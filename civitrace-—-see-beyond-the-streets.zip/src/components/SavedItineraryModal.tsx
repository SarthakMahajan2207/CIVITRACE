import React from 'react';
import { X, Bookmark, Clock, MapPin, Trash2, Printer, Compass, ArrowRight } from 'lucide-react';
import { Destination } from '../types';

interface SavedItineraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedDestinations: Destination[];
  onRemoveSaved: (id: string) => void;
  onClearAll: () => void;
  onOpenDetails: (destination: Destination) => void;
}

export const SavedItineraryModal: React.FC<SavedItineraryModalProps> = ({
  isOpen,
  onClose,
  savedDestinations,
  onRemoveSaved,
  onClearAll,
  onOpenDetails,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      <div className="relative w-full max-w-2xl bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh] z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-900/80 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-300">
              <Bookmark className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h3 className="text-xl font-editorial font-bold text-white">
                Saved Itinerary & Bookmarks
              </h3>
              <p className="text-xs text-slate-400">
                {savedDestinations.length} places saved in this session (stored locally)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Saved Places */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-3 flex-1">
          {savedDestinations.length > 0 ? (
            savedDestinations.map((dest, index) => (
              <div
                key={dest.id}
                className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors flex items-center justify-between gap-4 group"
              >
                <div
                  className="flex items-center gap-3 min-w-0 cursor-pointer flex-1"
                  onClick={() => {
                    onClose();
                    onOpenDetails(dest);
                  }}
                >
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-amber-300 text-xs font-bold font-mono flex items-center justify-center shrink-0">
                    {index + 1}
                  </span>
                  <div className="min-w-0">
                    <h4 className="text-sm font-editorial font-bold text-white group-hover:text-amber-300 transition-colors truncate">
                      {dest.name}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                      <span>{dest.category}</span>
                      <span>•</span>
                      <span className="flex items-center gap-0.5">
                        <Clock className="w-3 h-3 text-amber-400" /> {dest.suggestedDuration}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenDetails(dest);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-200 text-xs font-medium"
                  >
                    View
                  </button>
                  <button
                    onClick={() => onRemoveSaved(dest.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    title="Remove from saved"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-slate-400">
              <Compass className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p className="text-sm font-medium text-slate-300">Your itinerary is empty</p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Click the bookmark icon on any destination card to assemble your personalized exploration route.
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {savedDestinations.length > 0 && (
          <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs">
            <button
              onClick={onClearAll}
              className="text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" /> Clear All
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold shadow-md transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Export Route</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
