import { City } from '../../types';

export const jaipurData: City = {
  id: 'jaipur',
  name: 'Jaipur',
  state: 'Rajasthan',
  region: 'Dhundhar Plains & Aravalli Ranges',
  tagline: 'The Planned Pink City & Rajput Astronomical Capital',
  heroDescription: 'Conceived in 1727 by Maharaja Sawai Jai Singh II and Bengali master architect Vidyadhar Bhattacharya, Jaipur is India’s first planned Renaissance city. Built upon ancient Vastu Shastra principles and astronomical geometry, its salmon-terracotta streetscapes, hilltop forts, colossal sun dials, and generational craft guilds reflect Rajput chivalry and precision science.',
  introSentence: 'A planned desert capital where geometric grid streets, terracotta-pink facades, and astronomical stone observatories meet rugged Aravalli ramparts.',
  coordinates: [26.9124, 75.7873],
  accentColor: 'rose',
  hexAccent: '#e11d48',
  heroImage: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Hawa Mahal pink sandstone honeycomb windows in Jaipur',
  imageCredit: 'Unsplash / Rajasthan Tourism Development Archive',
  heritageThemes: ['Planned Vastu Urban Grid (1727)', 'UNESCO Astronomical Observatory (Jantar Mantar)', 'Amber Hilltop Fortresses', 'Kachhwaha Royal Dynasties', 'Block Printing & Gem Cutting Guilds'],

  destinations: [
    {
      id: 'jaipur-amber-fort',
      name: 'Amber Fort (Amer) & Maota Lake',
      cityId: 'jaipur',
      category: 'History & Heritage',
      shortSummary: 'UNESCO World Heritage 16th-century hilltop palace of yellow and pink sandstone overlooking Maota Lake.',
      fullDescription: 'Perched strategically upon a rugged Aravalli promontory 11 km north of Jaipur, Amber Fort was the ancient capital of the Kachhwaha Rajputs before the founding of Jaipur. Commenced in 1592 by Raja Man Singh I and expanded by Sawai Jai Singh, the palace-fortress blends rugged Rajput martial defenses with refined Mughal aesthetics. Overlooking the mirrored waters of Maota Lake and the formal Kesar Kyari (Saffron Garden), the fort features four grand courtyards. The pinnacle of its decorative splendour is the Sheesh Mahal (Mirror Palace), where walls and ceilings are inlaid with thousands of convex imported Belgian glass mirrors that glow like a constellation under the flame of a single candle.',
      historicalBackground: 'Founded on an 11th-century Meena stronghold. It served as the royal residence until Sawai Jai Singh II shifted the court down to the plains of Jaipur in 1727. Inscribed as part of the Hill Forts of Rajasthan UNESCO site in 2013.',
      culturalSignificance: 'The premier symbol of Rajput-Mughal diplomatic alliance and architectural cross-pollination.',
      architecturalFeatures: 'Carved yellow and pink sandstone, marble intarsia, Sheesh Mahal convex mirror mosaics, Jas Mandir relief panels, and subterranean tunnels connecting to Jaigarh Fort.',
      whyWorthVisiting: 'Experience the theatrical splendour of Rajput court life, defensive ramparts, and lake reflections.',
      whatToExperience: 'Walk up the stone ramp through Suraj Pol (Sun Gate), marvel at the floral mirrorwork in Sheesh Mahal, explore the zenana courtyards, and visit the historic Shila Devi temple at the gate.',
      location: 'Devisinghpura, Amer, Jaipur 302001',
      coordinates: [26.9855, 75.8513],
      suggestedDuration: '3 hours',
      bestTimeToVisit: 'Early morning (8:00 AM – 10:30 AM) to experience the palace in cool air before tourist buses arrive, or night for the light and sound show.',
      entryFeeInfo: '₹100 for Indian citizens, ₹500 for foreign visitors; composite tickets covering multiple Jaipur monuments available.',
      openingHoursInfo: 'Open daily: 8:00 AM – 5:30 PM; evening night viewing: 6:30 PM – 9:15 PM.',
      accessibilityInfo: 'Stone ramps lead to the first courtyard, but upper palace levels involve stone steps, cobblestone ramps, and narrow medieval corridors.',
      familySuitability: 'Dramatic and educational for all generations; wear comfortable footwear with good grip.',
      photographyNotes: 'Spectacular sunrise reflections of the fort ramparts in Maota Lake; mirror reflections inside Sheesh Mahal.',
      nearbyCombinations: ['Jaigarh Fort & Jaivana Cannon', 'Panna Meena ka Kund stepwell', 'Anokhi Museum of Hand Printing'],
      transitAdvice: 'Take RTDC bus #5 from Hawa Mahal or an auto-rickshaw/cab (11 km from city center). Electric golf carts shuttle from the base car park.',
      visitorTips: ['Take the underground tunnel walkway from Amber up to Jaigarh Fort to understand military escape routes.', 'Visit Panna Meena stepwell just 1 km away immediately afterwards.'],
      officialLinks: [{ title: 'Department of Archaeology & Museums Rajasthan', url: 'https://museumsrajasthan.gov.in' }],
      sourceNote: 'UNESCO World Heritage Dossier & Rajasthan State Archives.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Amber Fort stone ramparts and bastions overlooking Maota Lake',
      imageCredit: 'Unsplash'
    },
    {
      id: 'jaipur-hawa-mahal',
      name: 'Hawa Mahal (Palace of Winds)',
      cityId: 'jaipur',
      category: 'Architecture',
      shortSummary: 'Five-storey 1799 pink sandstone facade featuring 953 carved jharokha honeycomb windows.',
      fullDescription: 'Commissioned in 1799 by Maharaja Sawai Pratap Singh and designed by Lal Chand Ustad, Hawa Mahal is Jaipur’s most instantly recognizable architectural icon. Shaped in the form of Lord Krishna’s crown, this extraordinary five-storey pink and red sandstone structure rises 15 metres above the street, yet is only a single room deep at its upper floors. Its street facade incorporates 953 intricately carved stone jharokhas (casements) with miniature windows. Designed to enable the veiled royal women of the zenana to observe daily street life, festival processions, and imperial arrivals in the bazaar below without being seen from outside, the building operates on the Venturi effect: cool breezes circulate continuously through the latticework.',
      historicalBackground: 'Constructed as an extension of the City Palace complex to maintain strict purdah customs while keeping court women connected to civic festivities.',
      culturalSignificance: 'A masterpiece of climate-responsive vernacular engineering and Rajput aesthetic grace.',
      architecturalFeatures: 'Five-tiered semi-octagonal bays, pink sandstone jali screens, fluted domes, brass finials, and painted stained-glass transoms.',
      whyWorthVisiting: 'Nowhere else in the world features such an audacious, veil-like facade of stone lace that functions as a natural air-cooling device.',
      whatToExperience: 'Photograph the facade from the rooftop cafes opposite at sunrise, climb inside to look through the coloured glass windows into Badi Chaupar bazaar, and visit the small archaeological museum in the rear courtyard.',
      location: 'Hawa Mahal Road, Badi Choupad, J.D.A. Market, Jaipur 302002',
      coordinates: [26.9239, 75.8267],
      suggestedDuration: '1 to 1.5 hours',
      bestTimeToVisit: 'Sunrise (6:30 AM – 8:30 AM) when morning sunlight illuminates the pink stone facade.',
      entryFeeInfo: '₹50 for Indian nationals, ₹200 for foreign tourists (included in composite ticket).',
      openingHoursInfo: 'Open daily: 9:00 AM – 5:00 PM.',
      accessibilityInfo: 'The upper levels are reached via steep ramps rather than stairs (designed to allow palanquins to be wheeled up). Wheelchair users can navigate the lower courtyard.',
      familySuitability: 'Delightful for all ages; children love looking through the miniature coloured spyholes.',
      photographyNotes: 'Cross the street to Tattoo Cafe or Wind View Cafe for the classic eye-level panoramic photo of the 953-window facade in the morning light.',
      nearbyCombinations: ['Jantar Mantar', 'City Palace', 'Johari Bazaar'],
      transitAdvice: 'Badi Chaupar Metro Station (Pink Line) is directly underneath the monument, offering effortless transit.',
      visitorTips: ['Enter through the rear gate off Sireh Deori Bazaar to access the interior courtyards.', 'Notice that there are no stairs inside; only sloping ramps lead between storeys.'],
      officialLinks: [{ title: 'Rajasthan Tourism Development Corporation — Hawa Mahal', url: 'https://tourism.rajasthan.gov.in' }],
      sourceNote: 'Archaeological Survey of India & Rajasthan State Archaeology Department.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Intricately carved pink sandstone windows of Hawa Mahal',
      imageCredit: 'Unsplash'
    },
    {
      id: 'jaipur-jantar-mantar',
      name: 'Jantar Mantar UNESCO Astronomical Observatory',
      cityId: 'jaipur',
      category: 'History & Heritage',
      shortSummary: 'UNESCO World Heritage 1734 open-air observatory housing the world’s largest stone sundial, measuring time to two-second accuracy.',
      fullDescription: 'Constructed between 1728 and 1734 by the astronomer-king Maharaja Sawai Jai Singh II, Jantar Mantar is the most significant, comprehensive, and best-preserved collection of historic astronomical instruments in the world. Comprising nineteen colossal architectural stone instruments built from local stone and marble, each designed for naked-eye celestial calculation, it represents a remarkable convergence of Ptolemaic, Islamic, and Hindu astronomical sciences. The highlight is the Vrihat Samrat Yantra: the world’s largest stone sundial, rising 27 metres into the sky. Its massive triangular gnomon casts a shadow that moves at a visible rate of one millimetre per second, calculating local solar time to an accuracy of two seconds.',
      historicalBackground: 'The largest of five observatories built by Jai Singh II (others in Delhi, Ujjain, Varanasi, and Mathura). Inscribed as a UNESCO World Heritage site in 2010.',
      culturalSignificance: 'A triumph of pre-telescopic astronomical architecture, embodying the enlightened scientific spirit of 18th-century India.',
      architecturalFeatures: 'Gigantic precision-calibrated marble scales, quadrant arcs, hemispherical sundials (Jai Prakash Yantra), and zodiacal observation pillars.',
      whyWorthVisiting: 'Stand before monumental abstract sculptural stone forms that function as hyper-accurate calculators of the cosmos.',
      whatToExperience: 'Observe the shadow move across the Samrat Yantra dial in real-time, view the Jai Prakash Yantra inverted bowl instruments, and hire an accredited astronomical guide to explain the trigonometry.',
      location: 'Gangori Bazaar, J.D.A. Market, Kanwar Nagar, Jaipur 302002',
      coordinates: [26.9248, 75.8246],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Solar noon (11:30 AM – 1:30 PM) to watch the vertical shadows align with true local solar zenith.',
      entryFeeInfo: '₹50 for Indian nationals, ₹200 for foreign visitors; audio guide ₹150.',
      openingHoursInfo: 'Open daily: 9:00 AM – 5:00 PM.',
      accessibilityInfo: 'The observatory is laid out across level, paved garden courtyards; highly accessible for wheelchairs and strollers.',
      familySuitability: 'Fascinating for science enthusiasts, students, and curious travelers.',
      photographyNotes: 'Striking abstract geometric shapes and shadow lines against clear desert skies.',
      nearbyCombinations: ['City Palace', 'Hawa Mahal', 'Tripolia Bazaar'],
      transitAdvice: 'Located adjacent to City Palace. Chhoti Chaupar or Badi Chaupar Metro Stations are within 600m.',
      visitorTips: ['Hire an official guide at the entrance or rent an audio guide; without explanation, the mathematical genius of the stone instruments remains opaque.', 'Carry a sun hat and umbrella as the observatory is completely open to the sun.'],
      officialLinks: [{ title: 'UNESCO World Heritage — Jantar Mantar Jaipur', url: 'https://whc.unesco.org/en/list/1338' }],
      sourceNote: 'UNESCO Inscription Dossier & Archaeological Survey of India.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Monumental geometric stone sundials of Jantar Mantar in Jaipur',
      imageCredit: 'Unsplash'
    },
    {
      id: 'jaipur-panna-meena-stepwell',
      name: 'Panna Meena Ka Kund (Historic Stepwell)',
      cityId: 'jaipur',
      category: 'Architecture',
      shortSummary: '16th-century eight-storey symmetrical geometric stepwell tucked into the quiet foothills of Amer.',
      fullDescription: 'Located in the historic village behind Amber Fort, Panna Meena Ka Kund is a breathtaking 16th-century stepwell that served as a communal water reservoir, cooling retreat, and social meeting place for the local community. Engineered in an extraordinary criss-crossing diamond pattern of stepped stone pyramids descending eight storeys into the earth, the stepwell’s visual rhythm is mesmerizing. Recessed arched alcoves on the upper tiers allowed villagers to sit in the shade while fetching water. Local legend claims that the staircase pattern is an optical riddle: no person can use the same sequence of stairs to ascend as they did to descend.',
      historicalBackground: 'Built during the reign of Raja Man Singh I to harness seasonal rainwater runoff from the surrounding Aravalli hills.',
      culturalSignificance: 'A masterpiece of traditional desert hydraulic engineering and community water architecture.',
      architecturalFeatures: 'Symmetrical interlocking zig-zag stone stairs, subterranean cooling chambers, octagonal corner pavilions (chhatris), and yellow lime plaster finish.',
      whyWorthVisiting: 'Experience the quiet contemplative beauty of ancient Rajasthani stepwell geometry away from the tour bus crowds.',
      whatToExperience: 'Admire the mesmerizing optical symmetry from the upper parapet, explore the ancient Bihari Ji temple across the road, and stroll through the quiet village lanes of Amer.',
      location: 'Near Anokhi Museum, Amer, Jaipur 302028',
      coordinates: [26.9859, 75.8569],
      suggestedDuration: '45 minutes',
      bestTimeToVisit: 'Morning (8:00 AM – 10:30 AM) when the sun casts crisp triangular shadows down the stepped pyramids.',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Open daily: 6:00 AM – 6:00 PM.',
      accessibilityInfo: 'Viewing from the street level is flat and accessible; walking down the stairs is strictly prohibited by security guards for safety and preservation.',
      familySuitability: 'Safe and peaceful viewing; keep children away from low perimeter edges.',
      photographyNotes: 'Spectacular geometric angles; morning sunlight creates high-contrast shadows across the steps.',
      nearbyCombinations: ['Amber Fort', 'Anokhi Museum of Hand Printing', 'Jagat Shiromani Temple'],
      transitAdvice: 'A 10-minute walk or 2-minute auto ride from the base car park of Amber Fort.',
      visitorTips: ['Respect the guards and do not attempt to climb down into the water.', 'Visit the nearby 17th-century Jagat Shiromani Temple, which features magnificent carved Garuda and Krishna shrines.'],
      officialLinks: [{ title: 'Rajasthan Tourism — Amer Heritage Zone', url: 'https://tourism.rajasthan.gov.in' }],
      sourceNote: 'INTACH Rajasthan Chapter & State Archaeology Department.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Symmetrical geometric stone steps of historic stepwell in Rajasthan',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '10th – 17th Century CE',
      title: 'Amer Chieftaincy & Mughal Alliance',
      description: 'The Kachhwaha Rajputs rule from the hilltop fortress of Amer, establishing close strategic ties with Mughal Emperors Akbar and Jahangir.',
      keySites: ['Amber Fort', 'Jaigarh Fort', 'Shila Devi Temple']
    },
    {
      epoch: '1727 – 1800 CE',
      title: 'Foundation of the Planned Capital',
      description: 'Maharaja Sawai Jai Singh II shifts court to the plains and founds Jaipur, building nine Vastu grid sectors, Jantar Mantar, and the City Palace.',
      keySites: ['City Palace', 'Jantar Mantar', 'Hawa Mahal', 'Tripolia Bazaar']
    },
    {
      epoch: '1876 CE',
      title: 'The Pink Wash of Hospitality',
      description: 'Maharaja Sawai Ram Singh II orders the entire walled city painted in terracotta-pink lime to welcome Albert Edward, Prince of Wales, legally mandating the colour by municipal law.',
      keySites: ['Albert Hall Museum', 'Johari Bazaar pink arcades', 'Ajmeri Gate']
    }
  ],

  architecturalHeritageOverview: 'Jaipur represents the pinnacle of 18th-century Indian urban planning: a nine-square grid modeled on the cosmic Prastara plan, wide 111-foot boulevards lined with uniform terracotta-pink arcades, and defensive hilltop fortresses connected by underground tunnels.',

  traditionsAndFestivals: [
    {
      title: 'Gangaur & Teej Royal Processions',
      seasonOrFrequency: 'Chaitra (March – April) & Shravan (July – August)',
      description: 'Centuries-old royal processions where the idol of Goddess Parvati (Gauri) is carried through the Pink City from the City Palace to Talkatora lake, accompanied by caparisoned elephants, folk dancers, and camel bands.',
      visitorEtiquette: 'Watch from designated tourist viewing stands on Tripolia Bazaar; street crowds are joyful and dense.'
    },
    {
      title: 'Jaipur Literature Festival (JLF)',
      seasonOrFrequency: 'Annual in January',
      description: 'The "greatest literary show on Earth", drawing Nobel laureates, historians, and novelists to the lawns of Hotel Clarks Amer for free public intellectual debates and book signings.',
      visitorEtiquette: 'Register online in advance; carry layers as January mornings in Jaipur are chilly.'
    }
  ],

  dishes: [
    {
      id: 'jaipur-dal-baati-churma',
      name: 'Rajasthani Dal Baati Churma',
      localName: 'दाल बाटी चूरमा',
      culturalOrigin: 'The quintessential warrior food of Rajput armies, designed to bake in hot desert sand and keep for days.',
      description: 'Hard-baked wheat dough balls (baatis) cooked over cow-dung or charcoal embers, broken open and completely drenched in piping-hot clarified butter (desi ghee), served with spicy five-lentil panchmel dal, fiery red garlic chutney, and sweet cardamom-scented churma (crumbled wheat flour sautéed in ghee and jaggery).',
      typicalIngredients: ['Coarse wheat flour', 'Desi ghee', 'Panchmel dal (5 lentils)', 'Lahsun (garlic) chutney', 'Jaggery/sugar churma'],
      isVeg: true,
      whereToFind: 'Chokhi Dhani, Laxmi Mishthan Bhandar (LMB, Johari Bazaar), 1135 AD (Amber Fort).',
      priceCategory: 'Moderate',
      dietaryAdvice: 'Vegetarian. Extremely rich in ghee; one serving is deeply satiating.',
      etiquetteTips: 'Crush the baati thoroughly with your fingers into a bowl before pouring the hot dal and ghee over it.',
      image: 'https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'jaipur-pyaaz-kachori',
      name: 'Rawat Pyaaz Kachori',
      localName: 'प्याज कचौरी',
      culturalOrigin: 'Mastered in Jodhpur and turned into a morning civic religion by Rawat Mishthan Bhandar in Jaipur.',
      description: 'A large, flaky, golden pastry stuffed with a pungent, aromatic filling of spiced caramelised onions, crushed coriander seeds, fennel, and potatoes, fried slowly in ghee until crisp. Eaten scalding hot with sweet tamarind and spicy mint chutneys.',
      typicalIngredients: ['Refined flour pastry', 'Caramelised onions', 'Fennel seeds', 'Nigella seeds', 'Asafoetida', 'Imli chutney'],
      isVeg: true,
      whereToFind: 'Rawat Mishthan Bhandar (Station Road), Sodhani Sweets (Tonk Road), LMB (Johari Bazaar).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Flaky and deeply spiced; best eaten for breakfast accompanied by sweet kulhad chai.',
      etiquetteTips: 'Ask for it fresh from the frying kadhai; pair with a sweet mawa kachori to balance the heat.',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Johari Bazaar & Walled City',
      character: 'Historic pink arcades filled with sweetmakers, traditional thali halls, and street kachori vendors.',
      bestTime: 'Morning 8:30 AM – 11:00 AM and Evening 5:00 PM – 9:00 PM.',
      highlights: ['Paneer ghevar at Laxmi Mishthan Bhandar (LMB)', 'Kulfi at Pandit Kulfi', 'Samosa at Samrat'],
      visitorAdvice: 'The walled city is best explored on foot; auto-rickshaws can drop you at Badi Chaupar.'
    },
    {
      name: 'C-Scheme & MI Road',
      character: 'Cosmopolitan avenue featuring vintage lassi institutions, royal Rajasthani dining, and stylish garden cafes.',
      bestTime: 'All day (11:00 AM – 10:30 PM).',
      highlights: ['Creamy earthen-cup lassi at Lassiwala (est. 1944, 312 MI Road)', 'Handi mutton at Handi', 'Niros continental & Mughlai'],
      visitorAdvice: 'Be sure to visit the original Lassiwala at shop number 312, as several imitation stalls surround it.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Jaipur is hospitable and tourist-friendly, but persistent commission touts operating around Amber Fort and City Palace frequently attempt to steer visitors into overpriced gem, textile, or carpet emporiums.',
      'Politely decline unrequested shopping advice from auto drivers: "Nahi chahiye, shukriya" (No, thank you).',
      'Desert heat from April to June easily tops 40°C; carry water and sun protection.'
    ],
    transportPedestrian: [
      'Jaipur Metro (Pink Line) connects Mansarovar to Badi Chaupar, running directly into the heart of the walled heritage bazaar.',
      'Auto-rickshaw drivers rarely use meters; agree on a fixed fare before boarding or book via Uber/Ola.'
    ],
    nightTravel: [
      'MI Road, C-Scheme, and the floodlit heritage avenues around Albert Hall Museum are safe and pleasant for evening walks.',
      'Isolated sections of Nahargarh Fort road are unlit; visit the fort viewpoint by reliable hired cab before 9:00 PM.'
    ],
    accessibilityNotes: [
      'Jantar Mantar and Albert Hall Museum grounds have level paving and ramps.',
      'Hill forts (Amber, Nahargarh) have cobblestone slopes and steep medieval stairs that require steady footing.'
    ],
    emergencyContacts: [
      { title: 'Police Emergency Response', number: '112', note: '24/7 central emergency line' },
      { title: 'Jaipur Tourist Police Assistance', number: '0141 237 4473', note: 'Monitors tout harassment and visitor grievances' },
      { title: 'Women Safety Helpline', number: '1090', note: 'Rajasthan Police Nirbhaya Squad' },
      { title: 'SMS Hospital Emergency (Trauma Center)', number: '0141 251 8242', note: 'Premier government tertiary care hospital' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Department of Tourism Rajasthan and Jaipur Police Commissionerate.'
  },

  neighbourhoods: [
    {
      id: 'jaipur-walled-city',
      name: 'The Walled Pink City (Chaupars & Bazaars)',
      cityId: 'jaipur',
      character: 'The historic 1727 Vastu grid planned by Jai Singh II, framed by terracotta-pink shopfronts, bustling gem bazaars, and imperial palaces.',
      budgetTier: 'Budget-friendly to Moderate',
      transitScore: 'Very High (Served by Badi Chaupar & Chhoti Chaupar metro stations)',
      transitDetails: 'Direct Metro connection; cycle rickshaws and walking within the lanes.',
      walkabilityRating: 'High on covered arcades, but watch for two-wheelers at intersections.',
      accessibilityNotes: 'Sidewalks in the pink arcades are raised but flat; ramps exist at major crossings.',
      heritageHighlights: ['Hawa Mahal', 'Jantar Mantar', 'City Palace', 'Tripolia Gate'],
      foodHighlights: ['Laxmi Mishthan Bhandar (LMB)', 'Pandit Kulfi', 'Samrat Restaurant'],
      greenSpaceNotes: 'Talkatora Lake and Ram Niwas Garden situated directly south.',
      safetyContext: 'High public safety due to dense shopkeeper presence; stay alert to pickpockets in crowded Bapu Bazaar.',
      methodologyNote: 'Evaluated using UNESCO heritage city management plans and pedestrian accessibility audits.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'jaipur-c-scheme',
      name: 'C-Scheme & Civil Lines',
      cityId: 'jaipur',
      character: 'Leafy, cosmopolitan residential and diplomatic district filled with wide boulevards, colonial bungalows, boutique hotels, and design cafes.',
      budgetTier: 'Upscale / High-end',
      transitScore: 'High (Short cab drive to railway station; easily accessible by app taxis)',
      transitDetails: 'Wide avenues, low congestion, easy parking.',
      walkabilityRating: 'High (Quiet residential tree-lined streets with continuous footpaths).',
      accessibilityNotes: 'Level sidewalks with modern curb cuts; modern cafes have step-free access.',
      heritageHighlights: ['Raj Mandir Cinema (Art Deco marvel)', 'Central Park', 'Statue Circle'],
      foodHighlights: ['Lassiwala', 'Tapri Central (terrace tea)', 'Niros'],
      greenSpaceNotes: 'Central Park offers Jaipur’s longest jogging track (5 km) around a massive golf-course lawn.',
      safetyContext: 'One of the most secure and well-patrolled districts in the state capital.',
      methodologyNote: 'Calculated from municipal street lighting data and lifestyle infrastructure density.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-jaipur-pink-colour',
      cityId: 'jaipur',
      title: 'The Law of Pink: Why Jaipur Painted Itself Terracotta',
      preview: 'How a 19th-century royal visit turned a desert stone city into the world’s most famously coordinated monochromatic metropolis.',
      fullArticle: 'Before 1876, Jaipur was predominantly dressed in the natural pale yellow and buff hues of desert sandstone. That year, Albert Edward, Prince of Wales (later King Edward VII), embarked on a grand diplomatic tour of the Indian Empire. Seeking to impress the British heir and demonstrate the boundless hospitality of the Kachhwahas, Maharaja Sawai Ram Singh II looked for a colour that symbolized cordial welcome in Rajput tradition: gerua, a warm terracotta-pink hue made from local lime and ochre earth. Ram Singh ordered every building along the grand bazaars painted in this uniform shade. The Prince of Wales was reportedly enchanted, dubbing it the "Pink City". Ram Singh was so pleased by the visual unity that he enacted a municipal law in 1877 mandating that all shopfronts and havelis in the walled city maintain this exact shade—a statute that remains strictly enforced by the Jaipur Nagar Nigam to this day.',
      locationName: 'Johari Bazaar & Bapu Bazaar',
      factualExplanation: 'Documented in Royal Tour of the Prince of Wales by William Howard Russell and Jaipur Municipal Archives.',
      sources: ['State Archives of Rajasthan, Bikaner', 'Jaipur: The Making of an Indian City by Vibhuti Sachdev'],
      relatedDestinationIds: ['jaipur-hawa-mahal', 'jaipur-jantar-mantar'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Pink terracotta streetscapes of Jaipur'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '8°C – 26°C', advice: 'Ideal travel conditions; crisp sunny days and cool evenings. Bring a warm jacket for fort viewpoints and desert breezes.' },
      { season: 'Monsoon (Jul – Sep)', temperatureRange: '25°C – 34°C', advice: 'Aravalli hills turn lush and emerald green; lakes fill up. A picturesque, less crowded time to visit Amber and Nahargarh.' },
      { season: 'Summer (Apr – Jun)', temperatureRange: '28°C – 43°C', advice: 'Severe desert heat; sightseeing is best done between 7:00–10:00 AM or after 5:30 PM.' }
    ],
    transportInfrastructure: [
      { mode: 'Jaipur Metro', coverage: 'Mansarovar to Badi Chaupar (Pink Line)', tip: 'Clean, fast, connects the western suburbs directly to Hawa Mahal and Jantar Mantar.' },
      { mode: 'Auto-Rickshaws & E-Rickshaws', coverage: 'Everywhere', tip: 'Negotiate firmly or use Ola/Uber auto features.' },
      { mode: 'RTDC Tourist Buses', coverage: 'City circuit covers Amber, Nahargarh, and city museums', tip: 'Cost-effective for single travelers, though routes are fixed.' }
    ],
    environmentalNotes: 'Air quality is generally moderate, with occasional desert dust haze during pre-monsoon summer winds. Heritage preservation laws strictly govern facades in the walled city.',
    dataAttribution: 'Department of Tourism Rajasthan & Jaipur City Development Authority'
  }
};
