import React, { useState } from 'react';
import {
  Columns,
  HelpCircle,
  Bus,
  Footprints,
  Accessibility,
  Landmark,
  UtensilsCrossed,
  Trees,
  ShieldCheck,
  Wallet,
  Check,
  Plus,
  X,
  Sparkles
} from 'lucide-react';
import { Neighbourhood, City } from '../types';
import { allCities } from '../data/cities';

interface CompareSectionProps {
  currentCity: City;
}

export const CompareSection: React.FC<CompareSectionProps> = ({ currentCity }) => {
  // Initial selection: first 2 neighbourhoods of current city
  const [selectedNeighbourhoodIds, setSelectedNeighbourhoodIds] = useState<string[]>(
    currentCity.neighbourhoods.slice(0, 2).map((n) => n.id)
  );
  const [methodologyMetric, setMethodologyMetric] = useState<string | null>(null);

  // Pool of all available neighbourhoods (from active city + option to compare cross-city)
  const allAvailableNeighbourhoods = [
    ...currentCity.neighbourhoods,
    // Add popular neighbourhoods from other cities for cross-comparison
    ...allCities
      .filter((c) => c.id !== currentCity.id)
      .flatMap((c) => c.neighbourhoods)
  ];

  const selectedNeighbourhoods = allAvailableNeighbourhoods.filter((n) =>
    selectedNeighbourhoodIds.includes(n.id)
  );

  const toggleNeighbourhood = (id: string) => {
    if (selectedNeighbourhoodIds.includes(id)) {
      if (selectedNeighbourhoodIds.length > 1) {
        setSelectedNeighbourhoodIds(selectedNeighbourhoodIds.filter((item) => item !== id));
      }
    } else {
      if (selectedNeighbourhoodIds.length < 3) {
        setSelectedNeighbourhoodIds([...selectedNeighbourhoodIds, id]);
      } else {
        // Replace last item
        setSelectedNeighbourhoodIds([...selectedNeighbourhoodIds.slice(1), id]);
      }
    }
  };

  const metricDefinitions: Record<string, { definition: string; methodology: string; limitations: string }> = {
    budgetTier: {
      definition: 'Estimated daily visitor spending level on accommodations, dining, and casual purchases.',
      methodology: 'Synthesized from municipal commercial retail rates, average hotel tariffs, and local menu indexes.',
      limitations: 'Individual traveler costs vary according to dining choice and personal travel preferences.'
    },
    transitScore: {
      definition: 'Density, frequency, and multimodal connectivity of public transit infrastructure.',
      methodology: 'Audited from metro network proximity, municipal bus terminal density, and ride-hailing availability.',
      limitations: 'Traffic congestion during peak office rush hours can affect surface road transit speeds.'
    },
    walkabilityRating: {
      definition: 'Pedestrian ease, continuous footpath quality, and vehicular separation.',
      methodology: 'Evaluated through municipal street design guidelines, tree shade canopy, and pavement continuity.',
      limitations: 'Temporary civic repair works or festive street markets can temporarily alter walking routes.'
    },
    accessibilityNotes: {
      definition: 'Feasibility of navigation for manual wheelchairs, strollers, and mobility-impaired visitors.',
      methodology: 'Based on curb ramp presence, architectural threshold heights, and step-free transit stations.',
      limitations: 'Historic districts with century-old plinths often lack retrofitted ramp access.'
    },
    heritageHighlights: {
      definition: 'Concentration of protected monuments, museums, and historical structures.',
      methodology: 'Cross-referenced against national Archaeological Survey of India (ASI) and municipal heritage registers.',
      limitations: 'Does not reflect unlisted private ancestral vernacular properties.'
    },
    safetyContext: {
      definition: 'Social safety conditions, public lighting, and community vibrancy.',
      methodology: 'Derived from municipal street lighting records, night commercial activity, and police outposts.',
      limitations: 'CIVITRACE does not fabricate statistical crime rankings. Universal personal awareness applies.'
    }
  };

  return (
    <section id="compare" className="py-16 sm:py-24 bg-[#0a0e17] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-8 sm:mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
            <Columns className="w-4 h-4" />
            <span>Comparative Urban Intelligence</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
            Neighbourhood Comparison Tool
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Select two or three districts to compare their transit density, walkability, visitor budget, heritage character, and accessibility side-by-side with transparent methodology.
          </p>
        </div>

        {/* Selection Bar */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 mb-8 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
            <span>
              Select 2 to 3 neighbourhoods to compare (currently comparing{' '}
              <strong className="text-amber-300">{selectedNeighbourhoods.length}</strong>):
            </span>
            <span className="text-[11px] text-slate-500">
              Click a chip to add or remove
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {allAvailableNeighbourhoods.slice(0, 8).map((n) => {
              const isSelected = selectedNeighbourhoodIds.includes(n.id);
              return (
                <button
                  key={n.id}
                  onClick={() => toggleNeighbourhood(n.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-amber-600 text-amber-50 border border-amber-500 shadow-md'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-750 border border-slate-700/80'
                  }`}
                >
                  {isSelected ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{n.name}</span>
                  <span className="text-[10px] opacity-75">
                    ({allCities.find((c) => c.id === n.cityId)?.name})
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Side-by-Side Comparison Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {selectedNeighbourhoods.map((n) => {
            const parentCity = allCities.find((c) => c.id === n.cityId);
            return (
              <div
                key={n.id}
                className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 flex flex-col justify-between shadow-xl space-y-6"
              >
                {/* Header */}
                <div className="border-b border-slate-800 pb-4">
                  <div className="flex items-center justify-between text-xs text-amber-400 font-semibold mb-1">
                    <span>{parentCity?.name}</span>
                    <span className="text-[11px] text-slate-400">{n.dataFreshness}</span>
                  </div>
                  <h3 className="text-xl font-editorial font-bold text-white">
                    {n.name}
                  </h3>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    {n.character}
                  </p>
                </div>

                {/* Metrics Breakdown */}
                <div className="space-y-4 text-xs">
                  {/* Budget */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="flex items-center gap-1 font-semibold text-amber-200">
                        <Wallet className="w-3.5 h-3.5 text-amber-400" /> Typical Visitor Budget
                      </span>
                      <button
                        onClick={() => setMethodologyMetric('budgetTier')}
                        className="text-slate-500 hover:text-amber-300"
                        title="View methodology"
                      >
                        <HelpCircle className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="font-bold text-white text-sm">{n.budgetTier}</span>
                  </div>

                  {/* Public Transit */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="flex items-center gap-1 font-semibold text-teal-200">
                        <Bus className="w-3.5 h-3.5 text-teal-400" /> Public Transit Availability
                      </span>
                      <button
                        onClick={() => setMethodologyMetric('transitScore')}
                        className="text-slate-500 hover:text-amber-300"
                        title="View methodology"
                      >
                        <HelpCircle className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="font-medium text-slate-200 block">{n.transitScore}</span>
                    <span className="text-[11px] text-slate-400 mt-0.5 block">{n.transitDetails}</span>
                  </div>

                  {/* Walkability */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="flex items-center gap-1 font-semibold text-indigo-200">
                        <Footprints className="w-3.5 h-3.5 text-indigo-400" /> Walkability Rating
                      </span>
                      <button
                        onClick={() => setMethodologyMetric('walkabilityRating')}
                        className="text-slate-500 hover:text-amber-300"
                        title="View methodology"
                      >
                        <HelpCircle className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="font-medium text-slate-200">{n.walkabilityRating}</span>
                  </div>

                  {/* Accessibility */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="flex items-center gap-1 font-semibold text-rose-200">
                        <Accessibility className="w-3.5 h-3.5 text-rose-400" /> Wheelchair & Mobility Access
                      </span>
                      <button
                        onClick={() => setMethodologyMetric('accessibilityNotes')}
                        className="text-slate-500 hover:text-amber-300"
                        title="View methodology"
                      >
                        <HelpCircle className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="text-slate-300 leading-relaxed block">{n.accessibilityNotes}</span>
                  </div>

                  {/* Heritage Highlights */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <span className="flex items-center gap-1 font-semibold text-amber-200 mb-1.5">
                      <Landmark className="w-3.5 h-3.5 text-amber-400" /> Key Cultural Assets
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {n.heritageHighlights.map((h, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-slate-900 text-[11px] text-amber-200">
                          {h}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Green Spaces */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <span className="flex items-center gap-1 font-semibold text-emerald-200 mb-1">
                      <Trees className="w-3.5 h-3.5 text-emerald-400" /> Greenery & Public Open Spaces
                    </span>
                    <span className="text-slate-300 block">{n.greenSpaceNotes}</span>
                  </div>

                  {/* Safety Context */}
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-850">
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="flex items-center gap-1 font-semibold text-slate-200">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Contextual Safety Notes
                      </span>
                      <button
                        onClick={() => setMethodologyMetric('safetyContext')}
                        className="text-slate-500 hover:text-amber-300"
                        title="View methodology"
                      >
                        <HelpCircle className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="text-slate-300 leading-relaxed block">{n.safetyContext}</span>
                  </div>
                </div>

                {/* Methodology Footer */}
                <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 italic">
                  Methodology: {n.methodologyNote}
                </div>
              </div>
            );
          })}
        </div>

        {/* Methodology Modal */}
        {methodologyMetric && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/75 backdrop-blur-sm"
              onClick={() => setMethodologyMetric(null)}
            />
            <div className="relative w-full max-w-md bg-[#0f172a] border border-slate-700 rounded-2xl p-6 z-10 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <h4 className="text-base font-editorial font-bold text-white capitalize flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-amber-400" />
                  <span>Metric Methodology Disclosure</span>
                </h4>
                <button
                  onClick={() => setMethodologyMetric(null)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-slate-300">
                <div>
                  <span className="font-semibold text-amber-400 block mb-0.5">Definition:</span>
                  <p>{metricDefinitions[methodologyMetric]?.definition}</p>
                </div>
                <div>
                  <span className="font-semibold text-teal-400 block mb-0.5">Source & Methodology:</span>
                  <p>{metricDefinitions[methodologyMetric]?.methodology}</p>
                </div>
                <div>
                  <span className="font-semibold text-rose-400 block mb-0.5">Known Data Limitations:</span>
                  <p>{metricDefinitions[methodologyMetric]?.limitations}</p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-right">
                <button
                  onClick={() => setMethodologyMetric(null)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium"
                >
                  Understood
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
