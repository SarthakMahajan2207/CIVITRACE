import React from 'react';
import { Landmark, Clock, HelpCircle, Calendar, Sparkles, BookOpen } from 'lucide-react';
import { HeritageEpoch, CulturalTradition } from '../types';

interface HeritageSectionProps {
  cityName: string;
  heritagePeriods: HeritageEpoch[];
  architecturalOverview: string;
  traditions: CulturalTradition[];
  heritageThemes: string[];
}

export const HeritageSection: React.FC<HeritageSectionProps> = ({
  cityName,
  heritagePeriods,
  architecturalOverview,
  traditions,
  heritageThemes,
}) => {
  return (
    <section id="heritage" className="py-16 sm:py-24 bg-[#080c14] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
            <Landmark className="w-4 h-4" />
            <span>History & Living Culture</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
            Heritage & Historical Lineage of {cityName}
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Understanding the political transitions, architectural philosophies, and living traditions that shaped modern {cityName}.
          </p>

          {/* Heritage Key Themes Badges */}
          <div className="flex flex-wrap gap-2 mt-4">
            {heritageThemes.map((theme, i) => (
              <span
                key={i}
                className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-amber-200/90 font-medium"
              >
                • {theme}
              </span>
            ))}
          </div>
        </div>

        {/* Historical Timeline of Epochs */}
        <div className="mb-14 sm:mb-20">
          <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white mb-6 flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-400" />
            <span>Chronological Epochs & Sovereign Transitions</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
            {heritagePeriods.map((period, idx) => (
              <div
                key={idx}
                className="relative rounded-2xl bg-slate-900/90 border border-slate-800 p-5 flex flex-col justify-between hover:border-amber-500/40 transition-colors shadow-md"
              >
                <div>
                  <div className="inline-block px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold mb-3 font-mono">
                    {period.epoch}
                  </div>
                  <h4 className="text-base font-editorial font-bold text-white mb-2">
                    {period.title}
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {period.description}
                  </p>
                </div>

                {period.keySites && period.keySites.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-800/80">
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block mb-1">
                      Key Sites from this Era:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {period.keySites.map((site, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-2 py-0.5 rounded bg-slate-800 text-[11px] text-amber-200"
                        >
                          {site}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Architectural Deep-Dive & Fact vs Folklore Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-14 sm:mb-20">
          {/* Architectural Synthesis (2 cols) */}
          <div className="lg:col-span-2 rounded-2xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-400">
              <BookOpen className="w-4 h-4" />
              <span>Architectural Synthesis</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white">
              The Built Environment of {cityName}
            </h3>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed text-pretty">
              {architecturalOverview}
            </p>
            <div className="pt-3 border-t border-slate-800 text-xs text-slate-400">
              Documented through state archaeological surveys, municipal heritage conservation cells, and academic architectural monographs.
            </div>
          </div>

          {/* Fact vs Folklore Clarity Box (1 col) */}
          <div className="rounded-2xl bg-amber-950/20 border border-amber-500/30 p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400">
              <HelpCircle className="w-4 h-4" />
              <span>Editorial Integrity Note</span>
            </div>
            <h3 className="text-xl font-editorial font-bold text-amber-100">
              Fact vs. Folklore Distinction
            </h3>
            <p className="text-xs sm:text-sm text-amber-200/80 leading-relaxed">
              CIVITRACE strictly differentiates verified archaeological consensus and epigraphic records from popular folklore, local ghost legends, and contested oral histories. Where records differ or historical sources remain uncertain, our dossiers explicitly disclose the ambiguity.
            </p>
            <div className="p-3 rounded-xl bg-slate-950/60 border border-amber-500/20 text-[11px] text-slate-300">
              All dates, epigraphic inscriptions, and architectural styles cited in our guides are verified with the Archaeological Survey of India (ASI) or recognized university records.
            </div>
          </div>
        </div>

        {/* Living Traditions & Festivals */}
        <div>
          <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white mb-6 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>Living Traditions, Festivals & Visitor Etiquette</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {traditions.map((tradition, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between shadow-md"
              >
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold mb-2">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{tradition.seasonOrFrequency}</span>
                  </div>
                  <h4 className="text-lg font-editorial font-bold text-white mb-2">
                    {tradition.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {tradition.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800 bg-slate-950/50 p-3 rounded-xl">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 block mb-1">
                    Visitor & Etiquette Guidance:
                  </span>
                  <p className="text-xs text-slate-300 italic">
                    "{tradition.visitorEtiquette}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
