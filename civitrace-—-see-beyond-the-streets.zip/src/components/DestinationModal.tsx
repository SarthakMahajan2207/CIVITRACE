import React, { useState } from 'react';
import {
  X,
  MapPin,
  Clock,
  Calendar,
  Ticket,
  Accessibility,
  Users,
  Camera,
  Navigation,
  ExternalLink,
  Bookmark,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Share2,
  Compass
} from 'lucide-react';
import { Destination } from '../types';

interface DestinationModalProps {
  destination: Destination | null;
  onClose: () => void;
  isSaved: boolean;
  onToggleSave: (destinationId: string) => void;
  onAskPulseAi: (prompt: string) => void;
  onSelectNearbyDestination?: (destinationName: string) => void;
}

export const DestinationModal: React.FC<DestinationModalProps> = ({
  destination,
  onClose,
  isSaved,
  onToggleSave,
  onAskPulseAi,
  onSelectNearbyDestination,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);

  if (!destination) return null;

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${destination.name}, ${destination.location}`
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/85 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-4xl bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* Header Hero Image */}
        <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-slate-950 shrink-0">
          <img
            src={destination.image}
            alt={destination.imageAlt || destination.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-[#0f172a]/60 to-transparent" />

          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors shadow-lg"
            aria-label="Close dossier"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Category Pill */}
          <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-slate-900/85 backdrop-blur-md border border-amber-500/40 text-amber-200 text-xs font-semibold shadow-md">
            {destination.category}
          </div>

          {/* Title & Location Overlay */}
          <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:right-6">
            <h2 className="text-2xl sm:text-4xl font-editorial font-bold text-white text-balance">
              {destination.name}
            </h2>
            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-slate-300 mt-2">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                {destination.location}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                {destination.suggestedDuration}
              </span>
            </div>
          </div>
        </div>

        {/* Action Bar */}
        <div className="p-3 sm:px-6 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleSave(destination.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all ${
                isSaved
                  ? 'bg-amber-500 text-slate-950 border-amber-400 font-semibold'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
              <span>{isSaved ? 'Saved in Itinerary' : 'Save Destination'}</span>
            </button>

            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 transition-colors"
            >
              <Navigation className="w-3.5 h-3.5 text-teal-400" />
              <span>Open in Google Maps</span>
              <ExternalLink className="w-3 h-3 text-slate-500" />
            </a>

            <button
              onClick={handleShare}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 transition-colors"
              title="Copy share link"
            >
              <Share2 className="w-4 h-4" />
            </button>
            {copiedLink && (
              <span className="text-[11px] text-teal-400 animate-in fade-in">Link copied!</span>
            )}
          </div>

          {/* Ask Pulse AI Chip */}
          <button
            onClick={() => onAskPulseAi(`Tell me more about ${destination.name} and its historical and cultural significance in ${destination.cityId}.`)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-teal-800/80 to-amber-800/80 hover:from-teal-700 hover:to-amber-700 text-white font-medium border border-teal-500/40 shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            <span>Ask Pulse AI about this place</span>
          </button>
        </div>

        {/* Scrollable Dossier Body */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-6 sm:space-y-8 text-slate-200">
          {/* Introductory Summary */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/90 text-sm sm:text-base leading-relaxed text-amber-100/90 font-serif italic">
            "{destination.shortSummary}"
          </div>

          {/* Key Quick Facts Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1 flex items-center gap-1">
                <Ticket className="w-3.5 h-3.5 text-amber-400" /> Entry Fee
              </span>
              <span className="font-semibold text-slate-200">{destination.entryFeeInfo}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Opening Hours
              </span>
              <span className="font-semibold text-slate-200">{destination.openingHoursInfo}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-amber-400" /> Best Time
              </span>
              <span className="font-semibold text-slate-200">{destination.bestTimeToVisit}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-amber-400" /> Family Suitability
              </span>
              <span className="font-semibold text-slate-200">{destination.familySuitability}</span>
            </div>
          </div>

          {/* Detailed Editorial Background (150 - 250 words) */}
          <div className="space-y-4">
            <h3 className="text-lg font-editorial font-bold text-white border-b border-slate-800 pb-2">
              Detailed Exploration Dossier
            </h3>
            <p className="text-sm sm:text-base leading-relaxed text-slate-300 text-pretty">
              {destination.fullDescription}
            </p>
          </div>

          {/* Structured Analysis Sections */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Historical Background */}
            <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800/80 space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" /> Historical Background
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {destination.historicalBackground}
              </p>
            </div>

            {/* Cultural Significance */}
            <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800/80 space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <Compass className="w-4 h-4" /> Cultural Significance
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {destination.culturalSignificance}
              </p>
            </div>

            {/* Architectural / Natural Features */}
            <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800/80 space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Architectural & Design Features
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {destination.architecturalFeatures}
              </p>
            </div>

            {/* Why Worth Visiting */}
            <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800/80 space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Why It Is Worth Your Time
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {destination.whyWorthVisiting}
              </p>
            </div>
          </div>

          {/* What Visitors Experience */}
          <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 space-y-2">
            <h4 className="text-sm font-semibold text-white">What You Can Experience Here</h4>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {destination.whatToExperience}
            </p>
          </div>

          {/* Practical Visitor Tips */}
          {destination.visitorTips && destination.visitorTips.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-editorial font-bold text-white uppercase tracking-wider">
                Practical Visitor Guidance & Etiquette
              </h4>
              <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
                {destination.visitorTips.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" />
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Accessibility & Photography Breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Accessibility className="w-4 h-4 text-teal-400" /> Accessibility & Terrain
              </span>
              <p className="text-slate-400 leading-relaxed mt-1">{destination.accessibilityInfo}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-amber-400" /> Photography Guidelines
              </span>
              <p className="text-slate-400 leading-relaxed mt-1">{destination.photographyNotes}</p>
            </div>
          </div>

          {/* Transit & Navigation Advice */}
          <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2 text-xs sm:text-sm">
            <h4 className="font-semibold text-white flex items-center gap-1.5">
              <Navigation className="w-4 h-4 text-amber-400" /> Public Transit & Arrival Advice
            </h4>
            <p className="text-slate-300 leading-relaxed">{destination.transitAdvice}</p>
          </div>

          {/* Nearby Combinations */}
          {destination.nearbyCombinations && destination.nearbyCombinations.length > 0 && (
            <div className="space-y-2 text-xs sm:text-sm">
              <span className="text-slate-400 font-medium">Recommended Nearby Combinations for an Itinerary:</span>
              <div className="flex flex-wrap gap-2 mt-1">
                {destination.nearbyCombinations.map((combo, idx) => (
                  <button
                    key={idx}
                    onClick={() => onSelectNearbyDestination && onSelectNearbyDestination(combo)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-200 border border-slate-700 text-xs font-medium transition-colors"
                  >
                    + {combo}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Source Transparency & Verification Timestamp */}
          <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-500">
            <div>
              <span className="text-slate-400">Source: </span>
              <span>{destination.sourceNote}</span>
            </div>
            <div>
              <span className="text-slate-400">Last Verified: </span>
              <span className="text-slate-300 font-medium">{destination.verifiedDate}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>CIVITRACE Verified Cultural Intelligence</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
