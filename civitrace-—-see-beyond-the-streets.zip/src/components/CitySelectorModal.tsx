import React, { useState } from 'react';
import { X, Search, MapPin, Check, Sparkles } from 'lucide-react';
import { City } from '../types';
import { allCities } from '../data/cities';

interface CitySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCityId: string;
  onSelectCity: (city: City) => void;
}

export const CitySelectorModal: React.FC<CitySelectorModalProps> = ({
  isOpen,
  onClose,
  currentCityId,
  onSelectCity,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('All');

  if (!isOpen) return null;

  const regions = ['All', 'Maharashtra', 'Karnataka', 'Delhi', 'Rajasthan', 'Goa', 'Tamil Nadu', 'Telangana', 'West Bengal', 'Kerala', 'Uttar Pradesh', 'Gujarat'];

  const filteredCities = allCities.filter((city) => {
    const matchesQuery =
      city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      city.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
      city.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      city.region.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRegion =
      selectedRegion === 'All' || city.state.toLowerCase().includes(selectedRegion.toLowerCase());

    return matchesQuery && matchesRegion;
  });

  const handleSelect = (city: City) => {
    onSelectCity(city);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-4xl bg-[#0f172a] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-900/60 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Select Active Exploration City</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-editorial font-bold text-white">
              12 Cultural Capitals of India
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
              Switching the active city immediately updates all destinations, heritage timelines, local food guides, neighbourhood comparisons, safety data, and Pulse AI insights.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Region Filter Bar */}
        <div className="p-4 sm:px-6 bg-slate-900/40 border-b border-slate-800 space-y-3">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by city name, state, or character (e.g. Pune, Goa, Ganges, Nizam, Peshwa)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-white placeholder-slate-400 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Region Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {regions.map((region) => (
              <button
                key={region}
                onClick={() => setSelectedRegion(region)}
                className={`px-2.5 py-1 rounded-full whitespace-nowrap font-medium transition-all ${
                  selectedRegion === region
                    ? 'bg-amber-600 text-amber-50 border border-amber-500 shadow-xs'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/80 border border-slate-700/60'
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>

        {/* City Cards Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCities.map((city) => {
              const isSelected = city.id === currentCityId;
              return (
                <div
                  key={city.id}
                  onClick={() => handleSelect(city)}
                  className={`group relative rounded-xl border overflow-hidden cursor-pointer transition-all duration-300 flex flex-col justify-between ${
                    isSelected
                      ? 'border-amber-500 bg-slate-850 ring-2 ring-amber-500/40 shadow-lg shadow-amber-950/30'
                      : 'border-slate-800 bg-slate-900/80 hover:border-slate-700 hover:bg-slate-850'
                  }`}
                >
                  {/* Photo Header */}
                  <div className="relative h-32 sm:h-36 w-full overflow-hidden bg-slate-950">
                    <img
                      src={city.heroImage}
                      alt={city.imageAlt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                    
                    {/* Active Badge */}
                    {isSelected && (
                      <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-bold flex items-center gap-1 shadow-md">
                        <Check className="w-3 h-3 stroke-[3]" /> Active
                      </div>
                    )}

                    {/* State & Region */}
                    <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[11px] text-slate-300">
                      <span className="font-semibold text-amber-200">{city.state}</span>
                      <span className="text-slate-400 text-[10px]">{city.destinations.length} Places</span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-3.5 flex flex-col justify-between flex-1">
                    <div>
                      <h3 className="text-base font-editorial font-bold text-white group-hover:text-amber-300 transition-colors flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{city.name}</span>
                      </h3>
                      <p className="text-xs text-amber-100/70 font-medium italic mt-0.5 line-clamp-1">
                        "{city.tagline}"
                      </p>
                      <p className="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                        {city.introSentence}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                      <span>{city.neighbourhoods.length} Neighbourhoods</span>
                      <span className="text-amber-400 font-medium group-hover:underline">Explore City →</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredCities.length === 0 && (
            <div className="py-12 text-center text-slate-400">
              <MapPin className="w-8 h-8 mx-auto text-slate-600 mb-2" />
              <p className="text-sm font-medium text-slate-300">No cities match "{searchQuery}"</p>
              <p className="text-xs text-slate-500 mt-1">Try searching by state name or clear your filters.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>CIVITRACE currently supports 12 deeply researched Indian cultural capitals.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
