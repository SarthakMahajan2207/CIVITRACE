import React, { useState, useEffect } from 'react';
import {
  allCities,
  defaultCity,
  getCityById,
  initialCommunityReports,
  SearchResultItem,
} from './data/cities';
import { City, Destination, CommunityReport, CategoryType } from './types';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ExploreSection } from './components/ExploreSection';
import { HeritageSection } from './components/HeritageSection';
import { FoodSection } from './components/FoodSection';
import { SafetySection } from './components/SafetySection';
import { CompareSection } from './components/CompareSection';
import { CityInsightsSection } from './components/CityInsightsSection';
import { CityStoriesSection } from './components/CityStoriesSection';
import { InteractiveMap } from './components/InteractiveMap';
import { DestinationModal } from './components/DestinationModal';
import { CitySelectorModal } from './components/CitySelectorModal';
import { SavedItineraryModal } from './components/SavedItineraryModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { PulseAiDrawer } from './components/PulseAiDrawer';
import { Footer } from './components/Footer';
import { Sparkles, Compass } from 'lucide-react';

export default function App() {
  // Current active city state
  const [currentCity, setCurrentCity] = useState<City>(() => {
    const savedCityId = localStorage.getItem('civitrace_active_city');
    if (savedCityId) {
      const found = getCityById(savedCityId);
      if (found) return found;
    }
    return defaultCity;
  });

  // Active navigation section
  const [activeSection, setActiveSection] = useState<string>('hero');

  // Modals state
  const [isCitySelectorOpen, setIsCitySelectorOpen] = useState(false);
  const [activeDestination, setActiveDestination] = useState<Destination | null>(null);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isPulseAiOpen, setIsPulseAiOpen] = useState(false);
  const [pulseAiInitialPrompt, setPulseAiInitialPrompt] = useState<string>('');

  // Saved bookmarks stored in localStorage
  const [savedDestinationIds, setSavedDestinationIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('civitrace_saved_destinations');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Community observations stored in state + localStorage
  const [communityReports, setCommunityReports] = useState<CommunityReport[]>(() => {
    try {
      const stored = localStorage.getItem('civitrace_community_reports');
      return stored ? JSON.parse(stored) : initialCommunityReports;
    } catch {
      return initialCommunityReports;
    }
  });

  // Save active city to localStorage
  useEffect(() => {
    localStorage.setItem('civitrace_active_city', currentCity.id);
  }, [currentCity]);

  // Persist saved destinations
  useEffect(() => {
    localStorage.setItem('civitrace_saved_destinations', JSON.stringify(savedDestinationIds));
  }, [savedDestinationIds]);

  // Persist community reports
  useEffect(() => {
    localStorage.setItem('civitrace_community_reports', JSON.stringify(communityReports));
  }, [communityReports]);

  // Global Keyboard Shortcuts (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handlers
  const handleSelectCity = (city: City) => {
    setCurrentCity(city);
    setActiveDestination(null);
  };

  const handleToggleSave = (destId: string) => {
    setSavedDestinationIds((prev) =>
      prev.includes(destId) ? prev.filter((id) => id !== destId) : [...prev, destId]
    );
  };

  const handleClearAllSaved = () => {
    setSavedDestinationIds([]);
  };

  const handleAddCommunityReport = (newReport: Omit<CommunityReport, 'id' | 'timestamp' | 'status'>) => {
    const reportItem: CommunityReport = {
      ...newReport,
      id: `rep-user-${Date.now()}`,
      timestamp: 'Just now',
      status: 'Under review',
    };
    setCommunityReports((prev) => [reportItem, ...prev]);
  };

  const handleNavigateSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleAskPulseAi = (prompt: string) => {
    setPulseAiInitialPrompt(prompt);
    setIsPulseAiOpen(true);
  };

  const handleGlobalSearchResult = (item: SearchResultItem) => {
    if (item.type === 'city') {
      const city = getCityById(item.id);
      if (city) {
        handleSelectCity(city);
        handleNavigateSection('hero');
      }
    } else if (item.type === 'destination') {
      const parentCity = getCityById(item.cityId);
      if (parentCity) {
        if (parentCity.id !== currentCity.id) {
          handleSelectCity(parentCity);
        }
        const dest = parentCity.destinations.find((d) => d.id === item.id);
        if (dest) {
          setActiveDestination(dest);
        }
      }
    } else if (item.type === 'story') {
      const parentCity = getCityById(item.cityId);
      if (parentCity) {
        if (parentCity.id !== currentCity.id) {
          handleSelectCity(parentCity);
        }
        handleNavigateSection('stories');
      }
    } else if (item.type === 'dish') {
      const parentCity = getCityById(item.cityId);
      if (parentCity) {
        if (parentCity.id !== currentCity.id) {
          handleSelectCity(parentCity);
        }
        handleNavigateSection('food');
      }
    }
  };

  const handleSelectNearbyDestination = (name: string) => {
    const found = currentCity.destinations.find(
      (d) => d.name.toLowerCase().includes(name.toLowerCase()) || name.toLowerCase().includes(d.name.toLowerCase())
    );
    if (found) {
      setActiveDestination(found);
    }
  };

  // Compile list of full Destination objects for saved modal
  const allDestinationsMap = new Map<string, Destination>();
  for (const c of allCities) {
    for (const d of c.destinations) {
      allDestinationsMap.set(d.id, d);
    }
  }
  const savedDestinationsList = savedDestinationIds
    .map((id) => allDestinationsMap.get(id))
    .filter((d): d is Destination => Boolean(d));

  // Current city's community reports
  const currentCityReports = communityReports.filter((r) => r.cityId === currentCity.id);

  return (
    <div className="min-h-screen bg-[#0a0e17] text-[#f1ece4] font-sans selection:bg-amber-600 selection:text-white">
      {/* Sticky Primary Header */}
      <Navbar
        currentCity={currentCity}
        onSelectCityClick={() => setIsCitySelectorOpen(true)}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        onOpenSaved={() => setIsSavedModalOpen(true)}
        onOpenPulseAi={() => setIsPulseAiOpen(true)}
        savedCount={savedDestinationIds.length}
        activeSection={activeSection}
        onNavigateSection={handleNavigateSection}
      />

      {/* Main Page Flow */}
      <main>
        {/* Cinematic Hero */}
        <HeroSection
          city={currentCity}
          onExploreClick={() => handleNavigateSection('explore')}
          onStoriesClick={() => handleNavigateSection('stories')}
          onOpenCitySelector={() => setIsCitySelectorOpen(true)}
          onSearchSubmit={(q) => {
            const el = document.getElementById('explore');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Explore Destinations Section */}
        <ExploreSection
          destinations={currentCity.destinations}
          cityName={currentCity.name}
          onOpenDetails={(dest) => setActiveDestination(dest)}
          savedDestinationIds={savedDestinationIds}
          onToggleSave={handleToggleSave}
        />

        {/* Heritage & Historical Lineage Section */}
        <HeritageSection
          cityName={currentCity.name}
          heritagePeriods={currentCity.heritagePeriods}
          architecturalOverview={currentCity.architecturalHeritageOverview}
          traditions={currentCity.traditionsAndFestivals}
          heritageThemes={currentCity.heritageThemes}
        />

        {/* Local Food & Gastronomic Life Section */}
        <FoodSection
          cityName={currentCity.name}
          dishes={currentCity.dishes}
          foodDistricts={currentCity.foodDistricts}
        />

        {/* Safety & Responsible Exploration Section */}
        <SafetySection
          cityName={currentCity.name}
          cityId={currentCity.id}
          safetyGuide={currentCity.safetyGuide}
          communityReports={currentCityReports}
          onAddCommunityReport={handleAddCommunityReport}
        />

        {/* Neighbourhood Comparison Section */}
        <CompareSection currentCity={currentCity} />

        {/* City Intelligence & Environmental Disclosures */}
        <CityInsightsSection
          city={currentCity}
          onOpenDestination={(dest) => setActiveDestination(dest)}
        />

        {/* City Stories & Editorial Chronicles */}
        <CityStoriesSection
          cityName={currentCity.name}
          stories={currentCity.stories}
          destinations={currentCity.destinations}
          onOpenDestination={(dest) => setActiveDestination(dest)}
        />

        {/* Interactive OpenStreetMap Leaflet Map */}
        <InteractiveMap
          city={currentCity}
          onOpenDestination={(dest) => setActiveDestination(dest)}
        />
      </main>

      {/* Floating Pulse AI Quick Action Button */}
      <div className="fixed bottom-6 right-6 z-30">
        <button
          onClick={() => setIsPulseAiOpen(true)}
          className="flex items-center gap-2 px-4 py-3 rounded-full bg-gradient-to-r from-teal-700 to-amber-700 hover:from-teal-600 hover:to-amber-600 text-white font-semibold text-xs sm:text-sm shadow-2xl shadow-black/80 border border-teal-400/40 hover:scale-105 active:scale-95 transition-all group"
          title={`Ask Pulse AI about ${currentCity.name}`}
        >
          <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-amber-200 animate-pulse" />
          </div>
          <span className="font-editorial tracking-wide font-bold">Ask Pulse AI</span>
          <span className="hidden md:inline text-[11px] text-amber-200/90 font-mono">({currentCity.name})</span>
        </button>
      </div>

      {/* Footer */}
      <Footer
        onSelectCity={(city) => handleSelectCity(city)}
        onNavigateSection={handleNavigateSection}
      />

      {/* Destination Dossier Modal */}
      <DestinationModal
        destination={activeDestination}
        onClose={() => setActiveDestination(null)}
        isSaved={activeDestination ? savedDestinationIds.includes(activeDestination.id) : false}
        onToggleSave={handleToggleSave}
        onAskPulseAi={handleAskPulseAi}
        onSelectNearbyDestination={handleSelectNearbyDestination}
      />

      {/* City Selector Modal */}
      <CitySelectorModal
        isOpen={isCitySelectorOpen}
        onClose={() => setIsCitySelectorOpen(false)}
        currentCityId={currentCity.id}
        onSelectCity={handleSelectCity}
      />

      {/* Saved Itinerary Modal */}
      <SavedItineraryModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedDestinations={savedDestinationsList}
        onRemoveSaved={handleToggleSave}
        onClearAll={handleClearAllSaved}
        onOpenDetails={(dest) => setActiveDestination(dest)}
      />

      {/* Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectResult={handleGlobalSearchResult}
      />

      {/* Pulse AI Assistant Drawer */}
      <PulseAiDrawer
        isOpen={isPulseAiOpen}
        onClose={() => setIsPulseAiOpen(false)}
        city={currentCity}
        initialPrompt={pulseAiInitialPrompt}
        onClearInitialPrompt={() => setPulseAiInitialPrompt('')}
      />
    </div>
  );
}
