import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// API: Health check and capabilities status
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString()
  });
});

// API: Server-side Gemini AI assistant for Pulse AI
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { message, city, history } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server. Guided local mode active.',
        isFallbackRequired: true,
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = `You are Pulse AI, the fact-grounded editorial city guide for CIVITRACE: "See Beyond the Streets".
Current Active City: ${city?.name || 'Indian Cultural Cities'} (${city?.state || ''}).
City Overview: ${city?.tagline || ''} — ${city?.heroDescription || ''}
Key heritage themes: ${city?.heritageThemes?.join(', ') || ''}.

STRICT EDITORIAL DIRECTIVES:
1. Provide thoughtful, culturally grounded, and practically structured responses.
2. Distinguish established historical consensus from legends/folklore. State uncertainty when records differ.
3. NEVER fabricate prices, current opening hours, transit timetables, or live crowd status. If unknown, advise checking official site or local verification.
4. When suggesting itineraries, bundle geographically logical spots to minimise needless transit.
5. Emphasise local etiquette, architectural nuance, regional food stories, and respectful exploration.
6. Keep answers concise, highly readable, and formatted with clean paragraphs or bullet points without excessive hype.`;

    const contents = [];
    if (Array.isArray(history) && history.length > 0) {
      // Limit recent history turns
      for (const h of history.slice(-6)) {
        contents.push({
          role: h.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: h.content }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || 'I could not generate a response for this query.';
    return res.json({
      text: replyText,
      model: 'gemini-3.8-flash',
      isLive: true,
    });
  } catch (error: any) {
    console.error('Gemini API Server Error:', error);
    return res.status(500).json({
      error: error?.message || 'Error communicating with Gemini API.',
      isFallbackRequired: true,
    });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CIVITRACE Server running on http://0.0.0.0:${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
