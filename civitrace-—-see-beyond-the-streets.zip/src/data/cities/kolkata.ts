import { City } from '../../types';

export const kolkataData: City = {
  id: 'kolkata',
  name: 'Kolkata',
  state: 'West Bengal',
  region: 'Lower Ganges Delta',
  tagline: 'City of Joy & The Intellectual Renaissance Hub',
  heroDescription: 'Spanning the eastern bank of the tidal Hooghly river, Kolkata is the grand cultural and literary capital of India. As the seat of the British Raj until 1911 and the crucible of the 19th-century Bengal Renaissance, Kolkata blends monumental Makrana marble memorials, iconic balanced-cantilever river bridges, thousand-year-old clay idol-sculpting lanes, bustling book bazaars, and an unmatched tradition of passionate coffee-house intellectual debate (adda).',
  introSentence: 'A riverfront literary metropolis where classical imperial marble halls, yellow ambassador cabs, clay idol artisan hamlets, and historic tramlines celebrate the human spirit.',
  coordinates: [22.5726, 88.3639],
  accentColor: 'rose',
  hexAccent: '#e11d48',
  heroImage: 'https://images.unsplash.com/photo-1558431382-27e303142255?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Victoria Memorial white marble palace and reflecting pools in Kolkata',
  imageCredit: 'Unsplash / West Bengal Tourism Development Corporation',
  heritageThemes: ['Bengal Renaissance & Rabindranath Tagore', 'Colonial Imperial Capital (Until 1911)', 'Kumartuli Clay Idol Sculpture Guilds', 'College Street Boi-Para & Adda Culture', 'Historic Trams & Hooghly Riverine Life'],

  destinations: [
    {
      id: 'kol-victoria-memorial',
      name: 'Victoria Memorial Hall & The Maidan',
      cityId: 'kolkata',
      category: 'History & Heritage',
      shortSummary: 'Grand 1921 white Makrana marble monument fusing British neoclassical and Mughal architectural design.',
      fullDescription: 'Conceived by Viceroy Lord Curzon following the death of Queen Victoria in 1901 and designed by Sir William Emerson, the Victoria Memorial is India’s grandest imperial monument. Constructed entirely of pure white Makrana marble quarried from Rajasthan (the exact same marble used in the Taj Mahal), the palace blends British classical revivalism with Mughal domes, Rajasthani kiosks (chhatris), and Italianate loggias. Standing on 64 acres of landscaped gardens adjacent to the vast green expanse of the Maidan, the central dome reaches 56 metres and is crowned by a three-ton bronze rotating Angel of Victory. Inside, 25 galleries house an extraordinary collection of over 30,000 artifacts, including the world’s largest collection of paintings by British landscape artists Thomas and William Daniell.',
      historicalBackground: 'Opened to the public in December 1921 by the Prince of Wales. Functioned as the supreme symbol of imperial power in British India before transitioning into an independent national museum.',
      culturalSignificance: 'The defining civic postcard of Kolkata and the premier public gathering lawn for morning walkers, artists, and families.',
      architecturalFeatures: 'Makrana white marble ashlar masonry, monumental central dome with corner chhatris, Italianate porticos, reflecting pools, and sculpted allegorical pediments.',
      whyWorthVisiting: 'Experience imperial architectural ambition on a grand scale, surrounded by lush public gardens.',
      whatToExperience: 'Walk through the grand marble rotunda, study the Daniell oil paintings of 18th-century India, stroll around the reflecting pools, and attend the evening light and sound narration.',
      location: '1, Queens Way, Maidan, Kolkata 700071',
      coordinates: [22.5448, 88.3426],
      suggestedDuration: '2 to 2.5 hours',
      bestTimeToVisit: 'Morning (9:30 AM – 11:30 AM) or late afternoon (4:00 PM – 6:00 PM) when the setting sun reflects in the white marble.',
      entryFeeInfo: 'Museum & Gardens: ₹50 for Indian citizens, ₹500 for foreign visitors; Garden only ticket ₹20.',
      openingHoursInfo: 'Gardens open daily: 5:30 AM – 6:00 PM; Museum galleries open: 10:00 AM – 5:00 PM (Closed Mondays and National Holidays).',
      accessibilityInfo: 'Paved garden paths are wide, smooth, and wheelchair friendly; ramps provide access to the ground floor museum galleries.',
      familySuitability: 'Superb for families, photographers, and history lovers; vast open lawns.',
      photographyNotes: 'Spectacular reflections in the northern pond; capture the bronze Angel of Victory against the sky.',
      nearbyCombinations: ['St. Paul’s Cathedral', 'The Maidan', 'Academy of Fine Arts', 'Nandan Cultural Center'],
      transitAdvice: 'Rabindra Sadan and Maidan Metro Stations (Blue Line) are within an 800m walk; easily reached by yellow taxi or bus.',
      visitorTips: ['Cross the street immediately east to visit St. Paul’s Cathedral with its soaring Gothic spire and stained-glass Burne-Jones windows.', 'Horse-drawn vintage carriages line Queens Way for a nostalgic ride around the Maidan.'],
      officialLinks: [{ title: 'Victoria Memorial Hall Official Portal', url: 'https://victoriamemorial-cal.org' }],
      sourceNote: 'Ministry of Culture, Government of India & Archaeological Survey of India.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1558431382-27e303142255?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'White marble facade and dome of Victoria Memorial in Kolkata',
      imageCredit: 'Unsplash'
    },
    {
      id: 'kol-howrah-bridge',
      name: 'Howrah Bridge (Rabindra Setu) & Hooghly Ghats',
      cityId: 'kolkata',
      category: 'Architecture',
      shortSummary: 'Iconic 1943 balanced-cantilever steel bridge carrying 100,000 vehicles and 150,000 pedestrians daily across the Hooghly.',
      fullDescription: 'Completed in 1943 during the Second World War without a single nut or bolt—relying entirely on hand-driven hot steel rivets—Howrah Bridge (officially Rabindra Setu) is a monumental engineering wonder of the world. Spanning 705 metres across the sacred Hooghly river between Kolkata and Howrah Station without a single submerged pillar in the riverbed, the cantilever suspension system was fabricated using 26,500 tons of high-tensile steel supplied by Tata Steel. At its base on the Kolkata side lies Mallick Ghat Flower Market—Asia’s largest wholesale flower bazaar—where hundreds of vendors trade mountains of orange marigolds and lotus blossoms on ancient wooden steps as country boats glide down the misty river.',
      historicalBackground: 'Replaced a pontoon bridge built in 1874. Renamed in 1965 after Nobel laureate Rabindranath Tagore. Stands as the busiest cantilever bridge in the world.',
      culturalSignificance: 'The physical and emotional gateway to Kolkata, celebrated in global cinema, Bengali literature, and art.',
      architecturalFeatures: 'Balanced cantilever truss structure, 85-metre high anchor towers, rivet construction, and wide pedestrian walkways.',
      whyWorthVisiting: 'Experience the exhilarating kinetic energy of Kolkata as thousands of pedestrians, porters balancing giant wicker baskets, and yellow taxis cross the river together.',
      whatToExperience: 'Walk across the pedestrian path from Howrah to Kolkata at dawn, visit the vibrant Mallick Ghat flower market beneath the bridge, and board a public ferry across the river for five rupees.',
      location: 'Howrah Bridge, Hooghly River, Kolkata / Howrah',
      coordinates: [22.5851, 88.3468],
      suggestedDuration: '1.5 hours',
      bestTimeToVisit: 'Sunrise (5:30 AM – 7:30 AM) when the river is shrouded in gentle mist and the flower market is at its peak.',
      entryFeeInfo: 'Free public crossing; public river ferry ₹6.',
      openingHoursInfo: 'Open 24 hours. Well-patrolled by Kolkata Police and Port Trust security.',
      accessibilityInfo: 'Pedestrian walkway is broad and paved; step-free access from the street approaches on both banks.',
      familySuitability: 'Thrilling cultural experience; hold hands with children tightly during peak pedestrian movements.',
      photographyNotes: 'Photography directly on the bridge road deck is officially restricted by Kolkata Port Trust; sensational views can be captured from the public river ferries and Babu Ghat.',
      nearbyCombinations: ['Mallick Ghat Flower Market', 'Howrah Railway Station Heritage Facade', 'Babu Ghat'],
      transitAdvice: 'Take the newly commissioned East-West Metro (Green Line) through the underwater river tunnel connecting Howrah Station to Esplanade.',
      visitorTips: ['Board the public passenger ferry from Howrah Ghat to Fairlie Ghat or Babughat for the best panoramic view of the bridge superstructure.', 'Watch for the clay wrestlers practicing traditional kushti in the earthen akhada near Mallick Ghat at sunrise.'],
      officialLinks: [{ title: 'Syama Prasad Mookerjee Port Authority Kolkata', url: 'https://kolkataporttrust.gov.in' }],
      sourceNote: 'Kolkata Port Trust Archives & Tata Steel Historical Records.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Massive steel cantilever structure of Howrah Bridge across the misty Hooghly river',
      imageCredit: 'Unsplash'
    },
    {
      id: 'kol-kumartuli',
      name: 'Kumartuli Clay Idol Sculptors Guild',
      cityId: 'kolkata',
      category: 'Art & Museums',
      shortSummary: '300-year-old artisan potter quarter where generational sculptors fashion Durga idols from holy Ganga clay.',
      fullDescription: 'Tucked along the northern riverbank of the Hooghly lies Kumartuli (meaning "Potters’ Quarters"), a mesmerizing warren of narrow lanes where over 500 artisan families have sculpted sacred clay idols for three centuries. Arriving in the 18th century to create idols for the lavish aristocratic pujas of North Kolkata’s babus, the potters follow an ancient, sustainable ritual craft. Using bamboo armatures tied with straw (kathamo), the sculptors apply layers of sacred alluvial clay collected from the bed of the Hooghly (entel mati) mixed with cow dung and rice husk. Over months, these rough forms transform into magnificent, life-sized statues of Goddess Durga slaying the demon Mahishasura. In autumn, master artists paint the divine eyes of the goddess (Chokkhu Daan) in a ritual climax before the idols are dispatched across the globe.',
      historicalBackground: 'Established in the mid-18th century as a designated craft quarter under the East India Company’s settlement plans.',
      culturalSignificance: 'The artistic heart of Kolkata’s Durga Puja—inscribed as a UNESCO Intangible Cultural Heritage of Humanity in 2021.',
      architecturalFeatures: 'Traditional artisan workshop-studios with bamboo ceilings, drying lofts, clay kilns, and narrow pedestrian cobblestone alleys.',
      whyWorthVisiting: 'Stand inside active artisan workshops and observe raw river mud transformed into divine classical sculpture before your eyes.',
      whatToExperience: 'Walk respectfully through the sculpting alleys, observe artists shaping fingers from clay and applying gold-leaf ornament (daaker saaj), and visit Banamali Sarkar Street.',
      location: 'Kumartuli, Hatkhola, North Kolkata 700005',
      coordinates: [22.6006, 88.3614],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'August to October (leading up to Durga Puja) when workshops are in full production, or morning hours (9:00 AM – 12:00 PM).',
      entryFeeInfo: 'Free public quarter (small donation or photo pass fee of ₹50–₹100 is appreciated by artisan associations during peak season).',
      openingHoursInfo: 'Workshops operate daily: 8:00 AM – 8:00 PM.',
      accessibilityInfo: 'Alleys are narrow, unpaved in sections, and often filled with drying wooden frames; requires careful walking.',
      familySuitability: 'Profoundly inspiring for children, artists, and photographers.',
      photographyNotes: 'Spectacular portrait and documentary photography; always ask permission before taking close-up shots of an artisan at work.',
      nearbyCombinations: ['Sovabazar Rajbari', 'Bagbazar Ghat', 'Giridhar Ghat'],
      transitAdvice: 'Sovabazar Sutanuti Metro Station (Blue Line) is a 600m walk away; circular railway station at Bagbazar.',
      visitorTips: ['Wear comfortable, washable footwear as the lanes have clay dust and river sand.', 'Visit Sovabazar Rajbari nearby to see an intact 1757 aristocrat palace courtyard where traditional family pujas began.'],
      officialLinks: [{ title: 'UNESCO Intangible Cultural Heritage — Durga Puja in Kolkata', url: 'https://ich.unesco.org/en/RL/durga-puja-in-kolkata-01739' }],
      sourceNote: 'UNESCO Intangible Cultural Heritage Dossier & Kumartuli Mritshilpi Samiti.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Clay sculpture of Goddess Durga being painted in traditional workshop',
      imageCredit: 'Unsplash'
    },
    {
      id: 'kol-college-street',
      name: 'College Street Boi-Para & Indian Coffee House',
      cityId: 'kolkata',
      category: 'History & Heritage',
      shortSummary: 'The world’s largest secondhand book market (1.5 km of academic stalls) anchored by the 1876 Indian Coffee House.',
      fullDescription: 'Stretching 1.5 kilometres through the academic center of North Kolkata, College Street (known affectionately to Bengalis as Boi-Para, or "Book Town") is the largest second-hand book market in the world. Flanked by venerable 19th-century institutions of the Bengal Renaissance—Presidency University (1817), Calcutta University (1857), and the Sanskrit College—the pavements are packed with thousands of wooden stalls, tarpaulin shacks, and generational bookshops selling rare out-of-print first editions, philosophy treatises, and student textbooks. Across from Presidency University stands the legendary Indian Coffee House on Bankim Chatterjee Street: a soaring, smoke-stained, high-ceilinged 1876 hall where turbanned waiters serve black infusion coffee while students, poets, and Nobel laureates engage in passionate, endless intellectual debates (adda).',
      historicalBackground: 'The nerve center of the Bengal Renaissance where Raja Ram Mohan Roy, Ishwar Chandra Vidyasagar, and Rabindranath Tagore debated social reform and literature.',
      culturalSignificance: 'The intellectual sanctuary of Kolkata, celebrating the life of the mind, free inquiry, and literary passion.',
      architecturalFeatures: 'Colonial neoclassical academic colonnades, wooden book stalls lining tram tracks, high-ceilinged Victorian hall of Coffee House with whirring ceiling fans.',
      whyWorthVisiting: 'Immerse yourself in one of the world’s greatest book cultures and experience the legendary art of Bengali intellectual conversation.',
      whatToExperience: 'Browse rare paperbacks at the roadside wooden bookstalls, climb the staircase into Indian Coffee House to order mutton cutlets and black infusion coffee, and walk past Presidency College.',
      location: 'College Street, Bowbazar, Central Kolkata 700073',
      coordinates: [22.5739, 88.3639],
      suggestedDuration: '2 to 2.5 hours',
      bestTimeToVisit: 'Afternoon (2:00 PM – 6:00 PM) when student footfall and coffee house conversations reach their height.',
      entryFeeInfo: 'Free public street; Coffee House meals are very inexpensive.',
      openingHoursInfo: 'Bookstalls open Monday to Saturday: 11:00 AM – 8:00 PM; Coffee House open: 9:00 AM – 8:30 PM (Sundays: 12:30 PM – 7:30 PM).',
      accessibilityInfo: 'Sidewalks are narrow and filled with book crates; requires alert walking; historic stairs to Coffee House do not have an elevator.',
      familySuitability: 'Inspiring for students, literature enthusiasts, and travelers of all ages.',
      photographyNotes: 'Nostalgic documentary shots of ceiling fans, waiters in traditional uniform, and mountains of weathered books.',
      nearbyCombinations: ['Calcutta University Senate Hall', 'Presidency University', 'Putiram Sweets for dalpoori and misti'],
      transitAdvice: 'Mahatma Gandhi Road and Central Metro Stations (Blue Line) are within 500m; historic trams run along the central street.',
      visitorTips: ['Stop by Putiram Sweets at the corner of Surya Sen Street for breakfast dalpoori and fresh baked rasgullas.', 'If looking for a rare book, ask any stall owner; they will check an informal cooperative network to track down out-of-print titles within minutes.'],
      officialLinks: [{ title: 'College Street Boi-Para Publishers Association', url: 'https://kolkatatourism.gov.in' }],
      sourceNote: 'Calcutta University Historical Archive & Bengal Heritage Society Studies.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Wooden bookshelves stacked high with vintage volumes in College Street',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1690 – 1757 CE',
      title: 'Job Charnock & Three River Hamlets',
      description: 'Job Charnock establishes an English factory uniting the villages of Sutanuti, Gobindapur, and Kolikata; early Fort William built on the Hooghly.',
      keySites: ['Job Charnock’s Mausoleum (St. John’s Church)', 'Old Fort William site']
    },
    {
      epoch: '1772 – 1911 CE',
      title: 'Imperial Capital of British India & Bengal Renaissance',
      description: 'Calcutta serves as the supreme capital of British India. Intellectual awakening under Raja Ram Mohan Roy, Vidyasagar, Swami Vivekananda, and Rabindranath Tagore sparks modern Indian literature and science.',
      keySites: ['Victoria Memorial', 'St. Paul’s Cathedral', 'Jorasanko Thakurbari', 'College Street']
    },
    {
      epoch: 'Post-1911 & Independence',
      title: 'City of Joy & Democratic Consciousness',
      description: 'The capital moves to Delhi in 1911, but Kolkata retains its position as India’s cultural soul, leading independent cinema (Satyajit Ray, Ritwik Ghatak) and literary discourse.',
      keySites: ['Howrah Bridge', 'Nandan Cinema Complex', 'Coffee House']
    }
  ],

  architecturalHeritageOverview: 'Kolkata possesses India’s densest ensemble of European neoclassical and Palladian colonial architecture, distinguished by Corinthian columns, green-louvered wooden shutters (khorkhori), decorative cast-iron balconies, and vast inner residential courtyards (thakur-dalan).',

  traditionsAndFestivals: [
    {
      title: 'Kolkata Durga Puja (UNESCO Intangible Heritage)',
      seasonOrFrequency: 'Ashwin month (September – October, 5 days)',
      description: 'The world’s largest public art installation and carnival. Over 3,000 neighborhood pandals showcase magnificent temporary architectural pavilions, ranging from recreated Louvre halls to traditional rural temples, where millions stroll through the night (pandal-hopping) amidst the beats of the dhak drum.',
      visitorEtiquette: 'Carry comfortable walking shoes; travel by metro which operates 24 hours during the festival; savor street food at community pandals.'
    },
    {
      title: 'The Adda (Bengali Intellectual Salon)',
      seasonOrFrequency: 'Daily informal cultural practice',
      description: 'The UNESCO-recognized intangible ritual of unhurried, informal, free-flowing conversation among friends over cups of tea or coffee, spanning politics, poetry, cinema, and world philosophy.',
      visitorEtiquette: 'Pull up a chair at Indian Coffee House or a local roadside cha dokan; respectful listeners and curious debaters are warmly welcomed.'
    }
  ],

  dishes: [
    {
      id: 'kol-kathi-roll',
      name: 'Original Nizam’s Mutton Kathi Roll',
      localName: 'নিজামের কাঠি রোল',
      culturalOrigin: 'Created in 1932 at Nizam Restaurant in New Market to allow hurried British office workers to eat kebabs on the go.',
      description: 'Succulent chunks of spiced mutton or chicken kebab grilled on iron skewers (kathi), wrapped inside a flaky, golden, layered parotta fried on a tawa with an egg, drizzled with freshly squeezed lime juice, thinly sliced red onions, green chillies, and a pinch of black salt (chaat masala), with no synthetic ketchup or mayonnaise.',
      typicalIngredients: ['Skewer-grilled mutton/chicken', 'Egg-layered parotta', 'Sliced red onions', 'Green chillies', 'Lemon juice', 'Chaat masala'],
      isVeg: false,
      whereToFind: 'Nizam’s (New Market, Hogg Street), Kusum Rolls (Park Street), Hot Kati Rolls (Park Street).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Non-vegetarian. Paneer and potato versions are also prepared for vegetarians.',
      etiquetteTips: 'Eat it hot while walking through the bustling market lanes, holding the paper wrapper tightly.',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'kol-puchka',
      name: 'Kolkata Puchka',
      localName: 'কলকাতার ফুচকা',
      culturalOrigin: 'The street food pride of Kolkata, distinct from north Indian golgappas or western pani puris.',
      description: 'Crisp, ultra-thin semolina-flour puris punctured and filled with a spicy, warm filling of mashed boiled potatoes, black chickpeas, roasted cumin, rock salt, and fiery green chilli paste, plunged into a bowl of ice-cold, tart tamarind water steeped with fragrant Gondhoraj lime juice and mint leaves.',
      typicalIngredients: ['Crisp round puris', 'Mashed spiced potato', 'Kala chana (black chickpeas)', 'Gondhoraj lime tamarind water', 'Fresh coriander'],
      isVeg: true,
      whereToFind: 'Dilipda’s Puchka (Vivekananda Park), Dakshinapan shopping complex, Russell Street corner.',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian and vegan. At reputable stalls, confirm the use of packaged drinking water.',
      etiquetteTips: 'Eat the whole puchka in one single bite to experience the explosive burst of tart lime water and spicy potato.',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'kol-mishti-doi-rosogolla',
      name: 'Baked Mishti Doi & Nolen Gur Rosogolla',
      localName: 'মিষ্টি দই এবং রসগোল্লা',
      culturalOrigin: 'Refined in 1868 by Nobin Chandra Das in Bagbazar, revolutionizing Indian dairy confectionery.',
      description: 'Mishti Doi is dense, creamy yogurt set in porous earthen clay pots (kullad) that absorb excess moisture, sweetened with caramelized sugarcane jaggery or date-palm jaggery (Nolen Gur). Paired with spongy, hot cottage-cheese (chhena) dumplings cooked in delicate date-palm syrup that melt into sweet nectar on the palate.',
      typicalIngredients: ['Fermented full-cream curd', 'Caramelized milk', 'Nolen Gur (date-palm jaggery)', 'Chhena (fresh cottage cheese)'],
      isVeg: true,
      whereToFind: 'K.C. Das (Esplanade), Balaram Mullick & Radharaman Mullick (Bhowanipore), Girish Chandra Dey & Nakur Chandra Nandy (Hatibagan).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Dairy heavy. Nolen Gur varieties are seasonal and available primarily from November to February.',
      etiquetteTips: 'Always eat Mishti Doi with the small flat wooden spoon directly from the porous terracotta earthen pot.',
      image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Park Street & Free School Street',
      character: 'The historic dining and nightlife boulevard of Kolkata, home to legendary Anglo-Indian tearooms, continental dining, and jazz clubs.',
      bestTime: 'Lunch (12:30 PM – 3:30 PM) and Dinner (7:00 PM – 11:30 PM).',
      highlights: ['Chelo kebab at Peter Cat', 'Continental chicken steak at Mocambo', 'Pastries at Flurys'],
      visitorAdvice: 'Expect weekend dinner waits of 30–60 minutes at Peter Cat; no reservations accepted on Friday/Saturday evenings.'
    },
    {
      name: 'North Kolkata Heritage Lanes (Hatibagan & Shyambazar)',
      character: 'Traditional residential quarters famed for century-old sweetshops, telebhaja (crispy fritters), and Kosha Mangsho.',
      bestTime: 'Morning 8:00 AM – 11:00 AM and Evening 5:00 PM – 8:30 PM.',
      highlights: ['Kosha Mangsho and luchi at Golbari', 'Sandesh at Nakur Nandy', 'Fuchka at Hatibagan crossing'],
      visitorAdvice: 'Take the Blue Line Metro to Shyambazar or Sovabazar and explore on foot or by hand-pulled rickshaw.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Kolkata is widely considered one of the safest metropolitan cities in India for solo and family travelers, with a gentle, polite civic culture.',
      'During monsoon season (July – September), heavy tropical cloudbursts can cause temporary waterlogging in low-lying parts of North and Central Kolkata; check local metro transit.',
      'Summers from April to June are humid; carry a light cotton scarf and drink water.'
    ],
    transportPedestrian: [
      'Kolkata Metro (India’s first underground transit system, opened in 1984) is fast, reliable, and connects North and South directly. The new underwater Green Line connects Howrah to Esplanade beneath the river.',
      'Iconic yellow Ambassador taxis operate on mechanical or digital meters; drivers are generally courteous, but clarify the destination before boarding.',
      'Historic electric trams run along select heritage routes; a charming, slow, nostalgic way to see the city.'
    ],
    nightTravel: [
      'Park Street, Camac Street, and Southern Avenue are active, well-lit, and very safe for evening dining.',
      'App-based cabs (Uber, Ola, Yatri Sathi) operate reliably round the clock.'
    ],
    accessibilityNotes: [
      'Newly built Kolkata Metro Green Line stations feature full step-free accessibility, lifts, and tactile guiding paths.',
      'North Kolkata’s historic footpaths feature occasional open gutters and uneven paving that require care.'
    ],
    emergencyContacts: [
      { title: 'Kolkata Police Emergency', number: '112 / 100', note: 'Unified 24/7 emergency line' },
      { title: 'Women Police Helpline', number: '1091', note: 'Dedicated Women Safety Division' },
      { title: 'Medical Emergency Ambulance', number: '102 / 108', note: 'State health service' },
      { title: 'SSKM Government Hospital Emergency', number: '033 2223 1589', note: 'Premier tertiary care hospital' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Kolkata Police Commissionerate notifications and West Bengal Tourism Development Corporation guidelines.'
  },

  neighbourhoods: [
    {
      id: 'kol-north-heritage',
      name: 'North Kolkata: Sovabazar & Shyambazar',
      cityId: 'kolkata',
      character: 'The aristocratic 18th-century cultural heart, filled with grand rajbari palaces, clay idol studios, historic sweet shops, and winding alleys.',
      budgetTier: 'Budget-friendly',
      transitScore: 'Very High (Sovabazar Sutanuti & Shyambazar metro stations, circular railway)',
      transitDetails: 'Direct Blue Line Metro access; hand-pulled rickshaws and walking within the lanes.',
      walkabilityRating: 'High for curious walkers; narrow lanes with historic facades and low car traffic.',
      accessibilityNotes: 'Older streets have narrow sidewalks and occasional open drains; careful stepping required.',
      heritageHighlights: ['Sovabazar Rajbari', 'Kumartuli Idol Quarter', 'Jorasanko Thakurbari (Tagore’s House)', 'Marble Palace'],
      foodHighlights: ['Golbari', 'Nakur Chandra Nandy', 'Mitra Cafe'],
      greenSpaceNotes: 'Ghats along the Hooghly river provide scenic open air.',
      safetyContext: 'High social safety due to tight-knit residential communities and continuous street presence.',
      methodologyNote: 'Evaluated using urban architectural conservation surveys and cultural heritage density data.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'kol-south-ballygunge',
      name: 'South Kolkata: Ballygunge & Southern Avenue',
      cityId: 'kolkata',
      character: 'Leafy, cosmopolitan residential enclave centered around the Rabindra Sarobar lakes, contemporary art galleries, indie cafes, and bookstores.',
      budgetTier: 'Moderate to Upscale',
      transitScore: 'Very High (Kalighat and Rabindra Sarobar metro stations)',
      transitDetails: 'Direct Blue Line Metro; wide roads and plentiful yellow cabs.',
      walkabilityRating: 'Very High (Broad, shaded tree-lined sidewalks around the lakes and Southern Avenue).',
      accessibilityNotes: 'Continuous footpaths with gentle curb cuts around Rabindra Sarobar lakes.',
      heritageHighlights: ['Birla Academy of Art & Culture', 'Kalighat Temple', 'Gariahat Market'],
      foodHighlights: ['6 Ballygunge Place (authentic Bengali thali)', 'Flurys outlet', 'Dolly’s The Tea Shop'],
      greenSpaceNotes: 'Rabindra Sarobar (Dhakuria Lake) spans 192 acres of water and wooded park, a haven for migratory birds.',
      safetyContext: 'One of Kolkata’s most peaceful and secure residential districts.',
      methodologyNote: 'Based on lake ecology preservation metrics and residential lifestyle amenities.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-kol-coffee-house-adda',
      cityId: 'kolkata',
      title: 'The Great Coffee House Adda: Where India’s Freedom & Cinema Were Born',
      preview: 'Inside the smoky high-ceilinged hall on College Street where Amartya Sen, Satyajit Ray, and freedom fighters debated the fate of nations over three-rupee coffee.',
      fullArticle: 'To understand Kolkata is to understand the adda: the art of unhurried, passionate intellectual debate that costs nothing and produces revolutions. Nowhere is this more sacred than inside the Indian Coffee House at 15 Bankim Chatterjee Street. Opened in 1876 as Albert Hall, the building hosted early meetings of the Indian National Congress where Surendranath Banerjee campaigned against British partition. Decades later, film visionary Satyajit Ray sketched storyboards for Pather Panchali here; Nobel laureate Amartya Sen argued welfare economics with his student peers; and legendary poet Sunil Gangopadhyay launched the "Hungry Generation" literary movement. Beneath whirring 19th-century ceiling fans, waiters dressed in white uniforms and royal turbans still navigate between tables where university students and silver-haired professors argue about literature, politics, and the cosmos, proving that ideas remain Kolkata’s truest currency.',
      locationName: 'College Street, Bankim Chatterjee Street',
      factualExplanation: 'Documented in historical memoirs of the Bengal Renaissance and preserved in Calcutta Heritage Collective archives.',
      sources: ['Calcutta: The Living City by Sukanta Chaudhuri', 'Indian Coffee House Cooperative Society Records'],
      relatedDestinationIds: ['kol-college-street'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Historic wooden cafe and books in Kolkata'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '13°C – 26°C', advice: 'Magical travel season; sunny mild days, cool evenings, book fairs, and classical music soirees. Highly recommended.' },
      { season: 'Monsoon (Jun – Sep)', temperatureRange: '26°C – 32°C', advice: 'Heavy tropical delta rains; dramatic Hooghly cloudscapes. Check local news during cyclonic depressions in the Bay of Bengal.' },
      { season: 'Summer (Mar – May)', temperatureRange: '27°C – 39°C', advice: 'Warm and humid, punctuated by dramatic late-afternoon thunderstorms (Kalbaishakhi).' }
    ],
    transportInfrastructure: [
      { mode: 'Kolkata Metro', coverage: 'Blue Line (North-South) and new Green Line (underwater underwater Hooghly tunnel)', tip: 'World-class; takes under a minute to cross under the river between Howrah and Kolkata.' },
      { mode: 'Yellow Ambassador Taxis', coverage: 'Everywhere on street corners', tip: 'Classic, spacious, and quintessentially Kolkata. Insist on meter or negotiate reasonably.' },
      { mode: 'Hooghly River Ferries', coverage: 'Dozens of ghats connecting Kolkata and Howrah banks', tip: 'Unmatched river views for ₹6; great way to avoid road bridge bottlenecks.' }
    ],
    environmentalNotes: 'The Hooghly river and the vast East Kolkata Wetlands (a Ramsar site that naturally treats the city’s sewage through fish ponds) form vital ecological life-support systems.',
    dataAttribution: 'West Bengal Tourism Development Corporation & Kolkata Municipal Corporation'
  }
};
