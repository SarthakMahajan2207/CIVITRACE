import React, { useState } from 'react';
import {
  Compass,
  MapPin,
  BookOpen,
  ArrowRight,
  Sparkles,
  Layers,
  UtensilsCrossed,
  ShieldCheck,
  Search
} from 'lucide-react';
import { City } from '../types';

interface HeroSectionProps {
  city: City;
  onExploreClick: () => void;
  onStoriesClick: () => void;
  onOpenCitySelector: () => void;
  onSearchSubmit: (query: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  city,
  onExploreClick,
  onStoriesClick,
  onOpenCitySelector,
  onSearchSubmit,
}) => {
  const [heroSearchInput, setHeroSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearchInput.trim()) {
      onSearchSubmit(heroSearchInput.trim());
    } else {
      onExploreClick();
    }
  };

  const suggestionKeywords = [
    'History & Heritage',
    'Architecture',
    'Local Food',
    'Sacred Sites',
    'Photography'
  ];

  return (
    <section id="hero" className="relative min-h-[85vh] sm:min-h-[88vh] flex items-center justify-center overflow-hidden bg-[#0a0e17]">
      {/* Background Image with Cinematic Dark Gradient Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src={city.heroImage}
          alt={city.imageAlt}
          className="w-full h-full object-cover object-center scale-105 animate-in fade-in zoom-in-105 duration-1000 brightness-75 contrast-110"
        />
        {/* Multi-layered cinematic gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e17] via-[#0a0e17]/75 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0e17]/90 via-[#0a0e17]/60 to-transparent" />
        <div className="absolute inset-0 bg-radial-at-c from-transparent via-[#0a0e17]/40 to-[#0a0e17]/95" />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 flex flex-col items-start justify-center">
        {/* City Badge & Region */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-md border border-amber-500/40 text-amber-200 text-xs sm:text-sm font-medium mb-4 sm:mb-6 shadow-lg shadow-black/50">
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-semibold">{city.region}</span>
          <span className="text-slate-400">•</span>
          <span className="text-slate-300">{city.state}</span>
          <button
            onClick={onOpenCitySelector}
            className="ml-2 pl-2 border-l border-slate-700 text-amber-400 hover:text-amber-300 text-[11px] underline underline-offset-2 flex items-center gap-1"
          >
            Switch City <ArrowRight className="w-2.5 h-2.5" />
          </button>
        </div>

        {/* Hero Title */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-editorial font-bold tracking-tight text-white max-w-4xl leading-[1.1] text-balance">
          {city.name}
        </h1>

        {/* Tagline */}
        <p className="text-lg sm:text-2xl font-editorial italic text-amber-200/90 font-medium mt-2 sm:mt-3 max-w-3xl">
          "{city.tagline}"
        </p>

        {/* Factually Grounded Intro Sentence */}
        <p className="text-sm sm:text-lg text-slate-200 font-sans mt-4 max-w-2xl leading-relaxed text-balance">
          {city.heroDescription}
        </p>

        {/* Quick Intelligence Stats Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-4 my-6 sm:my-8 w-full max-w-2xl">
          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-left">
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold mb-0.5">
              <Compass className="w-3.5 h-3.5" />
              <span>{city.destinations.length} Places</span>
            </div>
            <p className="text-[11px] text-slate-400">Verified cultural sites</p>
          </div>

          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-left">
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold mb-0.5">
              <Layers className="w-3.5 h-3.5" />
              <span>{city.heritagePeriods.length} Epochs</span>
            </div>
            <p className="text-[11px] text-slate-400">Chronological history</p>
          </div>

          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-left">
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold mb-0.5">
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>{city.dishes.length} Regional Dishes</span>
            </div>
            <p className="text-[11px] text-slate-400">Culinary institutions</p>
          </div>

          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-left">
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold mb-0.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{city.neighbourhoods.length} Districts</span>
            </div>
            <p className="text-[11px] text-slate-400">Comparative metrics</p>
          </div>
        </div>

        {/* Hero Interactive Search Bar */}
        <form onSubmit={handleSearchSubmit} className="w-full max-w-xl mb-4 sm:mb-6">
          <div className="relative flex items-center">
            <Search className="absolute left-4 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={heroSearchInput}
              onChange={(e) => setHeroSearchInput(e.target.value)}
              placeholder={`Search ${city.name} destinations, street food, or history...`}
              className="w-full pl-11 pr-28 py-3.5 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700/90 text-white placeholder-slate-400 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 shadow-xl transition-all"
            />
            <button
              type="submit"
              className="absolute right-2 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow-md transition-all"
            >
              Search
            </button>
          </div>

          {/* Quick Suggestion Chips */}
          <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto text-[11px] scrollbar-none">
            <span className="text-slate-400 shrink-0">Popular:</span>
            {suggestionKeywords.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => onSearchSubmit(tag)}
                className="px-2 py-0.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors whitespace-nowrap"
              >
                {tag}
              </button>
            ))}
          </div>
        </form>

        {/* Primary CTA Buttons */}
        <div className="flex flex-wrap items-center gap-3 sm:gap-4">
          <button
            onClick={onExploreClick}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold text-sm sm:text-base shadow-lg shadow-amber-950/50 hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            <Compass className="w-4 h-4" />
            <span>Explore {city.name}</span>
          </button>

          <button
            onClick={onStoriesClick}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900/80 backdrop-blur-md hover:bg-slate-800 border border-slate-700/90 text-slate-200 hover:text-white font-medium text-sm sm:text-base shadow-md transition-all"
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span>Discover City Stories ({city.stories.length})</span>
          </button>

          <button
            onClick={onOpenCitySelector}
            className="flex items-center gap-1.5 px-4 py-3 rounded-xl text-slate-300 hover:text-white text-sm font-medium hover:underline transition-colors"
          >
            <span>Browse all 12 cities</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Photography Attribution */}
      <div className="absolute bottom-3 right-4 z-10 text-[10px] text-slate-500 hidden sm:block">
        Photo: {city.imageCredit}
      </div>
    </section>
  );
};
