import React, { useState, useMemo } from 'react';
import {
  Compass,
  Search,
  Filter,
  SlidersHorizontal,
  Landmark,
  Building,
  Trees,
  Utensils,
  Palette,
  Sparkles,
  Camera,
  X
} from 'lucide-react';
import { Destination, CategoryType } from '../types';
import { DestinationCard } from './DestinationCard';

interface ExploreSectionProps {
  destinations: Destination[];
  cityName: string;
  onOpenDetails: (destination: Destination) => void;
  savedDestinationIds: string[];
  onToggleSave: (destinationId: string) => void;
  initialCategory?: CategoryType;
  initialSearchQuery?: string;
}

export const ExploreSection: React.FC<ExploreSectionProps> = ({
  destinations,
  cityName,
  onOpenDetails,
  savedDestinationIds,
  onToggleSave,
  initialCategory = 'All',
  initialSearchQuery = '',
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [sortBy, setSortBy] = useState<'featured' | 'alphabetical' | 'duration'>('featured');

  const categories: { label: CategoryType; icon: React.FC<{ className?: string }> }[] = [
    { label: 'All', icon: Compass },
    { label: 'History & Heritage', icon: Landmark },
    { label: 'Architecture', icon: Building },
    { label: 'Nature & Outdoors', icon: Trees },
    { label: 'Local Food & Markets', icon: Utensils },
    { label: 'Art & Museums', icon: Palette },
    { label: 'Spiritual & Sacred', icon: Sparkles },
    { label: 'Photography', icon: Camera },
  ];

  const filteredDestinations = useMemo(() => {
    return destinations
      .filter((dest) => {
        const matchesCategory =
          selectedCategory === 'All' || dest.category === selectedCategory;

        const matchesQuery =
          dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dest.shortSummary.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dest.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dest.category.toLowerCase().includes(searchQuery.toLowerCase());

        return matchesCategory && matchesQuery;
      })
      .sort((a, b) => {
        if (sortBy === 'alphabetical') {
          return a.name.localeCompare(b.name);
        }
        if (sortBy === 'duration') {
          return a.suggestedDuration.localeCompare(b.suggestedDuration);
        }
        return 0; // default featured order
      });
  }, [destinations, selectedCategory, searchQuery, sortBy]);

  return (
    <section id="explore" className="py-16 sm:py-24 bg-[#0a0e17] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 sm:mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
              <Compass className="w-4 h-4" />
              <span>Cultural Discoveries</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
              Featured Places in {cityName}
            </h2>
            <p className="text-sm sm:text-base text-slate-400 mt-2 max-w-2xl">
              Curated architectural monuments, sacred landmarks, botanical sanctuaries, and living markets accompanied by deep historical and visitor intelligence.
            </p>
          </div>

          <div className="text-xs text-slate-400 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 shrink-0 self-start md:self-auto">
            Showing <span className="font-bold text-white">{filteredDestinations.length}</span> of {destinations.length} destinations
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="space-y-4 mb-8 sm:mb-10">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.label;
              return (
                <button
                  key={cat.label}
                  onClick={() => setSelectedCategory(cat.label)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all shadow-xs ${
                    isSelected
                      ? 'bg-amber-600 text-amber-50 border border-amber-500 shadow-md shadow-amber-950/40'
                      : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-850 border border-slate-800'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-100' : 'text-slate-400'}`} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search & Sort Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <div className="relative w-full sm:max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={`Search ${cityName} places by name, category, or area...`}
                className="w-full pl-10 pr-9 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-400 text-xs sm:text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto text-xs">
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-400">Sort:</span>
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 focus:outline-none focus:border-amber-500 text-xs"
              >
                <option value="featured">Featured Order</option>
                <option value="alphabetical">Alphabetical (A–Z)</option>
                <option value="duration">Visit Duration</option>
              </select>
            </div>
          </div>
        </div>

        {/* Destination Cards Grid */}
        {filteredDestinations.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredDestinations.map((dest) => (
              <DestinationCard
                key={dest.id}
                destination={dest}
                onOpenDetails={onOpenDetails}
                isSaved={savedDestinationIds.includes(dest.id)}
                onToggleSave={onToggleSave}
              />
            ))}
          </div>
        ) : (
          <div className="py-16 text-center rounded-2xl border border-slate-800 bg-slate-900/40 p-8">
            <Compass className="w-10 h-10 mx-auto text-slate-600 mb-3" />
            <h3 className="text-lg font-editorial font-bold text-slate-300">No destinations found</h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-md mx-auto">
              No places in {cityName} match your search query or selected interest filter.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold border border-slate-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
