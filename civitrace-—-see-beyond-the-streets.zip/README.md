# CIVITRACE — See Beyond the Streets

CIVITRACE is a full-stack, cinematic city-exploration and cultural intelligence web application built for travelers, students, residents, and solo explorers. Designed with an editorial aesthetic inspired by high-end travel journalism and cartography, it provides deeply researched, fact-grounded guides for **12 Indian cultural capitals**:

1. **Pune** — Oxford of the East & Citadel of the Peshwas
2. **Mumbai** — Urbs Prima in Indis & Maximum City of the Arabian Sea
3. **Bengaluru** — The Garden City turned Silicon Crucible of India
4. **Delhi** — Palimpsest of Empires & Seven Historic Citadels
5. **Jaipur** — The Planned Pink City & Rajput Astronomical Capital
6. **Goa** — Indo-Portuguese Maritime Crossroads & Konkan Heartland (Old & New Conquests)
7. **Chennai** — Gateway of South India & Classical Cultural Citadel
8. **Hyderabad** — City of Pearls & Sultanate Diamond Capital
9. **Kolkata** — City of Joy & The Intellectual Renaissance Hub
10. **Kochi** — Queen of the Arabian Sea & Maritime Spice Crossroads
11. **Varanasi** — Kashi: The City of Light & Oldest Living Sacred Center
12. **Ahmedabad** — India’s First UNESCO World Heritage City & Cradle of Ahimsa

---

## Key Features

### 1. Cultural Discoveries & Architectural Dossiers
- Comprehensive 150–250 word architectural, historical, and experiential dossiers for every featured destination.
- Sourced admission fees, opening hours, verified dates, and direct links to official authorities (Archaeological Survey of India, UNESCO, State Tourism boards).
- Practical visitor tips, best times of day, photography regulations, accessibility assessments, family suitability, and public transit navigation advice.
- Suggested nearby combinations for grouping destinations into coherent itineraries.

### 2. Heritage & Living Lineage
- Chronological historical epochs detailing sovereign transitions from ancient dynasties to the contemporary era.
- Architectural synthesis explaining regional building typologies (Deccan wadas, Dravidian gopurams, Indo-Portuguese balcãos, Sultanate stepwells).
- Living traditions and festivals accompanied by respectful visitor etiquette.
- **Fact vs. Folklore Disclosure**: Clearly distinguishes archaeological consensus from local legends and contested oral histories.

### 3. Gastronomic Lineage & Local Life
- Deep dives into iconic regional dishes with cultural origins, typical ingredients, vegetarian/non-vegetarian identification, dietary considerations, and iconic generational institutions.
- Dedicated guides to historic food streets and market districts with visiting hour advice.

### 4. Safety & Responsible Exploration
- Practical precautions covering climate, transit, pedestrian crossings, and night-time planning.
- Official emergency numbers (Police 112, Women Helplines, Tourist Police, Medical Trauma centers).
- **Transparent Data Limitations**: No fabricated crime scores or arbitrary danger ratings.
- **Community Observations**: Interactive reporting tool with transparent verification states (*Verified by civic/editorial source*, *Under review*, *Unverified community report*).

### 5. Neighbourhood Comparison Tool
- Side-by-side comparison matrix across visitor budget, public transit availability, walkability, accessibility, heritage density, and green spaces.
- Methodology, source definition, and known limitations modals for every single metric.

### 6. City Intelligence & Environmental Disclosures
- Seasonal climatology from India Meteorological Department (IMD) historical records.
- Public transit network maps and airport connectivity guides.
- Geolocation Proximity Tool: Explicitly requests user permission before calculating distance to the closest cultural nodes.

### 7. Interactive OpenStreetMap Cartography
- Usable Leaflet map powered by OpenStreetMap & Carto tiles.
- Interactive category-filtered marker pins with rich popups.
- Geodesic route distance calculation and turn-by-turn Google Maps navigation links.

### 8. Pulse AI — City Intelligence Assistant
- Powered by the Google Gemini API (`gemini-3.8-flash`) through a secure server-side Express backend.
- Intelligently grounded in the active city's verified historical and cultural datasets.
- Transparent fallback engine providing structured local city intelligence when an API key is not configured.

---

## Technical Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Motion, Lucide React
- **Mapping**: Leaflet with Carto Voyager & OpenStreetMap tiles
- **Backend**: Express on Node.js (via `tsx server.ts`)
- **AI Integration**: `@google/genai` TypeScript SDK with server-side proxy route `/api/gemini/chat`
- **Build Tool**: Vite 8

---

## Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Set your Gemini API key (optional — full grounded local fallback is active by default):
```env
GEMINI_API_KEY="your-gemini-api-key"
PORT=3000
```

### 3. Run the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Build for Production
```bash
npm run build
npm start
```

---

## Data Quality & Editorial Attribution

- **Archaeological & Historical Data**: Archaeological Survey of India (ASI) & State Departments of Archaeology.
- **World Heritage Sites**: UNESCO World Heritage Centre Inscription Dossiers.
- **Climatological Data**: India Meteorological Department (IMD) Climatological Normals.
- **Civic Transport**: State Road Transport Corporations, Regional Metro Rail Corporations, and Municipal Corporations.
- **Integrity Guarantee**: CIVITRACE does not fabricate prices, real-time traffic jams, or artificial safety indices. All reflections are labeled as editorial content.
