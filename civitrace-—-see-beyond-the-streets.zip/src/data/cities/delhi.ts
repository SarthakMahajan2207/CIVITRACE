import { City } from '../../types';

export const delhiData: City = {
  id: 'delhi',
  name: 'Delhi',
  state: 'National Capital Territory',
  region: 'Indo-Gangetic Plains & Aravalli Ridge',
  tagline: 'Palimpsest of Empires & Seven Historic Citadels',
  heroDescription: 'Straddling the Yamuna river and the prehistoric Aravalli ridge, Delhi is an imperial palimpsest where seven historic citadels lie stacked atop one another. From 12th-century Sultanate minarets and sublime Mughal garden tombs to broad British Lutyens boulevards and bustling walled-city bazaars, Delhi bears witness to a thousand years of sovereign power.',
  introSentence: 'An ancient imperial capital where medieval sandstone bastions, Sufi shrines, and broad colonial avenues echo with the rise and fall of dynasties.',
  coordinates: [28.6139, 77.2090],
  accentColor: 'rose',
  hexAccent: '#e11d48',
  heroImage: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Humayun’s Tomb red sandstone and marble dome in Delhi',
  imageCredit: 'Unsplash / Archaeological Survey of India Archive',
  heritageThemes: ['Seven Historic Cities of Delhi', 'Mughal Imperial Architecture', 'Delhi Sultanate Fortresses', 'Sufi Sanctuary & Dargahs', 'Post-Partition Culinary Resurgence'],

  destinations: [
    {
      id: 'delhi-humayun-tomb',
      name: 'Humayun’s Tomb & Sunder Nursery',
      cityId: 'delhi',
      category: 'History & Heritage',
      shortSummary: 'UNESCO World Heritage 1570 garden tomb that served as the architectural prototype for the Taj Mahal.',
      fullDescription: 'Commissioned in 1565 by Empress Bega Begum (Haji Begum) for her husband, the second Mughal Emperor Humayun, this monumental red sandstone and white marble mausoleum is the earliest surviving example of Mughal charbagh (four-fold paradise garden) architecture in India. Designed by Persian architect Mirak Mirza Ghiyas, the tomb sits atop a high terraced plinth, crowned by a double dome of pure white marble reaching 42 metres in height. Geometric water channels represent the four rivers of paradise mentioned in the Quran. Adjoining the tomb is Sunder Nursery—a meticulously restored 90-acre heritage ecological park containing over a dozen 16th-century monuments, sunken amphitheaters, and 300 tree species.',
      historicalBackground: 'Completed in 1572. It later served as the refuge of Bahadur Shah Zafar, the last Mughal emperor, before his capture by British forces during the 1857 Uprising.',
      culturalSignificance: 'The architectural breakthrough that synthesized Persian symmetry with indigenous Rajasthani jali stonework, paving the way for the Taj Mahal.',
      architecturalFeatures: 'Symmetrical Persian double dome, recessed arch iwans, red sandstone inlaid with white marble borders, octagonal chamber geometry, and gravity-fed charbagh canals.',
      whyWorthVisiting: 'A tranquil, impeccably restored masterpiece of world architecture paired with Delhi’s most beautiful heritage ecological park.',
      whatToExperience: 'Walk along the paradise garden watercourses, climb the terraced plinth into the central octagonal cenotaph chamber, and explore the artisan craft stalls at Sunder Nursery on weekends.',
      location: 'Mathura Road, Nizamuddin East, New Delhi 110013',
      coordinates: [28.5933, 77.2507],
      suggestedDuration: '2.5 to 3 hours',
      bestTimeToVisit: 'Late afternoon (3:30 PM – 6:00 PM) when the setting sun turns the red sandstone a radiant vermilion.',
      entryFeeInfo: 'Humayun’s Tomb: ₹40 for Indian citizens, ₹600 for foreign visitors; Sunder Nursery: ₹50 for adults.',
      openingHoursInfo: 'Open daily: Sunrise to Sunset (approx. 6:00 AM – 6:00 PM).',
      accessibilityInfo: 'Terraced plinth has ramps on the eastern side; Sunder Nursery pathways are fully wheelchair and stroller accessible with level stone paving.',
      familySuitability: 'Exceptional for families, landscape photographers, and history travelers.',
      photographyNotes: 'Reflections of the dome in the charbagh water channels; soft golden hour light through carved marble jali screens.',
      nearbyCombinations: ['Hazrat Nizamuddin Dargah', 'Isa Khan’s Tomb', 'National Crafts Museum'],
      transitAdvice: 'JLN Stadium Metro Station (Violet Line) is 1.5 km away. Sarai Kale Khan / Hazrat Nizamuddin Metro (Pink Line) is 2 km.',
      visitorTips: ['Combine your visit with Thursday evening Sufi Qawwali at the nearby Hazrat Nizamuddin Dargah.', 'Purchase a combined ticket if exploring both Humayun’s Tomb and Isa Khan’s tomb on the same morning.'],
      officialLinks: [{ title: 'Aga Khan Trust for Culture — Nizamuddin Urban Renewal', url: 'https://www.akdn.org' }],
      sourceNote: 'UNESCO World Heritage Centre & Aga Khan Trust for Culture Restoration Reports.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Symmetrical sandstone facade and white marble dome of Humayun’s Tomb',
      imageCredit: 'Unsplash'
    },
    {
      id: 'delhi-qutb-minar',
      name: 'Qutb Minar & Mehrauli Archaeological Complex',
      cityId: 'delhi',
      category: 'History & Heritage',
      shortSummary: 'UNESCO World Heritage 72.5-metre brick minaret erected in 1192 alongside a 1,600-year-old rust-resistant iron pillar.',
      fullDescription: 'Rising 72.5 metres into the Delhi sky, the Qutb Minar is the tallest brick minaret in the world and the founding monument of the Delhi Sultanate. Commenced in 1192 by Qutb-ud-din Aibak to mark the victory of the Ghurid forces over Prithviraj Chauhan and completed by Sultan Iltutmish, the fluted tower features five distinct tapering storeys adorned with intricate calligraphic bands in Kufic script and elaborately carved stalactite corbels. Within the surrounding Quwwat-ul-Islam mosque courtyard stands the celebrated 4th-century Gupta-era Iron Pillar: a 7.2-metre metallurgical wonder of pure wrought iron that has resisted corrosion for over 1,600 years without showing a trace of rust.',
      historicalBackground: 'The nucleus of the first of Delhi’s seven historic cities (Qila Rai Pithora / Mehrauli). Inscribed as a UNESCO World Heritage site in 1993.',
      culturalSignificance: 'Represents the transition from Hindu-Chauhan sovereignty to Sultanate rule, utilizing reused stone pillars from earlier temples to create an entirely novel Indo-Islamic idiom.',
      architecturalFeatures: 'Alternating angular and rounded flutings in red and buff sandstone; projecting balconies supported by stalactite stone brackets; Arabic epigraphy.',
      whyWorthVisiting: 'Encounter nine centuries of continuous architectural evolution and observe one of the greatest metallurgical mysteries of ancient science.',
      whatToExperience: 'Walk through the colonnades of Quwwat-ul-Islam Mosque, inspect the Gupta Iron Pillar up close, view the tomb of Sultan Iltutmish with its squinch arches, and photograph the unfinished Alai Minar.',
      location: 'Mehrauli, Southwest Delhi 110030',
      coordinates: [28.5245, 77.1855],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Morning (8:30 AM – 11:00 AM) or after 4:00 PM to avoid intense daytime glare.',
      entryFeeInfo: '₹40 for Indian citizens, ₹600 for foreign visitors (ASI digital ticketing available at gate via QR code).',
      openingHoursInfo: 'Open daily: 7:00 AM – 9:00 PM (monuments are dramatically floodlit after dark).',
      accessibilityInfo: 'Paved ramps throughout the archaeological park provide good wheelchair access across the main ruins.',
      familySuitability: 'Excellent for all ages; open park setting with ancient trees and green lawns.',
      photographyNotes: 'Stunning night illumination; upward-angled shots capturing the tapering balconies against the sky.',
      nearbyCombinations: ['Mehrauli Archaeological Park', 'Jamali Kamali Mosque', 'Zafar Mahal'],
      transitAdvice: 'Qutab Minar Metro Station (Yellow Line) is 1.2 km away; frequent electric feeder autos run to the ticket counter.',
      visitorTips: ['Cross the road afterwards into the Mehrauli Archaeological Park for quiet, uncrowded tombs hidden in thorny woodland.', 'Buy tickets online via the ASI portal to bypass weekend queue lines.'],
      officialLinks: [{ title: 'UNESCO World Heritage — Qutb Minar Complex', url: 'https://whc.unesco.org/en/list/233' }],
      sourceNote: 'Archaeological Survey of India Delhi Circle Dossier.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Tapering red sandstone tower of Qutb Minar reaching into the sky',
      imageCredit: 'Unsplash'
    },
    {
      id: 'delhi-chandni-chowk',
      name: 'Old Delhi (Shahjahanabad) & Chandni Chowk',
      cityId: 'delhi',
      category: 'Local Food & Markets',
      shortSummary: 'The walled 17th-century Mughal capital of Emperor Shah Jahan, bustling with historic havelis and street food.',
      fullDescription: 'Founded in 1648 by Mughal Emperor Shah Jahan and designed by his daughter Princess Jahanara, Shahjahanabad is the living sensory soul of historic northern India. Its main grand avenue, Chandni Chowk ("Moonlight Square"), once featured a central reflecting canal that caught the moon’s reflection. Today, newly pedestrianized with red sandstone cobbles, the street is an astonishing crossroads of faiths and flavors. Anchored by the red sandstone Jama Masjid—India’s largest historic mosque—the surrounding katras (specialized trading lanes) include Dariba Kalan for silver jewellery, Khari Baoli (Asia’s largest wholesale spice market), and Kinari Bazaar for wedding lace. Century-old food stalls serve slow-simmered nihari, piping hot paranthas, and crisp jalebis.',
      historicalBackground: 'Served as the Mughal imperial capital from 1648 until the fall of the empire in 1857. Survived the 1857 siege and the 1947 Partition with rich syncretic memories intact.',
      culturalSignificance: 'The heart of Ganga-Jamuni tehzeeb (syncretic north Indian culture), Urdu poetry of Mirza Ghalib, and traditional street food traditions.',
      architecturalFeatures: 'Historic haveli courtyards with carved sandstone doorways, Mughal jharokhas, copper-domed Gurdwara Sis Ganj Sahib, and the imperial red sandstone Jama Masjid.',
      whyWorthVisiting: 'Nowhere else in the subcontinent can travelers experience such a vibrant collision of centuries-old culinary heritage, spice trade, and architectural history.',
      whatToExperience: 'Climb the south minaret of Jama Masjid for views over the dense rooftops, ride a bicycle rickshaw through Khari Baoli to smell sacks of Kashmiri saffron and chillies, and sample paranthas at Pandit Gaya Prasad.',
      location: 'Shahjahanabad, Old Delhi 110006',
      coordinates: [28.6506, 77.2303],
      suggestedDuration: '3 to 4 hours',
      bestTimeToVisit: 'Morning (9:30 AM – 1:00 PM) before peak evening shopping footfall.',
      entryFeeInfo: 'Chandni Chowk streets are free; Jama Masjid entry is free (camera fee ₹300; minaret climb ₹100).',
      openingHoursInfo: 'Markets generally open Monday to Saturday 10:00 AM – 8:00 PM. Closed Sundays (except select food establishments).',
      accessibilityInfo: 'Chandni Chowk central boulevard is pedestrian-only and level; side gallis (lanes) are tight, crowded, and require alert walking.',
      familySuitability: 'High sensory reward; keep close hold of young children in the dense bazaar crowds.',
      photographyNotes: 'Spectacular documentary and food photography; request permission before photographing spice merchants in Khari Baoli.',
      nearbyCombinations: ['Red Fort (Lal Qila)', 'Jama Masjid', 'Mirza Ghalib’s Haveli in Ballimaran'],
      transitAdvice: 'Chandni Chowk and Chawri Bazar Metro Stations (Yellow Line) provide direct step-free access beneath the market.',
      visitorTips: ['Dress respectfully with shoulders and knees covered when visiting Jama Masjid; shoe bags are provided at the gates.', 'Wear a cotton face mask in Khari Baoli if sensitive to airborne chilli powder.'],
      officialLinks: [{ title: 'Shahjahanabad Redevelopment Corporation', url: 'https://delhitourism.gov.in' }],
      sourceNote: 'Delhi Heritage Research Foundation & INTACH Delhi Chapter.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1597040663342-45b6af3d91a5?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Crowded colourful bazaar streets of Chandni Chowk in Old Delhi',
      imageCredit: 'Unsplash'
    },
    {
      id: 'delhi-lodhi-garden',
      name: 'Lodhi Garden & Sayyid/Lodhi Tombs',
      cityId: 'delhi',
      category: 'Nature & Outdoors',
      shortSummary: '90-acre heritage landscaped park containing 15th-century octagonal tombs of the Sayyid and Lodhi dynasties.',
      fullDescription: 'Spanning 90 acres of shaded lawns, rose gardens, and ancient trees between Khan Market and Safdarjung’s Tomb, Lodhi Garden is Delhi’s favorite open-air cultural salon. Built between 1444 and 1517 during the reign of the Afghan Sayyid and Lodhi dynasties, the park contains the magnificent octagonal Tomb of Mohammed Shah, the imposing cube-like Bada Gumbad and its attached mosque with delicate incised stucco work, the Sheesh Gumbad (Glazed Dome) once coated in turquoise tiles, and the fortified garden tomb of Sikandar Lodhi. Today, statesmen, diplomats, poets, and morning joggers stroll beneath eucalyptus and neem trees while migratory birds nest in the historic stone niches.',
      historicalBackground: 'Originally a village known as Khairpur, transformed into "Lady Willingdon Park" in 1936 by British authorities, and redesigned with indigenous landscape aesthetics by Joseph Allen Stein in 1968.',
      culturalSignificance: 'The premier democratic green space of central Delhi, renowned for civic encounters, open-air intellectual conversations, and birdwatching.',
      architecturalFeatures: 'Octagonal tomb plan with exterior verandah and projecting eaves (chhajjas); early sultanate squinches; incised plaster Quranic calligraphies.',
      whyWorthVisiting: 'Combines peaceful park atmosphere with monumental 15th-century Afghan masonry, completely free of commercial admission fees.',
      whatToExperience: 'Walk past Bada Gumbad in the morning mist, listen to parakeets around the Athpula (eight-piered Mughal bridge), and admire the restored plasterwork inside the Bada Gumbad mosque.',
      location: 'Lodhi Road, New Delhi 110003',
      coordinates: [28.5931, 77.2197],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Early morning (6:30 AM – 9:00 AM) or sunset (4:30 PM – 6:30 PM).',
      entryFeeInfo: 'Free public park (NDMC maintained).',
      openingHoursInfo: 'Open daily: 6:00 AM – 8:00 PM (April to September: opens 5:00 AM).',
      accessibilityInfo: 'Paved, wide stone and asphalt pathways; ramped entry at all major gates; wheelchair accessible.',
      familySuitability: 'Superb for families, couples, and seniors.',
      photographyNotes: 'Silhouettes of the monumental domes against sunrise or dusk; reflection of Athpula bridge in the pond.',
      nearbyCombinations: ['Khan Market', 'India Habitat Centre', 'Safdarjung’s Tomb'],
      transitAdvice: 'Jor Bagh Metro Station (Yellow Line) is 500m walking distance from the west gate.',
      visitorTips: ['Combine your morning walk with breakfast at nearby Khan Market (Café Turtle or Sodabottleopenerwala).', 'Keep footwear clean if stepping onto the grass after monsoon rains.'],
      officialLinks: [{ title: 'New Delhi Municipal Council Parks Department', url: 'https://ndmc.gov.in' }],
      sourceNote: 'Archaeological Survey of India & NDMC Horticultural Department.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Domed sandstone tomb of the Lodhi dynasty set in verdant park',
      imageCredit: 'Unsplash'
    },
    {
      id: 'delhi-red-fort',
      name: 'The Red Fort (Lal Qila)',
      cityId: 'delhi',
      category: 'History & Heritage',
      shortSummary: 'Mughal Emperor Shah Jahan’s 1648 red sandstone palace-fortress, symbol of Indian national sovereignty.',
      fullDescription: 'Constructed between 1638 and 1648 when Mughal Emperor Shah Jahan moved his imperial seat from Agra to Delhi, the Red Fort is an immense citadel surrounded by 2.4 kilometres of towering red sandstone ramparts. Entering through the monumental Lahori Gate, visitors pass through Chhatta Chowk (the covered vaulted bazaar where silk merchants once sold brocades to the court) to reach the Diwan-i-Aam (Hall of Public Audience) with its carved marble baldachin throne. Beyond lies the Diwan-i-Khas (Hall of Private Audience), where the famous inscribed Persian couplet proclaims: "If there is paradise on earth, it is here, it is here, it is here." Here once stood the jewel-encrusted Peacock Throne before being plundered by Nader Shah of Persia in 1739.',
      historicalBackground: 'The supreme seat of Mughal power for two centuries. Inscribed as a UNESCO World Heritage site in 2007; the Prime Minister of India addresses the nation from its ramparts every Independence Day.',
      culturalSignificance: 'The defining political symbol of Indian sovereignty and independence, as well as the site of the historic 1945 INA Trials.',
      architecturalFeatures: 'Massive octagonal bastions, decorative kiosks (chhatris), white marble pavilions inlaid with pietradura floral stones, and stream of paradise (Nahr-i-Bihisht) channels.',
      whyWorthVisiting: 'Experience the sheer scale of Mughal sovereign theatre and stand where modern India’s freedom is commemorated each year.',
      whatToExperience: 'Walk through the Lahori Gate, study the carved marble pillars of Diwan-i-Khas, visit the Kranti Mandir museums inside the colonial barracks, and witness the evening light and sound show.',
      location: 'Netaji Subhash Marg, Chandni Chowk, Old Delhi 110006',
      coordinates: [28.6562, 77.2410],
      suggestedDuration: '2.5 hours',
      bestTimeToVisit: 'Morning (9:00 AM – 11:30 AM) on weekdays for unhurried exploration.',
      entryFeeInfo: '₹35 for Indian citizens, ₹550 for foreign tourists; museums ticket ₹50 extra (digital booking via ASI).',
      openingHoursInfo: 'Tuesday to Sunday: 9:30 AM – 5:30 PM. Closed Mondays.',
      accessibilityInfo: 'Paved walkways from the entry gate to central pavilions; golf carts available inside for visitors with limited mobility.',
      familySuitability: 'Broad open spaces, educational museums, and dramatic fortifications.',
      photographyNotes: 'Grand exterior shots from the sprawling grassy moat; ornate marble arches inside Diwan-i-Khas.',
      nearbyCombinations: ['Chandni Chowk', 'Jama Masjid', 'Shri Digambar Jain Lal Mandir'],
      transitAdvice: 'Lal Quila Metro Station (Violet Line) exits directly opposite the main entrance gate.',
      visitorTips: ['Security checks at the gate are rigorous; avoid carrying large backpacks or prohibited items (scissors, lighters).', 'Book tickets online via the ASI website to skip long physical queues.'],
      officialLinks: [{ title: 'UNESCO World Heritage — Red Fort Complex', url: 'https://whc.unesco.org/en/list/1054' }],
      sourceNote: 'Archaeological Survey of India & UNESCO World Heritage Centre.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1598555230054-94672f072465?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Red sandstone ramparts and Lahori Gate of the Red Fort in Delhi',
      imageCredit: 'Unsplash'
    },
    {
      id: 'delhi-crafts-museum',
      name: 'National Crafts Museum & Hastkala Academy',
      cityId: 'delhi',
      category: 'Art & Museums',
      shortSummary: 'Living artisan village museum housing 35,000 rare tribal and traditional Indian textiles, terracottas, and wood carvings.',
      fullDescription: 'Designed by visionary modernist architect Charles Correa, the National Crafts Museum on Bhairon Marg is an open-air oasis celebrating the boundless vernacular genius of rural India. Structured around open courtyards that mimic a traditional Indian village, the museum houses over 35,000 rare works of folk and tribal art. The galleries feature centuries-old Kalamkari temple hangings, Kutch mirror-work embroidery, Odisha bronze dhokra castings, and a colossal wooden ratha (temple chariot). In the open courtyard, master craftsmen from rural villages across India reside for monthly residencies, demonstrating live weaving, block printing, and pottery directly to visitors.',
      historicalBackground: 'Conceived in the 1950s by cultural activist Pupul Jayakar and designed by Charles Correa to celebrate Indian handicraft living traditions.',
      culturalSignificance: 'India’s premier institution preserving living intangible cultural heritage and direct fair-trade artisan livelihoods.',
      architecturalFeatures: 'Charles Correa’s vernacular courtyards, hand-painted mud walls, terracotta roof tiles, and carved timber pillars from Gujarat havelis.',
      whyWorthVisiting: 'Allows direct conversation with master artisans while buying certified authentic folk crafts without retail markups.',
      whatToExperience: 'Observe live pattachitra painting and dhokra bronze casting, dine on regional thalis at Café Lota, and wander through the village compound of rural mud houses.',
      location: 'Bhairon Marg, Pragati Maidan, New Delhi 110001',
      coordinates: [28.6145, 77.2422],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Morning or afternoon (10:30 AM – 3:30 PM); follow with lunch at Café Lota on-site.',
      entryFeeInfo: '₹20 for Indian nationals, ₹300 for foreign visitors; students ₹10.',
      openingHoursInfo: 'Tuesday to Sunday: 10:00 AM – 6:00 PM. Closed Mondays.',
      accessibilityInfo: 'Courtyards are level with ramped entries; accessible washrooms available.',
      familySuitability: 'Wonderfully tactile and inspiring for children and design students.',
      photographyNotes: 'Non-flash photography allowed in courtyards and artisan demonstration sheds.',
      nearbyCombinations: ['Purana Qila (Old Fort)', 'National Science Centre', 'Sundar Nursery'],
      transitAdvice: 'Supreme Court Metro Station (Blue Line) is 800m away; easily accessible by auto-rickshaw.',
      visitorTips: ['Reserve a table in advance for Café Lota, known for its creative regional Indian cuisine.', 'The museum craft shop offers government-authenticated handloom textiles and brass art.'],
      officialLinks: [{ title: 'National Crafts Museum Official Portal', url: 'https://nationalcraftsmuseum.gov.in' }],
      sourceNote: 'Ministry of Textiles, Government of India.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Handcrafted traditional Indian terracotta sculptures and folk arts',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '8th – 12th Century CE',
      title: 'Tomar & Chauhan Rajputs (Lalkot / Qila Rai Pithora)',
      description: 'Anangpal Tomar establishes the fortified settlement of Lal Kot; Prithviraj Chauhan expands it into Qila Rai Pithora before the Ghurid conquest.',
      keySites: ['Anangpal Dam', 'Rai Pithora Ramparts', 'Iron Pillar original site']
    },
    {
      epoch: '1206 – 1526 CE',
      title: 'The Delhi Sultanate (Mamluk, Khalji, Tughlaq, Sayyid, Lodhi)',
      description: 'Five successive dynasties rule from distinct fortified citadels: Siri, Tughlaqabad, Jahanpanah, and Feroz Shah Kotla, introducing Indo-Islamic domes and archways.',
      keySites: ['Qutb Minar', 'Tughlaqabad Fort', 'Hauz Khas Complex', 'Lodhi Tombs']
    },
    {
      epoch: '1526 – 1857 CE',
      title: 'The Mughal Empire & Shahjahanabad',
      description: 'Humayun and Akbar build monumental garden tombs. Shah Jahan founds Shahjahanabad with the Red Fort and Jama Masjid, crystallizing classical Urdu court culture.',
      keySites: ['Humayun’s Tomb', 'Red Fort', 'Jama Masjid', 'Chandni Chowk']
    },
    {
      epoch: '1911 – Present',
      title: 'Lutyens’ New Delhi & Sovereign Republic',
      description: 'The British shift the capital from Calcutta in 1911. Edwin Lutyens and Herbert Baker design the imperial axis (Rashtrapati Bhavan, India Gate), which becomes the seat of the democratic Republic of India.',
      keySites: ['Rashtrapati Bhavan', 'India Gate & Kartavya Path', 'National Museum']
    }
  ],

  architecturalHeritageOverview: 'Delhi represents eight centuries of architectural layering: early trabeated stone temples repurposed with corbelled arches under the Sultanate, the massive sloping granite rubble of Tughlaqabad, the perfection of the symmetrical Mughal charbagh garden tomb, and the neoclassical imperial axis of Lutyens’ New Delhi.',

  traditionsAndFestivals: [
    {
      title: 'Phool Walon Ki Sair (Festival of Flower Sellers)',
      seasonOrFrequency: 'Post-monsoon (September – October, 3 days)',
      description: 'A 200-year-old historic celebration of communal harmony in Mehrauli. Floral fan-shaped chhattars (pankhas) are offered jointly at the 13th-century Sufi shrine of Khwaja Bakhtiyar Kaki and the ancient Yogmaya Hindu Temple, accompanied by shehnai music and Kathak dances.',
      visitorEtiquette: 'Witnessed by people of all faiths; join the procession peacefully through Mehrauli market.'
    },
    {
      title: 'Nizamuddin Qawwali Evenings',
      seasonOrFrequency: 'Thursday evenings year-round',
      description: 'At the 700-year-old shrine of Sufi saint Hazrat Nizamuddin Auliya and poet Amir Khusrau, hereditary qawwals sing devotional Sufi verses in Persian, Hindavi, and Urdu beneath glowing chandeliers.',
      visitorEtiquette: 'Cover your head; remove footwear at the entrance; maintain silence during devotional singing.'
    }
  ],

  dishes: [
    {
      id: 'delhi-purani-dilli-nihari',
      name: 'Purani Dilli Mutton Nihari',
      localName: 'पुरानी दिल्ली नहारी',
      culturalOrigin: 'Created in the royal kitchens of Mughal Delhi in the late 18th century as a restorative dawn stew for laborers and nobility alike.',
      description: 'Tender mutton shank slow-simmered overnight for eight hours in a copper deg with bone marrow and 40 aromatic spices including mace, nutmeg, and dry ginger, thickened with roasted flour and garnished with julienned ginger, green chillies, and lime, served with hot tandoori khameeri roti.',
      typicalIngredients: ['Mutton shank & bone marrow (nalli)', 'Nihari potli masala', 'Ghee', 'Whole wheat flour', 'Ginger juliennes', 'Khameeri roti'],
      isVeg: false,
      whereToFind: 'Haji Shabrati Nihari Wale (Chitli Qabar, Matiya Mahal), Karim’s (Jama Masjid Gate 1), Al Jawahar.',
      priceCategory: 'Budget',
      dietaryAdvice: 'Non-vegetarian. Rich and unctuous; traditionally eaten for early morning breakfast or late dinner.',
      etiquetteTips: 'Squeeze fresh lime and add raw ginger juliennes at the table to cut through the rich bone-marrow gravy.',
      image: 'https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'delhi-chole-bhature',
      name: 'Dilli Ke Chole Bhature',
      localName: 'दिल्ली के छोले भटूरे',
      culturalOrigin: 'Brought by Punjabi refugees arriving in Delhi following the 1947 Partition, becoming the city’s favorite Sunday breakfast.',
      description: 'Plump chickpeas braised with black tea leaves, dried pomegranate seeds (anardana), and roasted cumin until dark and intensely tangy, paired with ballooning, deep-fried bhaturas stuffed with paneer, accompanied by pickled amla, carrots, and mint chutney.',
      typicalIngredients: ['Kabuli chana (chickpeas)', 'Anardana (dried pomegranate)', 'Tea decoction', 'Flour bhatura with paneer', 'Raw mango pickle'],
      isVeg: true,
      whereToFind: 'Sita Ram Diwan Chand (Paharganj), Chache Di Hatti (Kamla Nagar), Baba Nagpal Corner (Lajpat Nagar).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Deep-fried and intensely filling; pairs perfectly with a glass of sweet lassi.',
      etiquetteTips: 'Puncture the puffed bhatura carefully with your fingers to release the trapped steam before tearing.',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'delhi-daulat-ki-chaat',
      name: 'Daulat Ki Chaat (Winter Cloud Soufflé)',
      localName: 'दौलत की चाट',
      culturalOrigin: 'An ephemeral winter culinary delicacy prepared in Old Delhi by families from Moradabad.',
      description: 'Prepared exclusively during chilly winter months (November to February). Raw milk and cream are churned by hand in the cold night dew for hours; the resulting ethereal foam is skimmed off, chilled, and served topped with saffron syrup, crushed pistachios, and silver leaf (varq). It dissolves on the tongue like sweet cold air.',
      typicalIngredients: ['Churned milk dew froth', 'Castor sugar', 'Saffron syrup', 'Mawa (khoya)', 'Pistachio slivers', 'Edible silver varq'],
      isVeg: true,
      whereToFind: 'Khemchand Adesh Kumar stalls in Kinari Bazaar and Dariba Kalan (Chandni Chowk).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Highly delicate; cannot survive heat or transit and must be eaten immediately.',
      etiquetteTips: 'Scoop gently with the wooden spoon; never stir or mix, which causes the delicate froth to collapse.',
      image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Old Delhi: Matiya Mahal & Jama Masjid',
      character: 'Densely packed historic alleyways filled with generational kebab makers, slow-stewed nihari, and sweet shahi tukda.',
      bestTime: 'Evening 6:00 PM until midnight.',
      highlights: ['Mutton burra at Karim’s', 'Chicken changezi at Al Jawahar', 'Shahi tukda with rabdi at Cool Point'],
      visitorAdvice: 'Strictly pedestrian; access via Chawri Bazar or Jama Masjid Metro and walk down the lane facing Gate 1.'
    },
    {
      name: 'Pandara Road Market (India Gate)',
      character: 'Post-independence culinary enclave famous for legendary late-night North Indian curries and tandoori chicken.',
      bestTime: 'Late dinner 8:00 PM – 11:30 PM.',
      highlights: ['Butter chicken and dal makhani at Gulati', 'Havemore kebabs', 'Pindi chana'],
      visitorAdvice: 'Valet parking is available; expect 20–30 minute table waits on Friday and Saturday evenings.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Delhi requires heightened situational awareness, particularly for solo female travelers during late evening hours.',
      'Air quality index (AQI) can reach severe levels between late October and December due to seasonal crop burning and winter inversion; carry an N95 mask if traveling during these months.',
      'Summer temperatures in May and June frequently exceed 42°C; explore monuments early in the morning and carry hydration.',
      'In crowded tourist hubs like Paharganj, New Delhi Railway Station, and Chandni Chowk, be cautious of touts offering unsolicited hotel bookings or "closed monument" diversions.'
    ],
    transportPedestrian: [
      'Delhi Metro is India’s most comprehensive, safe, and air-conditioned transit system. The first coach of every train is strictly reserved for women.',
      'Auto-rickshaw drivers rarely use electronic meters for tourists; book via app-based aggregators (Uber, Ola, Rapido) or use pre-paid taxi booths at airport and railway stations.',
      'Crossing multi-lane arterial roads like Ring Road or Mathura Road is hazardous; always use designated footbridges, underpasses, or metro subways.'
    ],
    nightTravel: [
      'Central Delhi areas like Khan Market, Connaught Place (inner circle), and Hauz Khas Village are active until 11:30 PM.',
      'Use app-based cabs (Uber or Ola) for night travel, enabling in-app safety tracking and ride-sharing with contacts.'
    ],
    accessibilityNotes: [
      'Delhi Metro is fully wheelchair accessible with tactile paving, audible announcements, lifts, and wide automatic gates.',
      'Major ASI monuments like Humayun’s Tomb and Qutb Minar have ramped pathways, while Old Delhi’s narrow bazaar gallis have steep steps and open drains.'
    ],
    emergencyContacts: [
      { title: 'Delhi Police Unified Emergency', number: '112', note: '24/7 central emergency response' },
      { title: 'Delhi Police Women Helpline', number: '1091', note: 'Special Cell for Women and Children' },
      { title: 'Tourist Police Assistance', number: '011 2301 0101', note: 'Dedicated tourist kiosks at major monuments' },
      { title: 'Ambulance Emergency', number: '102 / 108', note: 'Centralized Ambulance Trauma Services (CATS)' }
    ],
    limitationsDisclaimer: 'Information is sourced from Delhi Police Crime Branch notifications, Delhi Metro Rail Corporation guidelines, and verified tourism department advisories.'
  },

  neighbourhoods: [
    {
      id: 'delhi-mehrauli-hauz-khas',
      name: 'South Delhi: Mehrauli & Hauz Khas',
      cityId: 'delhi',
      character: 'Fascinating blend of medieval 13th-century Sultanate ruins, archaeological woodland parks, contemporary art design studios, and lakeside cafes.',
      budgetTier: 'Moderate to Upscale',
      transitScore: 'Very High (Served by Qutab Minar & Hauz Khas interchange metro stations)',
      transitDetails: 'Hauz Khas serves as a vital interchange between Yellow and Magenta lines; auto-rickshaws plentiful.',
      walkabilityRating: 'High within the archaeological parks; village lanes are narrow and lively.',
      accessibilityNotes: 'Deer Park and Mehrauli Archaeological Park feature dirt trails; paved sidewalks around Hauz Khas metro.',
      heritageHighlights: ['Qutb Minar complex', 'Hauz Khas Madrasa & Lake', 'Jamali Kamali Mosque', 'Zafar Mahal'],
      foodHighlights: ['Olive Bar & Kitchen', 'MIA Bella overlooking the lake', 'Chor Bizarre'],
      greenSpaceNotes: 'Sanjay Van urban forest and Deer Park form a vast continuous green belt.',
      safetyContext: 'Active daytime and evening footfall; take care along poorly lit park trails after sunset.',
      methodologyNote: 'Evaluated using urban forest canopy data and archaeological density surveys.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'delhi-lutyens-lodhi',
      name: 'Central Delhi: Lutyens & Lodhi Estate',
      cityId: 'delhi',
      character: 'Stately, manicured diplomatic and administrative precinct characterized by wide tree-canopied avenues, government bungalows, open gardens, and upscale cultural centers.',
      budgetTier: 'Upscale / High-end',
      transitScore: 'High (Jor Bagh, Khan Market, and Central Secretariat metro stations)',
      transitDetails: 'Excellent road connectivity, low traffic congestion, and reliable ride-hailing services.',
      walkabilityRating: 'Very High (Continuous broad, level footpaths under mature jamun and neem trees).',
      accessibilityNotes: 'Sidewalks have curb ramps; public institutions (India Habitat Centre, Lodhi Garden) are accessible.',
      heritageHighlights: ['Lodhi Garden Tombs', 'India Gate & Kartavya Path', 'Rashtrapati Bhavan'],
      foodHighlights: ['Khan Market cafes', 'Gulati on Pandara Road', 'Lodi The Garden Restaurant'],
      greenSpaceNotes: 'Exceptional; includes Lodhi Garden, Nehru Park, and the National Rose Garden.',
      safetyContext: 'One of the most heavily patrolled and secure zones in India due to diplomatic presence.',
      methodologyNote: 'Based on municipal street infrastructure metrics and diplomatic zone safety ratings.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'delhi-old-delhi',
      name: 'Walled City: Shahjahanabad & Daryaganj',
      cityId: 'delhi',
      character: 'High-density 17th-century Mughal urban core brimming with historic mosques, residential havelis, book markets, and generational food lanes.',
      budgetTier: 'Budget-friendly',
      transitScore: 'Very High (Chandni Chowk, Chawri Bazar, Lal Quila, and Jama Masjid metro stations)',
      transitDetails: 'Subterranean metro access in every quadrant; bicycle rickshaws and walking within the lanes.',
      walkabilityRating: 'High for agile pedestrians; Chandni Chowk main road is pedestrianized, but gallis are packed.',
      accessibilityNotes: 'Historic gallis feature open stone gutters and occasional steps; central Chandni Chowk is flat.',
      heritageHighlights: ['Red Fort', 'Jama Masjid', 'Fatehpuri Masjid', 'Khari Baoli'],
      foodHighlights: ['Karim’s', 'Pandit Gaya Prasad Paranthe Wale', 'Khemchand Daulat Ki Chaat'],
      greenSpaceNotes: 'Limited internal green space; gardens surrounding Red Fort provide open relief.',
      safetyContext: 'High community vibrancy; watch personal belongings in crowded markets.',
      methodologyNote: 'Calculated from historical urban morphology records and commercial bazaar surveys.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-delhi-seven-cities',
      cityId: 'delhi',
      title: 'The Seven Cities: Why Delhi Never Dies',
      preview: 'From the Chauhan ramparts of Qila Rai Pithora to the Mughal elegance of Shahjahanabad, how Delhi was rebuilt again and again across a thousand years.',
      fullArticle: 'Legend claims that whoever builds a new city in Delhi is destined to lose it. History records at least seven distinct historic capitals erected within this 50-square-kilometre triangle of land. First came Qila Rai Pithora in Mehrauli under the Tomar and Chauhan Rajputs. In the 14th century, Alauddin Khalji built the circular fortress of Siri. Ghiyasuddin Tughlaq erected the colossal stone walls of Tughlaqabad, only to abandon it due to a water curse from Sufi saint Nizamuddin. Muhammad bin Tughlaq linked the ruins into Jahanpanah, before his successor Feroz Shah Tughlaq moved north to build Feroz Shah Kotla along the Yamuna. In the 16th century, Humayun and Sher Shah Suri raised Dinpanah and Purana Qila. Finally, Shah Jahan constructed the grand walled city of Shahjahanabad in 1648. Each empire fell, but their stones, arches, and water stepwells remain inextricably woven into the modern capital, creating a city that is less a single place than an eternal conversation between eras.',
      locationName: 'Mehrauli to Old Delhi',
      factualExplanation: 'Documented in historical chronicles from Ziauddin Barani to contemporary surveys by Percival Spear and Narayani Gupta.',
      sources: ['A History of Delhi under the Later Sultans', 'Delhi: A Thousand Years of Building by Lucy Peck'],
      relatedDestinationIds: ['delhi-qutb-minar', 'delhi-red-fort', 'delhi-humayun-tomb'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Ancient stone minaret and ruins in Delhi'
    },
    {
      id: 'story-delhi-paranthe-wali-gali',
      cityId: 'delhi',
      title: 'The Oil-Fried Bread of 1872: Secrets of Paranthe Wali Gali',
      preview: 'How a family of Brahmin migrants from Gwalior turned a tiny alley in Chandni Chowk into an institution that fed prime ministers and poets.',
      fullArticle: 'Tucked off the silver-bazaar bustle of Dariba Kalan lies a narrow lane known as Paranthe Wali Gali. In 1872, Pandit Gaya Prasad Kalawala migrated to Shahjahanabad from Morena, Gwalior, opening a small shop that prepared bread in a manner entirely unique: rather than roasting paranthas on a dry tawa with a smear of butter, he deep-fried them in deep, scalding kadhais of pure clarified butter (ghee). The bread puffed like a golden pillow, its flaky layers infused with imaginative fillings—not only spiced potato and radish, but bitter gourd (karela), crushed almonds (badam), green chillies (mirchi), and even sweet rabdi. Over 150 years later, the sixth generation of the family still serves these crisp, steaming delicacies on dried leaf plates alongside sweet pumpkin curry (sitaphal) and tart mint chutney, having hosted Jawaharlal Nehru, Indira Gandhi, and generations of Delhiites.',
      locationName: 'Paranthe Wali Gali, Chandni Chowk',
      factualExplanation: 'Commercial trade records and family oral histories preserved in Old Delhi merchant directories.',
      sources: ['Shahjahanabad Merchants Association Archives', 'City of Djinns by William Dalrymple'],
      relatedDestinationIds: ['delhi-chandni-chowk'],
      readTimeMinutes: 3,
      image: 'https://images.unsplash.com/photo-1597040663342-45b6af3d91a5?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Old Delhi street food vendors'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '5°C – 24°C', advice: 'Pleasant daytime sunshine; early morning fog. Peak season for monument visits and garden strolls. Carry warm woollens for crisp evenings.' },
      { season: 'Monsoon (Jul – Sep)', temperatureRange: '26°C – 35°C', advice: 'High humidity and heavy cloudbursts; gardens and monuments appear lush, but drainage can lag on arterial underpasses.' },
      { season: 'Summer (Apr – Jun)', temperatureRange: '28°C – 45°C', advice: 'Intense dry heat and dusty loo winds; visit outdoor monuments strictly between 6:30–9:30 AM or after 5:30 PM.' }
    ],
    transportInfrastructure: [
      { mode: 'Delhi Metro', coverage: '390+ km spanning 12 lines connecting Delhi, Noida, Gurgaon, and Faridabad', tip: 'Fastest, safest way to travel. Use the Airport Express Line for 20-minute transit from IGI Airport to New Delhi Station.' },
      { mode: 'App-Based Cabs & Autos', coverage: 'Full city coverage', tip: 'Uber, Ola, and BluSmart (all-electric cabs) are widely used and transparently priced.' },
      { mode: 'E-Rickshaws & Cycle Rickshaws', coverage: 'Last-mile connectivity in Old Delhi, Mehrauli, and university hubs', tip: 'Great for negotiating narrow historic market lanes where cars cannot enter.' }
    ],
    environmentalNotes: 'Delhi experiences severe winter particulate pollution (AQI 250–450) between late October and December. Check real-time SAFAR / CPCB air quality updates and use an N95 mask outdoors during winter months.',
    dataAttribution: 'Delhi Tourism and Transportation Development Corporation (DTTDC) & Central Pollution Control Board (CPCB)'
  }
};
