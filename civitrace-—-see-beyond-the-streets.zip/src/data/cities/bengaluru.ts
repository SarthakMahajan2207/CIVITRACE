import { City } from '../../types';

export const bengaluruData: City = {
  id: 'bengaluru',
  name: 'Bengaluru',
  state: 'Karnataka',
  region: 'Mysuru Plateau',
  tagline: 'The Garden City turned Silicon Crucible of India',
  heroDescription: 'Perched nearly 1,000 metres high on the Deccan plateau, Bengaluru balances its modern software corridors with 16th-century Kempe Gowda watchtowers, Tipu Sultan’s carved teakwood summer palace, verdant botanical canopies, and generational filter-coffee institutions.',
  introSentence: 'A plateau metropolis where centuries of lake engineering, regal botanical gardens, and Carnatic music converge with technological ingenuity.',
  coordinates: [12.9716, 77.5946],
  accentColor: 'emerald',
  hexAccent: '#059669',
  heroImage: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Lush green botanical glass house and gardens in Bengaluru',
  imageCredit: 'Unsplash / Bangalore Heritage Trust',
  heritageThemes: ['Kempe Gowda Chieftaincy', 'Mysore Kingdom & Tipu Sultan', 'Botanical Canopy & Lake Networks', 'Colonial Cantonment & Science Institutions', 'Filter Coffee & Tiffin Culture'],

  destinations: [
    {
      id: 'blr-lalbagh',
      name: 'Lalbagh Botanical Garden & Glass House',
      cityId: 'bengaluru',
      category: 'Nature & Outdoors',
      shortSummary: '240-acre royal botanical sanctuary commissioned in 1760 by Hyder Ali, housing the iconic Victorian Glass House.',
      fullDescription: 'Commissioned by Hyder Ali in 1760 and enriched by his son Tipu Sultan with exotic plants brought from Persia, Afghanistan, and the French colonies, Lalbagh is India’s foremost living botanical repository. At its center stands the magnificent Glass House, modeled on London’s Crystal Palace in 1889, where biannual flower shows draw hundreds of thousands of spectators. Spanning 240 acres, the garden features ancient trees exceeding two centuries in age, a peaceful lotus lake, a bonsai garden, and the monolithic 3,000-million-year-old Lalbagh Rock—one of the oldest exposed geological formations on Earth—topped by one of Kempe Gowda’s original 16th-century boundary watchtowers.',
      historicalBackground: 'Conceived as a 40-acre private royal retreat for the rulers of Mysore. Expanded under British superintendents such as John Cameron and Gustav Krumbiegel into an international botanical exchange.',
      culturalSignificance: 'The green lung of south Bengaluru and the primary reason Bengaluru earned its historic reputation as India’s "Garden City".',
      architecturalFeatures: 'Cast-iron and glass architectural pavilion (Glass House) fabricated by Walter Macfarlane & Co. of Glasgow; monolithic Archean granite rock; historic bandstand.',
      whyWorthVisiting: 'Offers an unparalleled walk beneath towering canopies of baobabs, silk-cotton trees, and Moreton Bay figs in the center of a bustling metropolis.',
      whatToExperience: 'Walk through the Glass House, climb the ancient basalt rock to Kempe Gowda’s watchtower at sunrise, stroll around the lake boardwalk, and sample fresh coconut water.',
      location: 'Mavalli, South Bengaluru 560004',
      coordinates: [12.9507, 77.5848],
      suggestedDuration: '2 to 2.5 hours',
      bestTimeToVisit: 'Early morning (6:00 AM – 9:00 AM) when morning joggers and birdwatchers fill the misty tree avenues.',
      entryFeeInfo: '₹30 for adults (free entry between 6:00 AM and 9:00 AM, and 6:00 PM and 7:00 PM for joggers); camera fee ₹60.',
      openingHoursInfo: 'Open daily: 6:00 AM – 7:00 PM.',
      accessibilityInfo: 'Paved, wide walking paths suitable for wheelchairs; golf carts (buggies) operate inside for elderly and disabled visitors.',
      familySuitability: 'Superb for all generations; extensive shaded lawns and lake trails.',
      photographyNotes: 'Spectacular early morning light through ancient canopy foliage; Glass House architectural reflections.',
      nearbyCombinations: ['MTR (Mavalli Tiffin Room)', 'Basavanagudi Bull Temple', 'Gandhi Bazaar'],
      transitAdvice: 'Direct connectivity via Lalbagh Metro Station (Green Line) right at the West Gate.',
      visitorTips: ['Enter through the West Gate if arriving by Metro.', 'Visit the historic Mavalli Tiffin Room (MTR) near the main gate for post-walk rava idli and filter coffee.'],
      officialLinks: [{ title: 'Department of Horticulture, Government of Karnataka', url: 'https://horticulture.karnataka.gov.in' }],
      sourceNote: 'Karnataka Directorate of Horticulture & Geological Survey of India.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Victorian Glass House illuminated in Lalbagh Garden',
      imageCredit: 'Unsplash'
    },
    {
      id: 'blr-tipu-palace',
      name: 'Tipu Sultan’s Summer Palace',
      cityId: 'bengaluru',
      category: 'History & Heritage',
      shortSummary: 'Two-storey Indo-Islamic teakwood palace completed in 1791, known as the "Abode of Happiness".',
      fullDescription: 'Completed in 1791 within the ramparts of Bangalore Fort, this two-storey royal retreat served as the summer headquarters of Tipu Sultan, the famed "Tiger of Mysore". Constructed entirely of seasoned teakwood, mortar, and stone, the palace is renowned for its grand fluted pillars, scalloped Indo-Islamic cusped arches, and delicate floral fresco motifs. The open-air durbar hall on the upper floor allowed cooling cross-breezes while the ruler held audience. Within the ground-floor chambers, a museum maintained by the Archaeological Survey of India displays replica rocket weapons developed by Tipu’s military engineers—precursors to modern artillery rockets—alongside original historical portraits and coins.',
      historicalBackground: 'Began under Hyder Ali in 1781 and completed by Tipu Sultan in 1791. Used briefly by British authorities as an administrative secretariat after the Fall of Srirangapatna in 1799.',
      culturalSignificance: 'A rare surviving example of late 18th-century secular timber palace architecture in southern India.',
      architecturalFeatures: 'Monolithic teak pillars, carved brackets, cusped multi-foil arches painted in vegetable dyes, and decorative timber balconies.',
      whyWorthVisiting: 'Experience the refined wooden court life of the Kingdom of Mysore and observe early Indian metallurgical rocket technology.',
      whatToExperience: 'Study the painted timber ceilings, walk through the zenana balconies, inspect the rocket warhead replicas in the gallery, and view the preserved Bangalore Fort stone gate nearby.',
      location: 'Allbert Victor Road, Chamrajpet, Bengaluru 560018',
      coordinates: [12.9592, 77.5738],
      suggestedDuration: '1 hour',
      bestTimeToVisit: 'Morning hours (9:00 AM – 11:30 AM) to avoid afternoon heat and school groups.',
      entryFeeInfo: '₹25 for Indian nationals, ₹300 for foreign tourists (ASI ticketing).',
      openingHoursInfo: 'Open daily: 8:30 AM – 5:30 PM.',
      accessibilityInfo: 'Ground floor rooms are level; the upper durbar hall is reached via steep historic wooden stairs without elevator access.',
      familySuitability: 'Compact and educational for history students and families.',
      photographyNotes: 'Non-flash photography permitted; capture the perspective through the receding rows of teak arches.',
      nearbyCombinations: ['Bangalore Fort Gate', 'K.R. Market (City Market)', 'Vani Vilas Hospital Heritage Building'],
      transitAdvice: 'Krishna Rajendra Market Metro Station (Green Line) is 500m walking distance.',
      visitorTips: ['Combine with an early morning stroll through the vibrant flower auctions at nearby K.R. Market.', 'Notice the tiger-stripe motifs subtly integrated into royal decorative elements.'],
      officialLinks: [{ title: 'ASI Bangalore Circle — Tipu Sultan Palace', url: 'https://asibengalurucircle.in' }],
      sourceNote: 'Archaeological Survey of India Heritage Dossier.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Carved teakwood arches of Tipu Sultan Summer Palace in Bengaluru',
      imageCredit: 'Unsplash'
    },
    {
      id: 'blr-cubbon-park',
      name: 'Cubbon Park & Attara Kacheri (High Court)',
      cityId: 'bengaluru',
      category: 'Nature & Outdoors',
      shortSummary: '300-acre colonial green sanctuary surrounding the neoclassical red-stone Attara Kacheri.',
      fullDescription: 'Established in 1870 by Major General Richard Sankey, Chief Engineer of Mysore State, Cubbon Park is the monumental green heart of administrative Bengaluru. Spanning over 300 acres, it is planted with over 6,000 indigenous and exotic trees, including silver oaks, tabebuias that burst into pink blossoms each February, and century-old bamboo thickets. Flanking the park’s northern lawns is Attara Kacheri ("Eighteen Offices"), a majestic two-storey neoclassical building finished in vibrant pompeiian red terracotta, now housing the High Court of Karnataka. Directly opposite stands the colossal granite neo-Dravidian edifice of Vidhana Soudha, built in 1956 under Chief Minister Kengal Hanumanthaiah.',
      historicalBackground: 'Originally named Meade’s Park, later renamed to honor Sir Mark Cubbon, the longest-serving British Commissioner of Mysore.',
      culturalSignificance: 'A beloved democratic sanctuary where citizens walk dogs, practice acoustic music, run book clubs, and enjoy vehicle-free Sundays.',
      architecturalFeatures: 'Neoclassical Ionic colonnades, Corinthian pediments on Attara Kacheri; neo-Dravidian chhatris and granite carvings on Vidhana Soudha; colonial bandstand.',
      whyWorthVisiting: 'Experience Bengaluru’s colonial architectural grandeur immersed in peaceful woodland directly adjacent to the state seat of power.',
      whatToExperience: 'Walk under the flowering canopy, admire the red facade of the High Court from the central lawns, visit the State Central Library (Seshadri Iyer Memorial Hall), and join Sunday book-reading circles.',
      location: 'Kasturba Road, Sampangi Rama Nagara, Bengaluru 560001',
      coordinates: [12.9763, 77.5929],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Sunday mornings (traffic is completely barred inside the park, turning it into a pedestrian haven).',
      entryFeeInfo: 'Park entry is free; State Central Library is free for readers.',
      openingHoursInfo: 'Open daily: 6:00 AM – 7:00 PM. Closed to vehicular traffic on Sundays and second Saturdays.',
      accessibilityInfo: 'Paved pedestrian paths with level asphalt roads; highly accessible for wheelchairs and strollers.',
      familySuitability: 'Outstanding for families, pets, and outdoor fitness.',
      photographyNotes: 'Striking contrast between the vibrant red Attara Kacheri and lush green foliage; blooming tabebuia trees in February/March.',
      nearbyCombinations: ['Vidhana Soudha', 'Government Museum & Venkatappa Art Gallery', 'Visvesvaraya Industrial & Technological Museum'],
      transitAdvice: 'Direct access via Vidhana Soudha and Cubbon Park Metro Stations (Purple Line).',
      visitorTips: ['Sundays feature the famous Cubbon Reads silent reading community from 9:00 AM to 1:00 PM on the library lawns.', 'Rent a bicycle or bring a picnic mat.'],
      officialLinks: [{ title: 'Karnataka State Department of Horticulture', url: 'https://horticulture.karnataka.gov.in' }],
      sourceNote: 'Bangalore Environment Trust & State Department of Parks.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Neoclassical red terracotta colonnade and park lawn at Cubbon Park',
      imageCredit: 'Unsplash'
    },
    {
      id: 'blr-bull-temple',
      name: 'Bull Temple (Dodda Basavana Gudi) & Bugle Rock',
      cityId: 'bengaluru',
      category: 'Spiritual & Sacred',
      shortSummary: '16th-century Vijayanagara monolithic Nandi bull shrine carved from a single granite boulder.',
      fullDescription: 'Built in 1537 by Kempe Gowda I, the founder of Bengaluru, the Bull Temple in Basavanagudi houses a monumental monolithic sculpture of Nandi, the sacred bull mount of Lord Shiva. Measuring 4.6 metres in height and 6.1 metres in length, the colossal bull was carved directly out of a single granite outcrop. Over centuries, tradition held that the statue was continuously growing, prompting priests to affix a trident on its forehead to arrest its expansion; regular offerings of butter and charcoal oil have given the granite a rich, glistening black patina. Adjacent lies Bugle Rock, an ancient volcanic geological park from which Kempe Gowda’s watchmen blew bugles to warn citizens of approaching armies.',
      historicalBackground: 'Founded after local peanut farmers reported a stray bull devouring their crops; Kempe Gowda consecrated the shrine, after which the bull peacefully vanished.',
      culturalSignificance: 'The cultural center of traditional Basavanagudi, celebrated annually during Kadalekai Parishe (Groundnut Fair).',
      architecturalFeatures: 'Vijayanagara-style Dravidian vimana tower, monolithic granite Nandi sculpture, and ancient basalt rock formations.',
      whyWorthVisiting: 'Experience the devotional soul of old south Bengaluru and witness one of the largest monolithic Nandi sculptures in the world.',
      whatToExperience: 'Take blessings at the monolithic Nandi shrine, stroll through the shady pathways of Bugle Rock Park, and browse the traditional Brahmin shops of Gandhi Bazaar nearby.',
      location: 'Bull Temple Road, Basavanagudi, Bengaluru 560004',
      coordinates: [12.9421, 77.5683],
      suggestedDuration: '1 to 1.5 hours',
      bestTimeToVisit: 'Morning (7:00 AM – 10:30 AM) during morning prayers, or November during the groundnut festival.',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Open daily: 6:00 AM – 8:30 PM.',
      accessibilityInfo: 'Gentle stone ramps provide access to the outer temple platform; shoes must be removed before entering.',
      familySuitability: 'Peaceful and culturally enriching for families.',
      photographyNotes: 'Exterior temple gopuram and park can be photographed; photography of the inner sanctum requires priest permission.',
      nearbyCombinations: ['Bugle Rock Park', 'Dodda Ganesha Temple', 'Gandhi Bazaar & Vidyarthi Bhavan'],
      transitAdvice: 'National College Metro Station (Green Line) is 1.2 km away. Auto-rickshaws available from Swastik/Gandhi Bazaar.',
      visitorTips: ['If visiting in late November, do not miss the Kadalekai Parishe, when farmers from across Karnataka sell fresh roasted peanuts.', 'Walk to nearby Vidyarthi Bhavan for their legendary ghee-soaked masala dosa.'],
      officialLinks: [{ title: 'Muzrai Department of Karnataka', url: 'https://muzrai.karnataka.gov.in' }],
      sourceNote: 'Karnataka Religious & Endowments Department Heritage Archives.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Historic Dravidian temple gopuram and stone courtyard in Basavanagudi',
      imageCredit: 'Unsplash'
    },
    {
      id: 'blr-kr-market',
      name: 'Krishna Rajendra (K.R.) City Market',
      cityId: 'bengaluru',
      category: 'Local Food & Markets',
      shortSummary: 'Asia’s largest traditional wholesale flower and spice bazaar, operating in sensory crescendo before dawn.',
      fullDescription: 'Established in 1928 on the historic site of an 18th-century water tank and military battlefield, K.R. Market (City Market) is an unforgettable assault of color, scent, and kinetic human energy. Long before dawn, farmers from across southern Karnataka arrive with mountains of fresh marigolds, fragrant jasmine (mallige), crimson roses, and crossandra strings. The three-storey red-brick heritage market building houses spice merchants weighing cardamom, dried chillies, and camphor, while the basement opens into a sea of woven floral garlands. Outside, the century-old iron colonnades buzz with vegetable vendors, coir rope craftsmen, and copper vessel tinsmiths.',
      historicalBackground: 'Site of the 1791 Third Anglo-Mysore War battle between British forces and Tipu Sultan’s cavalry. Rebuilt as a municipal market under the Dewan of Mysore.',
      culturalSignificance: 'The epicentre of Bengaluru’s traditional flower economy, supplying blossoms for temples, weddings, and homes across South India.',
      architecturalFeatures: 'Colonial arched brick facade, iron lattice framework, multi-level central atrium, and historic step wells nearby.',
      whyWorthVisiting: 'Nowhere else in southern India captures such an electrifying sensory explosion of early-morning flowers and traditional commerce.',
      whatToExperience: 'Arrive between 5:00 AM and 6:30 AM to see millions of fresh blossoms traded by lantern light, watch garland makers tie jasmine with banana fibre, and sip strong filter coffee from steel tumblers.',
      location: 'K.R. Market, Kalasipalya, Bengaluru 560002',
      coordinates: [12.9644, 77.5768],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Dawn (5:00 AM – 7:00 AM) for peak flower auction activity.',
      entryFeeInfo: 'Free public market.',
      openingHoursInfo: 'Flower trading begins at 4:00 AM; general vegetable and spice stalls open until 8:00 PM.',
      accessibilityInfo: 'Intense crowds, wet floors from crushed flowers, and steep concrete steps make wheelchair access difficult. Wear closed-toe walking shoes.',
      familySuitability: 'Thrilling for photographers and cultural travelers; hold hands with children tightly.',
      photographyNotes: 'Unrivalled street and color photography; wide-angle lenses excel from the first-floor balcony looking down into the flower pit.',
      nearbyCombinations: ['Bangalore Fort Gate', 'Tipu Sultan’s Summer Palace', 'Victoria Hospital Heritage Quadrangle'],
      transitAdvice: 'Direct access via Chickpet or Krishna Rajendra Market Metro Stations (Green Line).',
      visitorTips: ['Keep valuables in front pockets; the morning crush is intense.', 'Do not use camera flash directly in the eyes of working flower sorters.'],
      officialLinks: [{ title: 'Bruhat Bengaluru Mahanagara Palike (BBMP) Markets', url: 'https://bbmp.gov.in' }],
      sourceNote: 'BBMP Heritage Cell & Bangalore Historical Society Surveys.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Thousands of vibrant orange marigold garlands in K.R. Market',
      imageCredit: 'Unsplash'
    },
    {
      id: 'blr-bangalore-palace',
      name: 'Bangalore Palace & Royal Grounds',
      cityId: 'bengaluru',
      category: 'Architecture',
      shortSummary: 'Tudor-revival royal estate built in 1878 by Chamarajendra Wadiyar X, inspired by Windsor Castle.',
      fullDescription: 'Purchased in 1873 by the guardians of the young Maharaja Chamarajendra Wadiyar X from the Rev. J. Garrett, Bangalore Palace was transformed into a majestic Tudor-revival castle completed in 1878. Featuring fortified stone towers, crenellated battlements, turreted balconies, and sweeping lawns, its exterior deliberately echoes Windsor Castle. The lavish interiors showcase wooden staircases carved with elephant heads, stained-glass heraldic windows imported from England, Victorian floral wallpaper, and an extraordinary Durbar Hall adorned with yellow walls, classical chandeliers, and historic oil paintings by renowned artist Raja Ravi Varma.',
      historicalBackground: 'Constructed as the city residence for the Mysore royal family. Still owned and maintained privately by the Wadiyar dynasty.',
      culturalSignificance: 'A prominent landmark of royal Mysore patronage, showcasing how 19th-century Indian royalty integrated European architectural styles with indigenous court rituals.',
      architecturalFeatures: 'Tudor stone towers, Gothic battlements, carved oak and teak woodwork, Florentine tile mosaics, and Dutch wood mantels.',
      whyWorthVisiting: 'Offers an opulent glimpse into the private domestic universe of the Mysore royal family and features rare original Raja Ravi Varma canvases.',
      whatToExperience: 'Walk through the grand ballroom and durbar hall, inspect the Maharaja’s personal hunting memorabilia and vintage photographs, and explore the courtyard tiled in Moorish patterns.',
      location: 'Vasanth Nagar, Bengaluru 560052',
      coordinates: [12.9988, 77.5921],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Morning (10:00 AM – 1:00 PM) for comfortable room viewing.',
      entryFeeInfo: '₹250 for Indian nationals, ₹500 for foreign visitors (includes audio guide); camera pass ₹300.',
      openingHoursInfo: 'Open daily: 10:00 AM – 5:30 PM.',
      accessibilityInfo: 'Ground floor is accessible; upper floors require climbing wooden staircases.',
      familySuitability: 'Engaging castle experience for children and architecture lovers.',
      photographyNotes: 'Interior photography requires a paid ticket badge; flash is prohibited near historic oil paintings.',
      nearbyCombinations: ['Mount Carmel College corridor', 'Sankey Tank', 'Malleshwaram'],
      transitAdvice: 'Auto-rickshaw or taxi from Cantonment railway station (2 km) or Cubbon Park Metro (3 km).',
      visitorTips: ['The audio guide (included in ticket price) provides excellent historic context for each royal salon.', 'Check ahead if private concerts or exhibitions are utilizing the palace grounds.'],
      officialLinks: [{ title: 'Bangalore Palace Trust', url: 'https://karnatakatourism.org' }],
      sourceNote: 'Mysore Royal Family Archives & Karnataka State Tourism Board.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Tudor-revival stone towers and battlements of Bangalore Palace',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1537 – 1638 CE',
      title: 'Kempe Gowda & Vijayanagara Feudatory',
      description: 'Chieftain Kempe Gowda I establishes a mud fort and four boundary watchtowers, creating the city’s Pete commercial grid and early lake reservoirs.',
      keySites: ['Kempe Gowda Watchtowers', 'Bull Temple', 'Bangalore Fort site']
    },
    {
      epoch: '1761 – 1799 CE',
      title: 'Kingdom of Mysore: Hyder Ali & Tipu Sultan',
      description: 'Bangalore Fort is rebuilt in stone. Tipu develops botanical collections at Lalbagh, establishes weapons foundries, and builds his teakwood summer residence.',
      keySites: ['Tipu Sultan’s Summer Palace', 'Lalbagh Glass House early site', 'Stone Fort Bastion']
    },
    {
      epoch: '1809 – 1947 CE',
      title: 'The British Cantonment & Science Capital',
      description: 'A vast military cantonment develops east of the pete, giving rise to leafy bungalows, clubs, and schools. J.N. Tata and the Wadiyars establish the Indian Institute of Science (IISc) in 1909.',
      keySites: ['Cubbon Park', 'Attara Kacheri', 'IISc Main Building', 'MG Road & Brigade Road']
    },
    {
      epoch: 'Post-1980s',
      title: 'Electronic City & Global IT Transformation',
      description: 'Public sector aerospace and defense laboratories (HAL, ISRO, DRDO) lay the groundwork for India’s software revolution, transforming Bangalore into a global tech hub.',
      keySites: ['HAL Aerospace Museum', 'ISRO Headquarters', 'Outer Ring Road tech corridors']
    }
  ],

  architecturalHeritageOverview: 'Bengaluru’s urban fabric is an intriguing dialogue between 16th-century granite pete shrines, 18th-century carved teak Indo-Islamic summer palaces, neoclassical and Tudor colonial cantonment halls, and mid-20th-century socialist-monumental structures like the neo-Dravidian granite Vidhana Soudha.',

  traditionsAndFestivals: [
    {
      title: 'Bengaluru Karaga Shaktyotsava',
      seasonOrFrequency: 'Chaitra Poornima (March – April, midnight)',
      description: 'A centuries-old nocturnal festival of the Thigala community celebrating Draupadi. A designated priest, dressed in female attire, carries a towering floral pyramid (the Karaga) on his head without touching it with hands, visiting both historic Hindu temples and the 300-year-old Hazrat Tawakkal Mastan Dargah in a profound display of communal harmony.',
      visitorEtiquette: 'Takes place after midnight through the dense lanes of the old Pete; observe with quiet respect and avoid obstructing the procession route.'
    },
    {
      title: 'Kadalekai Parishe (Groundnut Fair)',
      seasonOrFrequency: 'Last Monday of Karthika month (November)',
      description: 'The historic groundnut harvest fair held around the Bull Temple in Basavanagudi. Farmers pile mountains of roasted, spiced, and raw peanuts on temple avenues, accompanied by traditional clay toys and sugarcane juice.',
      visitorEtiquette: 'Carry a cloth bag to purchase freshly roasted nuts; public transport is strongly advised due to heavy pedestrian footfall.'
    }
  ],

  dishes: [
    {
      id: 'blr-bisi-bele-bath',
      name: 'Mysuru Bisi Bele Bath',
      localName: 'ಬಿಸಿ ಬೇಳೆ ಬಾತ್',
      culturalOrigin: 'Born in the royal kitchens of the Mysore Palace over 300 years ago, perfected in Bengaluru darshinis.',
      description: 'A comforting, slow-cooked one-pot porridge of short-grain rice, toor dal, and assorted vegetables simmered with a complex house masala of 30 freshly roasted spices, kapok buds (marathi moggu), tamarind, and fresh grated coconut, drenched in golden pure ghee and topped with crunchy fried boondi.',
      typicalIngredients: ['Short-grain rice', 'Toor dal', 'Marathi moggu (kapok bud)', 'Tamarind', 'Pure ghee', 'Boondi'],
      isVeg: true,
      whereToFind: 'Mavalli Tiffin Room (MTR, Lalbagh), Maiyas (Jayanagar), Brahmins’ Coffee Bar (Shankarapuram).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Heavy on pure cow ghee. Nutty and richly spiced without scorching chilli heat.',
      etiquetteTips: 'Eat warm with a side spoon of sweet raita and fried potato chips or boondi for contrasting texture.',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'blr-benne-masala-dosa',
      name: 'Crispy Benne Masala Dosa',
      localName: 'ಬೆಣ್ಣೆ ಮಸಾಲ ದೋಸೆ',
      culturalOrigin: 'Developed in Davanagere and refined in iconic Basavanagudi and Malleshwaram tiffin rooms.',
      description: 'Unlike thin paper dosas, the Bengaluru masala dosa features a thick, fermented rice-and-urad batter that cooks to a deep mahogany crisp outside while remaining soft and spongy inside. Slathered generously with white unsalted country butter (benne), smeared with spicy red garlic-chana dal chutney, and folded over fragrant spiced potato palya.',
      typicalIngredients: ['Fermented rice-dal batter', 'White butter (benne)', 'Red garlic chutney', 'Potato palya', 'Coconut chutney'],
      isVeg: true,
      whereToFind: 'Vidyarthi Bhavan (Gandhi Bazaar), Central Tiffin Room / Shri Sagar (CTR, Malleshwaram), Taaza Thindi (Jayanagar).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Sambar is traditionally omitted at classic spots like CTR and Vidyarthi Bhavan, which serve it exclusively with fresh thick coconut chutney.',
      etiquetteTips: 'Do not ask for sambar at Vidyarthi Bhavan or CTR; they consider their fresh coconut chutney the pure traditional pairing.',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'blr-filter-kaapi',
      name: 'South Indian Filter Kaapi',
      localName: 'ಫಿಲ್ಟರ್ ಕಾಫಿ',
      culturalOrigin: 'Brought to Karnataka in the 17th century by saint Baba Budan who smuggled seven raw coffee beans from Yemen; transformed into a cultural ritual in the 1930s.',
      description: 'A rich, scalding brew made by steeping dark-roasted Arabica and Robusta beans blended with chicory (15–20%) in a traditional brass drip filter. The potent decoction is frothed vigorously with boiling full-cream milk between a stainless steel or brass tumbler and dabarah (saucer) to create a thick, velvety crown of aromatic foam.',
      typicalIngredients: ['Dark-roasted coffee-chicory blend', 'Fresh boiled full-cream milk', 'Sugar', 'Brass filter decoction'],
      isVeg: true,
      whereToFind: 'Brahmins’ Coffee Bar, Indian Coffee House (Church Street), Vidyarthi Bhavan, Brahmin’s Thatte Idli.',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Can be ordered "strong" (less milk) or "without sugar" on request.',
      etiquetteTips: 'Pour back and forth between tumbler and dabarah from a height to cool the coffee and aerate the crema before drinking.',
      image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Basavanagudi & Gandhi Bazaar',
      character: 'The historic intellectual hub of old Bangalore, famed for hundred-year-old vegetarian tiffin rooms, spice merchants, and Carnatic music.',
      bestTime: 'Early morning 7:00 AM – 10:30 AM and Evening 5:00 PM – 8:00 PM.',
      highlights: ['Crispy benne masala dosa at Vidyarthi Bhavan', 'Idli-vada at Brahmins’ Coffee Bar', 'Kalyani bakery khara buns'],
      visitorAdvice: 'Expect weekend queues of 30–45 minutes at Vidyarthi Bhavan; take a token number at the front desk.'
    },
    {
      name: 'VV Puram Thindi Beedi (Food Street)',
      character: 'A single lively pedestrian street in Sajjan Rao Circle offering over 25 vegetarian street stalls serving South Indian, Rajasthani, and fusion delicacies.',
      bestTime: 'Evening 6:30 PM until 11:00 PM.',
      highlights: ['Hot paddus at VB Bakery corner', 'Congress Kadlekai (spiced split peanuts)', 'Gulkand ice cream with butter'],
      visitorAdvice: 'Strictly vegetarian street; park at National College grounds and walk 500m to the entrance.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Bengaluru is safe for independent travelers, with a large cosmopolitan student and IT professional population.',
      'Bengaluru’s infamous road traffic can double transit times between 8:30–11:00 AM and 5:30–8:30 PM; always prioritize the Namma Metro when traversing central routes.',
      'Sudden pre-monsoon thunderstorm downpours (April – May) can cause localized waterlogging on underpasses; monitor civic advisories during heavy storms.'
    ],
    transportPedestrian: [
      'Namma Metro connects Purple (East-West) and Green (North-South) corridors with high reliability and air-conditioning.',
      'Auto-rickshaw drivers may refuse meters for long suburban trips; use app-based aggregators (Namma Yatri, Ola, Uber) for transparent pricing.',
      'Sidewalk conditions vary significantly: pedestrian paths on Church Street and Brigade Road are paved and walkable, while outer suburbs often lack dedicated footpaths.'
    ],
    nightTravel: [
      'Indiranagar (100ft Road and 12th Main), Koramangala, and Church Street are active, well-lit, and lively with diners until 1:00 AM.',
      'App-based cabs operate 24/7 with dependable pick-ups from Kempegowda International Airport (BLR).'
    ],
    accessibilityNotes: [
      'Namma Metro stations feature tactile pavers, braille elevator buttons, and wheelchair-accessible wide automatic gates.',
      'Cubbon Park and Lalbagh Botanical Gardens are among the most accessible public outdoor parks in India.'
    ],
    emergencyContacts: [
      { title: 'Karnataka State Police Emergency', number: '112', note: '24/7 unified emergency dispatch' },
      { title: 'Women Help Line Bengaluru', number: '1091', note: 'Parihar Family Counselling & Women Safety' },
      { title: 'Ambulance Emergency', number: '108', note: 'Karnataka GVK Emergency Services' },
      { title: 'BBMP Disaster Control', number: '080 2266 0000', note: 'Municipal tree falls and stormwater flooding' }
    ],
    limitationsDisclaimer: 'Information is synthesized from BBMP civic records, Bengaluru City Police notifications, and Bangalore Metro Rail Corporation data.'
  },

  neighbourhoods: [
    {
      id: 'blr-basavanagudi',
      name: 'Basavanagudi & Shankarapuram',
      cityId: 'bengaluru',
      character: 'Old-world South Bengaluru heritage district with temple tanks, leafy gulmohar streets, Sanskrit institutions, and generational tiffin houses.',
      budgetTier: 'Budget-friendly',
      transitScore: 'Very High (Served by National College & Lalbagh Metro stations)',
      transitDetails: 'Direct Green Line Metro access; short auto ride to Swargate and City Market.',
      walkabilityRating: 'High (Shaded residential streets, wide pedestrian tree walks around Gandhi Bazaar).',
      accessibilityNotes: 'Level streets with tree canopies; traditional temple stairs require climbing.',
      heritageHighlights: ['Bull Temple', 'Bugle Rock', 'Gokhale Institute of Public Affairs', 'Karanji Anjaneya Temple'],
      foodHighlights: ['Vidyarthi Bhavan', 'Brahmins’ Coffee Bar', 'Subbamma Stores for traditional podis'],
      greenSpaceNotes: 'Bugle Rock Park, MN Krishna Rao Park, and proximity to Lalbagh.',
      safetyContext: 'Exceptionally safe residential environment with active generational community watch.',
      methodologyNote: 'Evaluated using heritage conservation listings, tree shade percentage, and public transit connectivity.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'blr-indiranagar',
      name: 'Indiranagar & 100 Feet Road',
      cityId: 'bengaluru',
      character: 'Vibrant, upscale lifestyle and design hub with independent boutique fashion, specialty microbreweries, third-wave coffee roasters, and tree-lined avenues.',
      budgetTier: 'Upscale / High-end',
      transitScore: 'Very High (Indiranagar Metro Station directly on the Purple Line)',
      transitDetails: 'Quick 15-minute Metro connection to MG Road and Cubbon Park; abundant app cabs.',
      walkabilityRating: 'Moderate to High (100 Feet Road and 12th Main have commercial sidewalks, but traffic is steady).',
      accessibilityNotes: 'Most modern cafes and gastro-pubs offer level street-level entry.',
      heritageHighlights: ['HAL Aerospace Museum (nearby)', 'Vintage mid-century residential architecture'],
      foodHighlights: ['Toit Microbrewery', 'Maverick & Farmer Coffee', 'Carnatic fusion kitchens'],
      greenSpaceNotes: 'Defence Colony parks and tree-lined residential cross-streets.',
      safetyContext: 'High social safety day and night due to active cafe culture and regular police patrols.',
      methodologyNote: 'Based on commercial lifestyle amenity concentration and transit accessibility scores.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'blr-malleshwaram',
      name: 'Malleshwaram Heritage Grid',
      cityId: 'bengaluru',
      character: 'Traditional north-central neighbourhood laid out in 1898, famed for its classical dance academies, ancient Kadu Malleshwara Shiva temple, and saree bazaars.',
      budgetTier: 'Moderate',
      transitScore: 'Very High (Sampige Road and Kuvempu Road Metro stations on the Green Line)',
      transitDetails: 'Excellent Metro and BMTC bus connectivity along Sampige Road and Margosa Road.',
      walkabilityRating: 'High (Historic grid with alternating cross-streets; 8th Cross is a bustling pedestrian shopping corridor).',
      accessibilityNotes: 'Temple complexes have stone steps; sidewalks on Margosa Road are shaded and reasonably continuous.',
      heritageHighlights: ['Kadu Malleshwara Temple (17th century)', 'Sankey Tank reservoir', 'MES College campus'],
      foodHighlights: ['Central Tiffin Room (CTR / Shri Sagar)', 'Veena Stores', 'Janatha Hotel'],
      greenSpaceNotes: 'Sankey Tank offers an exceptional 2 km perimeter walking promenade around tree-lined waters.',
      safetyContext: 'One of Bengaluru’s safest traditional residential neighborhoods.',
      methodologyNote: 'Calculated from historical urban grid surveys and pedestrian recreational infrastructure.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-blr-watchtowers',
      cityId: 'bengaluru',
      title: 'The Prophecy of Four Towers: Kempe Gowda’s 1537 Vision',
      preview: 'Why a 16th-century feudal chieftain built four stone watchtowers on isolated hillocks, predicting his muddy outpost would one day engulf them all.',
      fullArticle: 'In 1537, when Kempe Gowda I founded his mud fort of Bengaluru, the settlement was a modest cluster of weavers, potters, and oil merchants surrounded by dry scrub forests and rocky granite outcrops. According to local historical chronicles, Kempe Gowda erected four stone watchtowers at what were then the extreme wilderness boundaries: one atop the monolithic rock at Lalbagh in the south, one overlooking Kempambudhi lake in the west, one at Ulsoor lake in the east, and one on the hillock at Mekhri Circle in the north. He prophesied that the day the city expanded beyond these four sentry towers, Bengaluru would meet cosmic transformation. Today, all four watchtowers still stand intact, but the city has expanded thirty kilometres past every single one, swallowing the four towers into the geographic center of an eleven-million-strong global metropolis.',
      locationName: 'Lalbagh, Ulsoor, Kempambudhi & Mekhri Circle',
      factualExplanation: 'Documented in epigraphic records by B.L. Rice in Epigraphia Carnatica and preserved as protected municipal monuments.',
      sources: ['Epigraphia Carnatica, Vol. IX', 'Bangalore Historical Society Monograph Series'],
      relatedDestinationIds: ['blr-lalbagh', 'blr-bull-temple'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Stone watchtower on ancient granite hill in Bengaluru'
    },
    {
      id: 'story-blr-krumbiegel-trees',
      cityId: 'bengaluru',
      title: 'Serial Blooming: The German Botanist Who Painted the City in Petals',
      preview: 'How Gustav Krumbiegel engineered Bengaluru’s tree canopy so that a different colour blossoms every single month of the year.',
      fullArticle: 'If Bengaluru’s avenues appear like an Impressionist canvas, it is thanks to the genius of Gustav Hermann Krumbiegel (1865–1956), a German botanist invited by the Maharaja of Mysore in 1908 to become Superintendent of Lalbagh. Krumbiegel conceived an innovative urban design philosophy known as "serial blooming". Instead of planting uniform street trees, he meticulously selected species from South America, Africa, and Southeast Asia whose flowering seasons followed in strict succession. In January, the pink trumpets of Tabebuia rosea erupt; in March, the fiery orange of the Gulmohar ignites; in April, the mauve canopies of Jacaranda mimosifolia take over; and in May, the golden cascades of the Cassia fistula illuminate the boulevards. Krumbiegel gave Bengaluru not merely shade, but an ever-shifting botanical calendar painted across the sky.',
      locationName: 'Lalbagh & Cubbon Park',
      factualExplanation: 'Detailed in Karnataka Department of Horticulture archives and Krumbiegel’s personal planting journals.',
      sources: ['Lalbagh Botanical Gardens Historical Archives', 'Gustav Krumbiegel Centennial Documentation by INTACH'],
      relatedDestinationIds: ['blr-lalbagh', 'blr-cubbon-park'],
      readTimeMinutes: 3,
      image: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Pink blossoming trees in urban park'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '15°C – 28°C', advice: 'Delightful weather; cool mornings and mild sunny days ideal for walking heritage trails and visiting open gardens.' },
      { season: 'Monsoon (Jun – Sep)', temperatureRange: '20°C – 27°C', advice: 'Pleasant overcast skies and refreshing showers; parks turn lush emerald green. Carry a compact umbrella.' },
      { season: 'Summer (Mar – May)', temperatureRange: '22°C – 36°C', advice: 'Warmer, but significantly cooler than coastal or northern plains due to the 920m elevation.' }
    ],
    transportInfrastructure: [
      { mode: 'Namma Metro', coverage: 'Purple Line (Whitefield to Challaghatta) and Green Line (Nagasandra to Silk Institute)', tip: 'Best way to cross East-West and North-South without being trapped in highway bottlenecks.' },
      { mode: 'Vayu Vajra Airport Buses (BMTC)', coverage: 'Direct air-conditioned Volvo buses connecting Kempegowda Airport (BLR) to all major city zones', tip: 'Cost-effective, reliable, and equipped with luggage racks.' },
      { mode: 'Auto-Rickshaws & App Cabs', coverage: 'Ubiquitous', tip: 'Use Namma Yatri or Uber/Ola to avoid street fare disputes.' }
    ],
    environmentalNotes: 'Air quality in Bengaluru is generally moderate (AQI 50–90), helped by generous tree canopy and plateau winds. Lake health is monitored by KSPCB; several historic lakes (Jayanagar, Sankey, Agara) feature well-maintained walking perimeters.',
    dataAttribution: 'Bruhat Bengaluru Mahanagara Palike (BBMP) & Karnataka State Pollution Control Board'
  }
};
