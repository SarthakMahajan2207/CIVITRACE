import React, { useState } from 'react';
import { BookOpen, Clock, ArrowRight, X, ExternalLink, ShieldCheck, MapPin } from 'lucide-react';
import { CityStory, Destination } from '../types';

interface CityStoriesSectionProps {
  cityName: string;
  stories: CityStory[];
  destinations: Destination[];
  onOpenDestination: (destination: Destination) => void;
}

export const CityStoriesSection: React.FC<CityStoriesSectionProps> = ({
  cityName,
  stories,
  destinations,
  onOpenDestination,
}) => {
  const [activeStory, setActiveStory] = useState<CityStory | null>(null);

  const handleOpenStory = (story: CityStory) => {
    setActiveStory(story);
  };

  return (
    <section id="stories" className="py-16 sm:py-24 bg-[#0a0e17] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
            <BookOpen className="w-4 h-4" />
            <span>Narrative Dispatches</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
            City Stories & Editorial Chronicles of {cityName}
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Thoughtful long-form essays, hidden engineering breakthroughs, and untold cultural chronicles that reveal what makes {cityName} distinctive.
          </p>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {stories.map((story) => (
            <div
              key={story.id}
              className="group rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 overflow-hidden flex flex-col justify-between shadow-xl transition-all duration-300"
            >
              <div>
                {/* Story Image */}
                <div className="relative h-56 w-full overflow-hidden bg-slate-950">
                  <img
                    src={story.image}
                    alt={story.imageAlt || story.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-85 group-hover:opacity-100"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                  {/* Read time */}
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur-md border border-slate-700 text-amber-200 text-xs font-medium flex items-center gap-1 shadow-md">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>{story.readTimeMinutes} min read</span>
                  </div>

                  {/* Location Tag */}
                  <div className="absolute bottom-3 left-4 flex items-center gap-1 text-xs text-slate-300">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>{story.locationName}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-3">
                  <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white group-hover:text-amber-300 transition-colors leading-tight">
                    {story.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-3">
                    {story.preview}
                  </p>
                </div>
              </div>

              {/* Card Footer */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => handleOpenStory(story)}
                  className="flex items-center gap-2 text-xs font-semibold text-amber-400 hover:text-amber-300 group-hover:underline transition-colors"
                >
                  <span>Read Full Editorial Chronicle</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Expanded Story Reading Modal */}
      {activeStory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div
            className="fixed inset-0 bg-black/85 backdrop-blur-md transition-opacity"
            onClick={() => setActiveStory(null)}
          />

          <div className="relative w-full max-w-3xl bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10 animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="relative h-56 sm:h-64 w-full bg-slate-950 shrink-0 overflow-hidden">
              <img
                src={activeStory.image}
                alt={activeStory.imageAlt || activeStory.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-[#0f172a]/50 to-transparent" />

              <button
                onClick={() => setActiveStory(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors shadow-lg"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 block mb-1">
                  Editorial Chronicle • {cityName}
                </span>
                <h3 className="text-2xl sm:text-3xl font-editorial font-bold text-white">
                  {activeStory.title}
                </h3>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-200">
              {/* Lead Summary */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-sm sm:text-base italic font-serif text-amber-100/90 leading-relaxed">
                "{activeStory.preview}"
              </div>

              {/* Full Article Text */}
              <div className="space-y-4 text-sm sm:text-base text-slate-300 leading-relaxed">
                <p className="first-letter:text-4xl first-letter:font-editorial first-letter:font-bold first-letter:text-amber-400 first-letter:mr-2 first-letter:float-left">
                  {activeStory.fullArticle}
                </p>
              </div>

              {/* Factual Explanation vs Editorial Reflection */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
                <span className="font-semibold text-teal-400 flex items-center gap-1.5 uppercase tracking-wider">
                  <ShieldCheck className="w-3.5 h-3.5" /> Factual Basis & Historical Context:
                </span>
                <p className="text-slate-300 leading-relaxed">{activeStory.factualExplanation}</p>
              </div>

              {/* Sources */}
              {activeStory.sources && activeStory.sources.length > 0 && (
                <div className="pt-3 border-t border-slate-800 text-xs">
                  <span className="text-slate-400 font-semibold block mb-1">Verified References & Archives:</span>
                  <ul className="space-y-1 text-slate-400">
                    {activeStory.sources.map((s, i) => (
                      <li key={i}>• {s}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Related Destinations */}
              {activeStory.relatedDestinationIds && activeStory.relatedDestinationIds.length > 0 && (
                <div className="pt-3 border-t border-slate-800">
                  <span className="text-xs text-slate-400 font-semibold block mb-2">Related Cultural Destinations:</span>
                  <div className="flex flex-wrap gap-2">
                    {activeStory.relatedDestinationIds.map((destId) => {
                      const related = destinations.find((d) => d.id === destId);
                      if (!related) return null;
                      return (
                        <button
                          key={destId}
                          onClick={() => {
                            setActiveStory(null);
                            onOpenDestination(related);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-medium transition-colors flex items-center gap-1"
                        >
                          <MapPin className="w-3 h-3" />
                          <span>{related.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>CIVITRACE Editorial Guild</span>
              <button
                onClick={() => setActiveStory(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium"
              >
                Close Chronicle
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
