import { City } from '../../types';

export const goaData: City = {
  id: 'goa',
  name: 'Goa',
  state: 'Goa',
  region: 'Konkan Coast & Western Ghats Foothills',
  tagline: 'Indo-Portuguese Maritime Crossroads & Konkan Heartland',
  heroDescription: 'Beyond the superficial resort clichés lies a 450-year Indo-Portuguese civilizational tapestry. Goa is not a single city but a distinctive state comprising historic sub-regions: the colonial "Velhas Conquistas" (Old Conquests of Ilhas, Bardez, and Salcete) with their baroque churches, azulejo-tiled Latin quarters, and emerald paddy fields, and the lush "Novas Conquistas" reaching into the sacred Western Ghats spice groves and ancient rock sanctuaries.',
  introSentence: 'A coastal cultural confluence where Portuguese baroque basilicas, Konkani temple tanks, ancestral riverside estates, and vibrant fishing villages breathe together.',
  coordinates: [15.4989, 73.8278],
  accentColor: 'teal',
  hexAccent: '#0d9488',
  heroImage: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Colourful Portuguese villas and azulejo tiles in Fontainhas Latin Quarter, Goa',
  imageCredit: 'Unsplash / Goa Heritage Action Group',
  heritageThemes: ['Velhas Conquistas vs Novas Conquistas Regional Dynamics', 'UNESCO Baroque Churches of Old Goa', 'Fontainhas Latin Quarter Urbanism', 'Ancestral Indo-Portuguese Havelis & Balcãos', 'Saraswat & Christian Konkani Gastronomy'],

  destinations: [
    {
      id: 'goa-bom-jesus',
      name: 'Basilica of Bom Jesus (Old Goa)',
      cityId: 'goa',
      category: 'History & Heritage',
      shortSummary: 'UNESCO World Heritage 1605 Jesuit baroque basilica preserving the relics of St. Francis Xavier.',
      fullDescription: 'Consecrated in 1605 in the former Portuguese colonial capital of Velha Goa, the Basilica of Bom Jesus is one of the oldest churches in India and a supreme exemplar of Renaissance and Baroque architecture in Asia. Built of rich dark laterite stone left unplastered on its exterior, the facade exhibits classical Doric, Ionic, and Corinthian orders embellished with basalt carvings. Inside, beneath a simple timber ceiling, stands an immense gilded reredos depicting St. Ignatius of Loyola and the infant Jesus. In the southern transept lies the silver casket containing the sacred mortal remains of St. Francis Xavier, co-founder of the Society of Jesus, crafted by 17th-century Goan silversmiths.',
      historicalBackground: 'Construction began in 1594 and was consecrated in May 1605 by Dom Fr. Aleixo de Menezes. Inscribed as a UNESCO World Heritage site under "Churches and Convents of Goa" in 1986.',
      culturalSignificance: 'The pre-eminent spiritual shrine of Goan Christians and a global Catholic pilgrimage destination, celebrated during the decennial sacred exposition.',
      architecturalFeatures: 'Unplastered exposed laterite stone facade, basalt doorway carvings, towering three-tiered retable, Tuscan pilasters, and carved wooden pulpit.',
      whyWorthVisiting: 'Experience the astonishing scale of 17th-century maritime Goa when Old Goa was renowned across Europe as "Goa Dourada" (Golden Goa).',
      whatToExperience: 'Study the exposed laterite craftsmanship of the facade, view the silver reliquary of St. Francis Xavier, walk through the adjoining Jesuit art gallery, and cross the lawn to Sé Cathedral.',
      location: 'Old Goa Road, Bainguinim, Goa 403402',
      coordinates: [15.5009, 73.9116],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Morning (9:00 AM – 11:30 AM) to beat midday coastal heat and afternoon tour crowds.',
      entryFeeInfo: 'Free church entry; modern art gallery ₹10 (ASI monument).',
      openingHoursInfo: 'Monday to Saturday: 9:00 AM – 6:30 PM; Sunday: 10:30 AM – 6:30 PM.',
      accessibilityInfo: 'Stone ramp provides wheelchair access at the side portal; interior nave floor is smooth stone and level.',
      familySuitability: 'Solemn and serene; please dress respectfully (cover shoulders and knees).',
      photographyNotes: 'Exterior photography is allowed; flash photography inside the Xavier chapel is prohibited.',
      nearbyCombinations: ['Sé Cathedral', 'Church of St. Francis of Assisi', 'Ruins of Church of St. Augustine'],
      transitAdvice: 'Take a KTC bus from Panaji Kadamba Bus Terminal to Old Goa (9 km, 20 mins) or an auto-rickshaw/cab.',
      visitorTips: ['Strict dress code enforced: sleeveless tops, short skirts, or beachwear are not permitted.', 'Combine with a walk up Monte Santo (Holy Hill) to the evocative ruins of St. Augustine’s belfry tower.'],
      officialLinks: [{ title: 'UNESCO World Heritage — Churches and Convents of Goa', url: 'https://whc.unesco.org/en/list/234' }],
      sourceNote: 'Archaeological Survey of India & Archdiocese of Goa and Daman.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Exposed dark laterite facade of the Basilica of Bom Jesus in Old Goa',
      imageCredit: 'Unsplash'
    },
    {
      id: 'goa-fontainhas',
      name: 'Fontainhas Latin Quarter (Panaji)',
      cityId: 'goa',
      category: 'Architecture',
      shortSummary: 'Asia’s only preserved Latin Quarter, boasting 19th-century pastel mansions, red-tiled roofs, and azulejos.',
      fullDescription: 'Nestled at the base of Altinho hill along the Ourem Creek in Panaji, Fontainhas is a living heritage precinct that feels transported from southern Europe. Established in the late 18th century by Antonio Joao de Sequeira after epidemics forced the abandonment of Old Goa, Fontainhas was formally recognized as a conservation zone in 1984. Its narrow, winding cobblestone streets are flanked by two- and three-storey houses washed in vibrant Portuguese pastel shades of cadmium yellow, ultramarine blue, olive green, and terracotta red. Distinctive architectural signatures include projecting balcãos (covered street-facing verandahs where families greet neighbors), wrought-iron balconies, oyster-shell window panes (carepas), and hand-painted blue ceramic house nameplates (azulejos).',
      historicalBackground: 'Named after the freshwater spring (Fonte Phoenix) that flowed from Altinho hill. It evolved into the residential heart of the Goan Catholic and administrative intelligentsia.',
      culturalSignificance: 'The premier surviving urban ensemble of Portuguese domestic architecture in India, celebrated in literature, art, and music.',
      architecturalFeatures: 'Balcão street-verandahs, mother-of-pearl window panes, hand-glazed azulejo ceramic tiles, curved red Mangalore tile gables, and decorative plaster moldings.',
      whyWorthVisiting: 'A delightful, peaceful walking district where travelers can appreciate authentic residential conservation, heritage cafes, and family bakeries.',
      whatToExperience: 'Take an unhurried morning walking tour, admire the 1818 Chapel of St. Sebastian with its rare open-eyed crucifix, visit 31st January Bakery for freshly baked pasteis de nata, and visit Gitanjali Gallery.',
      location: 'Fontainhas, Panaji, North Goa 403001',
      coordinates: [15.4989, 73.8315],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Early morning (7:30 AM – 9:30 AM) for golden morning light and quiet streets, or late afternoon (4:30 PM – 6:30 PM).',
      entryFeeInfo: 'Free public neighbourhood.',
      openingHoursInfo: 'Open public streetscape; keep voices low to respect residential privacy.',
      accessibilityInfo: 'Streets are generally flat stone asphalt; sidewalks are narrow with occasional high curbs.',
      familySuitability: 'Charming and safe for all ages; watch for occasional slow scooter traffic in narrow lanes.',
      photographyNotes: 'Sensational architectural color and texture; respect homeowner privacy and do not climb onto private residential balcão steps.',
      nearbyCombinations: ['Our Lady of the Immaculate Conception Church', 'Altinho Viewpoint', 'Mandovi River Promenade'],
      transitAdvice: 'Walking distance (800m) from Panaji city center and the main Kadamba bus station.',
      visitorTips: ['Never enter private compounds or residential porches without permission.', 'Stop by Confeitaria 31 De Janeiro for authentic Goan bebinca and coconut bolinhas.'],
      officialLinks: [{ title: 'Goa Heritage Action Group', url: 'https://goaheritageactiongroup.org' }],
      sourceNote: 'Goa Heritage Action Group & Town and Country Planning Department.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Colourful yellow and blue painted Portuguese villas in Fontainhas, Goa',
      imageCredit: 'Unsplash'
    },
    {
      id: 'goa-shanta-durga',
      name: 'Shree Shantadurga Temple (Kavlem, Ponda)',
      cityId: 'goa',
      category: 'Spiritual & Sacred',
      shortSummary: '1738 Indo-Portuguese Hindu temple dedicated to the goddess of peace who reconciled Shiva and Vishnu.',
      fullDescription: 'Located in the verdant foothills of Kavlem in the Ponda taluka (part of the Novas Conquistas), this magnificent temple complex is dedicated to Shantadurga, the mediator goddess who stepped between fighting forms of Lord Shiva and Lord Vishnu to restore cosmic harmony. When the Portuguese Inquisition banned Hindu rites and demolished temples in Salcete during the 1560s, devotees smuggled the sacred idol under the cover of night across the Zuari river into the territory of the Hindu Adilshahi Sultanate. The current temple, built in 1738 under the patronage of Maratha ruler Shahu Maharaj, exhibits an extraordinary hybrid architecture: European vaulted roofs and Roman arched windows crowned by a pagoda-like dome, paired with an exquisite multi-tiered octagonal deepstambha (lamp tower) standing in front of the temple tank.',
      historicalBackground: 'The deity was originally worshipped at Quelossim in Salcete before fleeing Portuguese persecution in 1566. Consecrated at Kavlem with Maratha royal support.',
      culturalSignificance: 'The pre-eminent spiritual sanctuary for the Goan Saraswat diaspora, symbolizing cultural survival and resilience.',
      architecturalFeatures: 'Saraswat temple design with European baroque adaptations: arched windows, red-brick balustrades, classical pilasters, and a pyramidal central dome beside an octagonal white deepstambha.',
      whyWorthVisiting: 'Reveals the profound, often-overlooked Hindu heritage of Goa and showcases a unique architectural synthesis found nowhere else in India.',
      whatToExperience: 'Walk around the peaceful temple water tank, admire the white tiered deepstambha illuminated with oil lamps on festival nights, and observe morning aarti with traditional pakhawaj drumming.',
      location: 'Kavlem, Ponda, Central Goa 403401',
      coordinates: [15.3855, 73.9928],
      suggestedDuration: '1.5 hours',
      bestTimeToVisit: 'Morning (8:30 AM – 11:30 AM) when prayers are chanted and temple halls are cool.',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Open daily: 6:00 AM – 8:30 PM.',
      accessibilityInfo: 'Courtyard around the deepstambha is flat paved stone; gentle ramps lead to the outer sabha mandapa.',
      familySuitability: 'Deeply tranquil, respectful family and spiritual environment.',
      photographyNotes: 'Courtyard and deepstambha can be photographed; photography inside the inner garbhagriha is prohibited.',
      nearbyCombinations: ['Mangueshi Temple', 'Sahakari Spice Farm', 'Tambdi Surla Mahadev Temple (further east)'],
      transitAdvice: 'Located 28 km from Panaji and 18 km from Margao. Best reached via private taxi or KTC bus to Ponda followed by auto.',
      visitorTips: ['Strict dress code: conservative attire covering shoulders and legs is required.', 'Combine with a guided visit to a nearby organic spice plantation in Ponda for an authentic traditional Saraswat lunch served on banana leaves.'],
      officialLinks: [{ title: 'Shree Shantadurga Sansthan Kavlem', url: 'https://shreeshantadurga.com' }],
      sourceNote: 'Shantadurga Sansthan Religious Archives & Directorate of Archives and Archaeology Goa.',
      verifiedDate: 'September 2024',
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'White multi-tiered temple lamp tower and courtyard in Ponda, Goa',
      imageCredit: 'Unsplash'
    },
    {
      id: 'goa-fort-aguada',
      name: 'Fort Aguada & 17th-Century Lighthouse',
      cityId: 'goa',
      category: 'History & Heritage',
      shortSummary: 'Formidable 1612 Portuguese coastal citadel with 79 cannons and a massive 2.37-million-gallon freshwater cistern.',
      fullDescription: 'Constructed in 1612 at the mouth of the Mandovi river on the Sinquerim headland to defend Portuguese shipping against Maratha navies and Dutch fleets, Fort Aguada was the grandest fortress in Portuguese Asia. Its name derives from the Portuguese word for water (água); within its massive laterite walls lay a subterranean freshwater cistern capable of storing 2,376,000 gallons of drinking water—one of the largest in Asia at the time—which replenished passing ships that had sailed from Lisbon. The upper ramparts feature dry moats, gun embrasures for 79 heavy bronze cannons, and a four-storey circular stone lighthouse erected in 1864, the oldest of its kind in India.',
      historicalBackground: 'Built under the Viceroyalty of Dom Jerónimo de Azevedo. It successfully prevented Dutch fleets from blockading the Mandovi river across the 17th century.',
      culturalSignificance: 'A cornerstone of Goa’s colonial maritime defence network, offering sweeping views across the meeting point of river and ocean.',
      architecturalFeatures: 'Monolithic cut-laterite bastions, subterranean vaulted water cisterns, stone gun embrasures, and circular lighthouse.',
      whyWorthVisiting: 'Spectacular coastal panorama over the Arabian Sea, coupled with brilliant pre-industrial military and hydraulic engineering.',
      whatToExperience: 'Walk along the laterite battlements, inspect the ancient water cistern vents, visit the recently restored jail museum at the lower fort, and watch fishing trawlers cross the river bar.',
      location: 'Sinquerim, Candolim, North Goa 403515',
      coordinates: [15.4925, 73.7736],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Morning (8:30 AM – 10:30 AM) or sunset (5:00 PM – 6:30 PM) for ocean breezes.',
      entryFeeInfo: 'Upper Fort: ₹25 for Indian citizens, ₹300 for foreign visitors; Lower Fort Aguada Jail Museum has a separate ticket (₹100).',
      openingHoursInfo: 'Open daily: 9:00 AM – 6:00 PM.',
      accessibilityInfo: 'Upper fort perimeter has gravel pathways and uneven stone ramps; difficult for manual wheelchairs.',
      familySuitability: 'Great for families and history lovers; watch children near cliff parapets.',
      photographyNotes: 'Sunset over the Arabian Sea through the laterite gun slits; panoramic views over Sinquerim beach.',
      nearbyCombinations: ['Sinquerim Beach', 'Candolim heritage village', 'Reis Magos Fort'],
      transitAdvice: 'Take a cab or scooter from Candolim (3 km) or Panaji (15 km). Ample car parking available at the upper fort gate.',
      visitorTips: ['Wear comfortable shoes with grip; laterite stone can be abrasive and uneven.', 'Combine with Reis Magos Fort on the northern bank of the Mandovi, which has been beautifully restored into a cultural gallery.'],
      officialLinks: [{ title: 'Department of Tourism Goa — Fort Aguada', url: 'https://goatourism.gov.in' }],
      sourceNote: 'Archaeological Survey of India Goa Circle & Goa State Tourism.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Historic stone ramparts and lighthouse of Fort Aguada overlooking the sea',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '10th – 14th Century CE',
      title: 'Kadamba Dynasty & Chandor Capital',
      description: 'The indigenous Kadamba dynasty governs from Chandor (Chandrapur) and Gopakapattana on the Zuari river, fostering maritime trade with Arabia and building early stone temple architecture.',
      keySites: ['Tambdi Surla Mahadev Temple (12th c.)', 'Ancient Chandor ruins']
    },
    {
      epoch: '1510 – 1961 CE',
      title: 'Portuguese Rule (Velhas Conquistas & Golden Goa)',
      description: 'Afonso de Albuquerque captures Goa in 1510. Catholic orders build monumental churches in Old Goa; the 18th century expands control to the Novas Conquistas, blending European and Konkani cultures.',
      keySites: ['Basilica of Bom Jesus', 'Fontainhas', 'Fort Aguada', 'Ancestral Braganza House (Chandor)']
    },
    {
      epoch: '1961 CE – Present',
      title: 'Operation Vijay & Modern Statehood',
      description: 'The Indian Armed Forces liberate Goa on 19 December 1961. Goa attains full Indian statehood in 1987, maintaining its distinctive civil code and bilingual Portuguese-Konkani heritage.',
      keySites: ['Aguada Jail Freedom Memorial', 'Goa State Museum']
    }
  ],

  architecturalHeritageOverview: 'Goa’s architecture is uniquely defined by dark, porous ferruginous laterite stone quarried locally and coated in oyster-shell lime plaster. The domestic Portuguese-Goan houses are distinguished by their "balcãos" (street-facing open verandas), mother-of-pearl window panes, grand double staircases, and vibrant pigment facades.',

  traditionsAndFestivals: [
    {
      title: 'Goa Carnival (Intruz)',
      seasonOrFrequency: 'Four days before Lent (February)',
      description: 'The joyous pre-Lenten carnival introduced by the Portuguese, featuring King Momo leading colourful street floats, traditional brass bands, folk dances, and communal feasting in Panaji, Margao, and Vasco.',
      visitorEtiquette: 'Fun and celebratory; streets are packed; secure mobile phones in deep pockets.'
    },
    {
      title: 'Shigmotsav (Goan Shigmo)',
      seasonOrFrequency: 'Phalguna month (March, 14 days)',
      description: 'The vibrant indigenous Konkani spring harvest festival celebrating warrior returns and agricultural abundance. Village troupes perform Romtamel and Ghode Modni dances with huge colourful umbrellas (chattris) and flags.',
      visitorEtiquette: 'A respectful, authentic folk celebration; local villagers welcome onlookers who observe with reverence.'
    }
  ],

  dishes: [
    {
      id: 'goa-fish-curry-thali',
      name: 'Goan Fish Curry Rice Thali',
      localName: 'शित कोडी निस्तें (Xit Kodd’i Nuste)',
      culturalOrigin: 'The daily staple and culinary soul of every Goan home, both Hindu and Christian.',
      description: 'Steaming local unpolished red rice (ukda tandool) served with a vibrant orange curry of fresh Kingfish (surmai) or mackerel (bangdo) simmered with freshly grated coconut, dry Kashmiri chillies, coriander seeds, and tangy kokum or raw mango, accompanied by crispy rava-fried fish, kismur (dried prawn salad with coconut and onion), and cooling sol kadhi.',
      typicalIngredients: ['Fresh surmai or mackerel', 'Fresh coconut milk', 'Kokum (solam) / raw mango', 'Kashmiri chillies', 'Red ukda rice', 'Kismur'],
      isVeg: false,
      whereToFind: 'Ritz Classic (Panaji), Vinayak Family Restaurant (Assagao), Martin’s Corner (Betalbatim), Peep Kitchen.',
      priceCategory: 'Budget to Moderate',
      dietaryAdvice: 'Non-vegetarian (seafood). Rich in coconut and kokum; ask for moderate spice if unaccustomed to coastal chillies.',
      etiquetteTips: 'Pour the fish curry generously over the red rice and mix with your fingers for the true local experience.',
      image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'goa-pork-vindaloo',
      name: 'Authentic Goan Vindaloo & Poee',
      localName: 'गोवन विंदालू आणि पोई',
      culturalOrigin: 'Adapted from the Portuguese sailor dish "carne de vinha d’alhos" (meat with wine vinegar and garlic).',
      description: 'Unlike commercial Indian restaurant curries, genuine Goan vindaloo features tender chunks of pork marinated for hours in fermented Goan toddy vinegar, garlic, ginger, and a fiery paste of whole spices without any tomatoes. Served alongside warm, hollow Goan poee (traditional leavened wheat bread baked in wood-fired ovens).',
      typicalIngredients: ['Pork shoulder', 'Toddy palm vinegar', 'Kashmiri chillies', 'Garlic cloves', 'Cinnamon & cloves', 'Goan poee bread'],
      isVeg: false,
      whereToFind: 'Mum’s Kitchen (Panaji), Viva Panjim (Fontainhas), Nostalgia (Raia), Horseshoe (Panaji).',
      priceCategory: 'Moderate',
      dietaryAdvice: 'Non-vegetarian (pork). Rich and tangy due to palm vinegar; matures in flavor when eaten the following day.',
      etiquetteTips: 'Tear open the hollow poee bread and stuff it with vindaloo gravy for the perfect pairing.',
      image: 'https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'goa-bebinca',
      name: 'Traditional Goan Bebinca',
      localName: 'पारंपारिक बेबिका',
      culturalOrigin: 'Invented in the 17th century by Sister Bebiana at the Convent of Santa Monica in Old Goa.',
      description: 'Known as the Queen of Goan Desserts, bebinca is a rich, sixteen-layered pudding baked slowly layer by layer. Each delicate tier is made of refined flour, coconut milk, sugar, egg yolks, and nutmeg, browned carefully beneath overhead charcoal embers and brushed with pure ghee before the next layer is poured.',
      typicalIngredients: ['Thick coconut milk', 'Egg yolks', 'Pure ghee', 'Nutmeg powder', 'Sugar', 'Flour'],
      isVeg: false,
      whereToFind: 'Confeitaria 31 De Janeiro (Fontainhas), Simonia Stores, Mr. Baker 1922 (Panaji).',
      priceCategory: 'Moderate',
      dietaryAdvice: 'Contains egg yolks and dairy ghee. Long shelf life, making it the supreme gift from Goa.',
      etiquetteTips: 'Warm a slice slightly in an oven and serve with a scoop of vanilla ice cream.',
      image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Panaji: Fontainhas & Campal',
      character: 'Quaint lanes filled with hundred-year-old family-run tavernas, heritage bakeries, and upscale Indo-Portuguese dining.',
      bestTime: 'Lunch (12:30 PM – 3:30 PM) and Dinner (7:30 PM – 10:30 PM).',
      highlights: ['Prawn balchão at Viva Panjim', 'Bebinca at Confeitaria 31 De Janeiro', 'Seafood at Ritz Classic'],
      visitorAdvice: 'Viva Panjim has only a few tables in an intimate living room; arrive early or expect a short wait.'
    },
    {
      name: 'South Goa: Margao & Salcete Hinterland',
      character: 'The cultural center of Salcete Catholic cuisine, featuring legendary country restaurants and historic market fish sheds.',
      bestTime: 'Lunch 1:00 PM – 3:30 PM.',
      highlights: ['Chorizo pav at Margao Old Market', 'Stuffed crab at Nostalgia (Raia)', 'Seafood at Martin’s Corner'],
      visitorAdvice: 'Combine with an afternoon heritage mansion tour in Chandor (Braganza House).'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Goa has a very relaxed and welcoming atmosphere, but travelers must respect local sensibilities regarding dress codes when away from beach zones.',
      'Bathing suits and beachwear are not acceptable in town centres, churches, temples, or village streets; cover up with a sarong or light shirt.',
      'Strong sea riptides occur along open ocean beaches, especially between June and October during the southwest monsoon; only swim where green flags are posted by Drishti Marine lifeguards.'
    ],
    transportPedestrian: [
      'Renting two-wheelers (scooters/motorcycles) is widespread; always wear a strapped helmet by law and carry your driving license and vehicle registration.',
      'Goa does not have standard app-based metered aggregators like Uber or Ola; use the GoaMiles app or negotiate taxi fares with authorized tourist taxi stands before starting your trip.',
      'The Kadamba Transport Corporation (KTC) runs clean, inexpensive electric AC shuttle buses connecting Panaji, Margao, Mapusa, and the airports (Dabolim and MOPA).'
    ],
    nightTravel: [
      'Panaji, Candolim, and coastal village roads are peaceful and safe for night walks until late.',
      'Hinterland forest roads in Ponda and Sanguem have limited street lighting and wandering cattle; drive cautiously at night.'
    ],
    accessibilityNotes: [
      'Old Goa churches offer ramped access to main prayer halls, but village lanes in Fontainhas feature high curbs without ramps.',
      'Miramar and Colva beaches have paved sea promenade walkways suitable for wheelchairs.'
    ],
    emergencyContacts: [
      { title: 'Goa Police Central Emergency', number: '112', note: '24/7 centralized police dispatch' },
      { title: 'Tourist Police Helpdesk', number: '0832 242 6333', note: 'Assistance for visitors and hotel disputes' },
      { title: 'Drishti Ocean Lifesaving Service', number: '0832 241 4141', note: 'Beach emergencies and ocean rescues' },
      { title: 'Goa Medical College Hospital (Bambolim)', number: '0832 245 8727', note: 'Premier tertiary care hospital' }
    ],
    limitationsDisclaimer: 'Sourced from Goa Police Commissionerate notifications, Drishti Marine ocean safety reports, and Goa Tourism Department advisories.'
  },

  neighbourhoods: [
    {
      id: 'goa-panaji-fontainhas',
      name: 'Panaji City & Fontainhas Latin Quarter',
      cityId: 'goa',
      character: 'The state capital: a civilized, pedestrian-friendly riverfront city blending 19th-century colonial Latin lanes with relaxed civic promenades.',
      budgetTier: 'Moderate to Upscale',
      transitScore: 'High (Kadamba central bus terminal; direct electric airport shuttles; walkable downtown)',
      transitDetails: 'Direct bus connections across Goa; plentiful auto-rickshaws and pilot motorcycle taxis.',
      walkabilityRating: 'Very High (Shaded riverfront promenade along the Mandovi and intimate pedestrian lanes in Fontainhas).',
      accessibilityNotes: 'Mandovi promenade is wide, paved, and flat; Fontainhas lanes have cobblestones and narrow sidewalks.',
      heritageHighlights: ['Fontainhas Latin Quarter', 'Our Lady of the Immaculate Conception Church', 'Adil Shah Palace'],
      foodHighlights: ['Viva Panjim', 'Ritz Classic', 'Confeitaria 31 De Janeiro', 'Black Market'],
      greenSpaceNotes: 'Campal coastal gardens, Garcia de Orta municipal park, and Altinho hill canopy.',
      safetyContext: 'One of the safest, most tranquil state capitals in India with round-the-clock safety.',
      methodologyNote: 'Evaluated using urban conservation guidelines and municipal pedestrian quality audits.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'goa-salcete-chandor',
      name: 'Salcete Countryside & Chandor',
      cityId: 'goa',
      character: 'The aristocratic Catholic heartland of South Goa, characterized by vast ancestral mansions (casas senhoriais), lush paddy fields, and quiet village chapels.',
      budgetTier: 'Moderate',
      transitScore: 'Moderate (Requires private car, scooter, or hired taxi from Margao)',
      transitDetails: 'Margao railway station is 12 km away; quiet country roads with low traffic.',
      walkabilityRating: 'High for peaceful country strolls along village bunds and paddy fields.',
      accessibilityNotes: 'Level village terrain; ancestral heritage mansions have high front staircases.',
      heritageHighlights: ['Menezes Braganza House (17th c.)', 'Sara Fernandes Heritage House', 'Chandor Kadamba site'],
      foodHighlights: ['Nostalgia (Raia)', 'Fernando’s heritage dining', 'Village bakeries baking fresh poee'],
      greenSpaceNotes: 'Endless coconut groves, riverine backwaters, and seasonal bird sanctuaries.',
      safetyContext: 'Extremely peaceful rural community with strong generational neighbor watch.',
      methodologyNote: 'Based on rural heritage estate listings and ecotourism density data.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-goa-oyster-windows',
      cityId: 'goa',
      title: 'Windows of Mother-of-Pearl: The Craft of Carepas',
      preview: 'Why centuries-old Goan mansions don’t use glass in their windows, but translucent sea shells collected from the Zuari river estuary.',
      fullArticle: 'Before industrial plate glass was imported in the late 19th century, Goan builders faced a tropical challenge: how to allow natural daylight into grand rooms without admitting the scorching tropical sun or the driving monsoon rain. Their solution was an indigenous marine innovation called carepas. Craftsmen harvested the flat, translucent bivalve shells of the windowpane oyster (Placuna placenta) from the brackish mudflats of the Zuari river estuary. These shells were carefully ground into uniform wafer-thin squares and slotted into intricate lattice grooves carved from seasoned teakwood. The result is pure magic: outside, the shell panels deflect the blinding midday glare; inside, they cast a luminous, pearlescent glow across the red-oxide and timber floors, softening the coastal heat into serene sanctuary.',
      locationName: 'Fontainhas & Salcete Mansions',
      factualExplanation: 'Documented in architectural studies by the Goa Heritage Action Group and Fundação Oriente.',
      sources: ['Houses of Goa by Gerard da Cunha', 'Goa Heritage Action Group Monograph Series'],
      relatedDestinationIds: ['goa-fontainhas'],
      readTimeMinutes: 3,
      image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Mother-of-pearl shell window in historic Goan house'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '20°C – 32°C', advice: 'Peak season; clear blue skies, mild sea breezes, and pleasant humidity. Perfect for exploring heritage quarters and spice farms.' },
      { season: 'Monsoon (Jun – Sep)', temperatureRange: '24°C – 29°C', advice: 'Dramatic coastal downpours; lush emerald countryside, swollen waterfalls (Dudhsagar), and fewer crowds. Beautiful for relaxed cultural exploration.' },
      { season: 'Summer (Mar – May)', temperatureRange: '26°C – 35°C', advice: 'Warm and humid; plan outdoor walking before 10:00 AM or after 5:00 PM.' }
    ],
    transportInfrastructure: [
      { mode: 'Scooter / Motorcycle Rentals', coverage: 'Everywhere in Goa', tip: 'Most flexible way to explore villages. Ensure you receive a yellow-plate rental vehicle and wear a helmet.' },
      { mode: 'GoaMiles Taxi App', coverage: 'Panaji, airports, and major coastal towns', tip: 'Government-backed app offering standardized pricing without manual haggling.' },
      { mode: 'Kadamba Electric Buses', coverage: 'Intercity corridors between Panaji, Margao, Vasco, and Mapusa', tip: 'Air-conditioned, modern, and very inexpensive (₹20–₹50).' }
    ],
    environmentalNotes: 'Goa enjoys clean coastal air (AQI 30–60), filtered by the sea and the forested Western Ghats. Coastal protection zones (CRZ) protect backwater estuaries and mangrove ecosystems.',
    dataAttribution: 'Department of Tourism Government of Goa & Goa State Pollution Control Board'
  }
};
