import { City } from '../../types';

export const varanasiData: City = {
  id: 'varanasi',
  name: 'Varanasi',
  state: 'Uttar Pradesh',
  region: 'Middle Gangetic Plains',
  tagline: 'Kashi: The City of Light & Oldest Living Sacred Center',
  heroDescription: 'Perched along the crescent sweep of the holy Ganga as it bends northward toward the Himalayas, Varanasi (Kashi or Benares) is recognized as one of the world’s oldest continuously inhabited cities. Across 84 stone ghats, life, spiritual liberation (moksha), and ritual death unfold side by side in timeless continuity. Here, sunrise boat rides through sacred river mist, five-tiered brass evening aartis, labyrinthine medieval alleys (gallis), master silk weavers, and classical Hindustani music schools embody an unbroken civilizational pulse.',
  introSentence: 'The eternal spiritual capital of India where ancient stone riverfront ghats, dawn prayers on the Ganga, sacred brass bells, and centuries of philosophical inquiry meet the morning sun.',
  coordinates: [25.3176, 82.9739],
  accentColor: 'amber',
  hexAccent: '#d97706',
  heroImage: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Stone ghats and river boats along the holy Ganga at sunrise in Varanasi',
  imageCredit: 'Unsplash / Uttar Pradesh Tourism Department',
  heritageThemes: ['84 Riverfront Ghats on the Holy Ganga', 'Kashi Vishwanath Jyotirlinga & Corridor', 'Buddha’s First Sermon at Sarnath (528 BCE)', 'Centuries of Banarasi Silk Brocade Weaving', 'Benares Gharana of Classical Hindustani Music'],

  destinations: [
    {
      id: 'varanasi-dashashwamedh',
      name: 'Dashashwamedh Ghat & The Evening Ganga Aarti',
      cityId: 'varanasi',
      category: 'Spiritual & Sacred',
      shortSummary: 'The grandest central riverfront ghat, home to the nightly choreographed brass-lamp Ganga Aarti ceremony.',
      fullDescription: 'According to Hindu lore, Dashashwamedh Ghat ("Ghat of the Ten Sacrificed Horses") was created by Lord Brahma to welcome Lord Shiva to Kashi. Reconstructed in 1748 by Peshwa Balaji Baji Rao of the Marathas, it is the bustling, beating spiritual heart of Varanasi’s riverfront. Every evening at dusk, thousands of pilgrims and travelers gather on the stone steps and aboard hundreds of floating riverboats to witness the Maha Ganga Aarti. Young saffron-robed Hindu priests stand on elevated wooden daises, performing a deeply moving, synchronized ritual choreography: waving smoking incense burners, sounding conch shells (shankha), and lifting multi-tiered brass lamps containing blazing camphor fires to the sky as the entire riverbank resonates with devotional chanting.',
      historicalBackground: 'Recorded in the ancient Skanda Purana; reinforced with grand stone embankments by 18th-century Maratha rulers including Rani Ahilyabai Holkar.',
      culturalSignificance: 'The supreme public ritual expression of reverence for Mother Ganga, drawing devotees and observers from around the globe.',
      architecturalFeatures: 'Monumental tiered red sandstone and chunar stone steps descending into the river, historic pavilions, and wooden river platforms.',
      whyWorthVisiting: 'Experience one of humanity’s most awe-inspiring spectacles of collective sacred energy, sound, and fire light on water.',
      whatToExperience: 'Hire a wooden rowboat in the late afternoon to watch the aarti from the river, release a floating earthen diya lamp onto the water with a silent prayer, and sit on the steps to hear the ringing bells.',
      location: 'Dashashwamedh Ghat Road, Bangali Tola, Varanasi 221001',
      coordinates: [25.3069, 83.0104],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Sunset (5:30 PM – 7:30 PM) for the Ganga Aarti, or dawn (5:30 AM – 7:00 AM) for morning prayers and boat rides.',
      entryFeeInfo: 'Free public ghat; shared riverboat during aarti: ₹100–₹200 per seat; private rowboat ₹500–₹1,000 (negotiate in advance).',
      openingHoursInfo: 'Open 24 hours. The evening Ganga Aarti begins around 6:30 PM in summer and 6:00 PM in winter.',
      accessibilityInfo: 'Stone ghat steps are steep, uneven, and can be slick with river silt near the water’s edge. Wheelchair access is available via the upper riverfront road and the newly constructed Kashi Vishwanath riverfront plaza.',
      familySuitability: 'Deeply memorable for all generations; hold hands with children tightly near crowded water edges.',
      photographyNotes: 'Spectacular long-exposure shots of blazing brass fire lamps and illuminated wooden boats reflecting in the dark water.',
      nearbyCombinations: ['Kashi Vishwanath Temple', 'Manikarnika Ghat', 'Assi Ghat'],
      transitAdvice: 'Take an e-rickshaw or auto to Godowlia Chowk; from there, vehicles are barred and you walk 500m down the pedestrian market street to the ghat.',
      visitorTips: ['Arrive by 5:30 PM to secure a good viewing spot on the steps or book a wooden boat from a registered boatman.', 'Never step into unauthorized motorboats that lack lifebuoys.'],
      officialLinks: [{ title: 'Uttar Pradesh Tourism — Varanasi Ghats', url: 'https://uptourism.gov.in' }],
      sourceNote: 'Ganga Seva Nidhi Official Trust & Varanasi District Administration.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Tiered stone steps and river boats of Dashashwamedh Ghat at sunset in Varanasi',
      imageCredit: 'Unsplash'
    },
    {
      id: 'varanasi-kashi-vishwanath',
      name: 'Kashi Vishwanath Temple & The River Corridor',
      cityId: 'varanasi',
      category: 'Spiritual & Sacred',
      shortSummary: 'One of the twelve sacred Jyotirlingas of Lord Shiva, crowned by a one-ton pure gold shikhara.',
      fullDescription: 'Standing on the western bank of the holy Ganga, Kashi Vishwanath is one of the twelve sacred Jyotirlinga shrines of Lord Shiva and the supreme pilgrimage destination of Hinduism. Believed to have existed since timeless antiquity, the current temple sanctum was reconstructed in 1780 by the saintly Maratha queen Maharani Ahilyabai Holkar of Indore, after repeated demolitions under medieval rulers. In 1839, Maharaja Ranjit Singh of Punjab donated one ton of pure gold to gild the monumental 15.5-metre temple spire (shikhara). The newly inaugurated 50,000-square-metre Kashi Vishwanath Corridor now connects the temple sanctum directly to the river ghats at Lalita Ghat, providing wide, paved pedestrian courtyards, heritage galleries, and step-free pilgrim access.',
      historicalBackground: 'Hymned in the Rigveda and Mahabharata; the epicentre of Hindu theological discourse where Adi Shankaracharya, Ramakrishna Paramahamsa, and Swami Vivekananda prayed.',
      culturalSignificance: 'The spiritual pivot of Kashi, where taking darshan of Vishwanath (Lord of the Universe) is believed to bestow liberation (moksha) from the cycle of rebirth.',
      architecturalFeatures: 'Pure gold-gilded shikhara, carved sandstone sabha mandapa, Maratha stone arches, and the monumental new corridor connecting the shrine to the river.',
      whyWorthVisiting: 'Experience the profound devotional heart of Hinduism in a restored sacred precinct with direct vistas of the holy river.',
      whatToExperience: 'Walk through the open stone corridor from Lalita Ghat, take blessings at the sacred Jyotirlinga, admire the golden shikhara gleaming in the sun, and view the restored ancient shrines along the corridor.',
      location: 'Vishwanath Gali, Lahori Tola, Varanasi 221001',
      coordinates: [25.3109, 83.0107],
      suggestedDuration: '2 to 3 hours (including security queuing)',
      bestTimeToVisit: 'Early morning (5:00 AM – 7:30 AM) for Mangala Aarti or mid-morning (9:30 AM – 11:30 AM).',
      entryFeeInfo: 'General darshan is free; special booked VIP/Sugam Darshan tickets available online via the temple trust portal (₹300).',
      openingHoursInfo: 'Open daily: 3:00 AM – 11:00 PM (brief closures for sacred aartis).',
      accessibilityInfo: 'The new corridor from Lalita Ghat features escalators, ramps, and battery-operated carts for elderly and disabled pilgrims.',
      familySuitability: 'Deeply sacred; strict security checks require depositing all mobile phones, bags, and leather items in lockers at the gate.',
      photographyNotes: 'All cameras, smartphones, and electronic devices are strictly prohibited inside the inner security zone.',
      nearbyCombinations: ['Annapurna Temple', 'Manikarnika Ghat', 'Kashi Vishwanath Corridor Riverfront'],
      transitAdvice: 'Access directly from Lalita Ghat by riverboat, or from Godowlia Chowk through the pedestrian Vishwanath Gali.',
      visitorTips: ['Carry an original government photo ID (Aadhaar or Passport) for security entry.', 'Leave all electronics, leather belts, and bags at your hotel or inside official trust lockers at the gate.'],
      officialLinks: [{ title: 'Shri Kashi Vishwanath Temple Trust Official Portal', url: 'https://shrikashivishwanath.org' }],
      sourceNote: 'Kashi Vishwanath Temple Trust & State Religious Affairs Department.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Golden spire and temple domes of Kashi Vishwanath along the Ganga',
      imageCredit: 'Unsplash'
    },
    {
      id: 'varanasi-sarnath',
      name: 'Sarnath & The Dhamek Stupa',
      cityId: 'varanasi',
      category: 'History & Heritage',
      shortSummary: 'The sacred Deer Park where Gautama Buddha preached his first sermon in 528 BCE, launching Buddhism.',
      fullDescription: 'Located just 10 km northeast of Varanasi’s riverfront, Sarnath is one of the four most sacred pilgrimage sites of world Buddhism. It was here in the quiet Deer Park (Isipatana) in 528 BCE that Siddhartha Gautama, having attained enlightenment at Bodh Gaya, preached his first sermon—the Dhammacakkappavattana Sutta—setting into motion the Wheel of the Law (Dharmachakra) and revealing the Four Noble Truths and Eightfold Path to his first five disciples. Dominating the peaceful landscaped archaeological park is the colossal 43.6-metre Dhamek Stupa, constructed in 500 CE under the Gupta Empire to replace earlier Ashokan brick shrines, adorned with exquisite carved floral swags, geese, and geometric stone bands. Nearby stands the Archaeological Museum housing the original 3rd-century BCE Ashokan Lion Capital—the National Emblem of India.',
      historicalBackground: 'Founded by Emperor Ashoka in the 3rd century BCE; expanded into a flourishing monastic university of 1,500 monks recorded by Chinese pilgrim Xuanzang in 640 CE.',
      culturalSignificance: 'The birthplace of the Buddhist Sangha and the origin point of the Wheel of Law emblem displayed on the Indian national flag.',
      architecturalFeatures: 'Cylindrical Gupta stone stupa with carved relief friezes; remains of the Ashoka Pillar with inscribed edicts; ruins of ancient monastic viharas and votive stupas.',
      whyWorthVisiting: 'Experience the serene, contemplative silence of world Buddhist origins and stand face-to-face with the original Lion Capital of India.',
      whatToExperience: 'Walk in silent meditation around the monumental Dhamek Stupa, inspect the Ashokan Pillar stump, explore the Mulagandha Kuti Vihara modern temple with Japanese frescoes, and view the Lion Capital in the museum.',
      location: 'Sarnath, Varanasi 221007 (10 km northeast of the city center)',
      coordinates: [25.3811, 83.0227],
      suggestedDuration: '2.5 to 3 hours',
      bestTimeToVisit: 'Morning (8:30 AM – 11:30 AM) when the garden lawns are dewy and monastic pilgrims chant in yellow robes.',
      entryFeeInfo: 'Archaeological Park: ₹25 for Indian citizens, ₹300 for foreign visitors; Sarnath Museum: ₹5.',
      openingHoursInfo: 'Park open daily: Sunrise to Sunset; Sarnath Museum open Saturday to Thursday: 9:00 AM – 5:00 PM (Closed Fridays).',
      accessibilityInfo: 'Paved, wide walkways throughout the archaeological ruins; fully accessible for wheelchairs and strollers.',
      familySuitability: 'Deeply peaceful and educational for travelers of all backgrounds.',
      photographyNotes: 'Gentle morning light across the stone carvings of Dhamek Stupa; no photography allowed inside the Sarnath Museum.',
      nearbyCombinations: ['Sarnath Archaeological Museum', 'Chaukhandi Stupa', 'Thai & Tibetan Monasteries'],
      transitAdvice: 'Take an auto-rickshaw or taxi from Varanasi Cantt station or Godowlia (30 minutes drive). Sarnath railway station is 1 km away.',
      visitorTips: ['Do not miss the Sarnath Archaeological Museum right opposite the park gate to see the polished sandstone Ashokan Lion Capital in pristine condition.', 'Remove footwear when entering active monastic shrines like Mulagandha Kuti Vihara.'],
      officialLinks: [{ title: 'Archaeological Survey of India — Sarnath Circle', url: 'https://asi.nic.in' }],
      sourceNote: 'Archaeological Survey of India & UNESCO World Heritage Tentative List Dossier.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Ancient cylindrical stone Dhamek Stupa in the peaceful deer park at Sarnath',
      imageCredit: 'Unsplash'
    },
    {
      id: 'varanasi-manikarnika-ghat',
      name: 'Manikarnika Ghat (The Eternal Cremation Ghat)',
      cityId: 'varanasi',
      category: 'Spiritual & Sacred',
      shortSummary: 'The primary sacred cremation ghat of Hinduism where funeral pyres burn continuously 24 hours a day.',
      fullDescription: 'According to sacred cosmology, Manikarnika is the spot where Lord Shiva dropped his jewel earring (Manikarnika) into a sacred well dug by Lord Vishnu. It is the primary cremation ghat of Varanasi, where sacred funeral fires have burned without interruption for thousands of years. In Hindu theology, to breathe one’s last breath in Kashi or to have one’s mortal remains cremated at Manikarnika and surrendered to the waters of the holy Ganga ensures instantaneous release from the cycle of rebirth (Maha-Samadhi / Moksha), with Lord Shiva himself whispering the liberating Taraka mantra into the ear of the departing soul. Stacks of seasoned banyan and sandalwood logs rise like fortresses along the stone steps, while Dom community custodians attend to the eternal flames with profound equanimity.',
      historicalBackground: 'Described in ancient Puranas and epics; maintained continuously as a sacred site of passage across millennia.',
      culturalSignificance: 'The ultimate philosophical confrontation with mortality, where death is viewed not with morbid fear, but as a dignified, natural transition toward cosmic union.',
      architecturalFeatures: 'Sinking stone Shiva temple leaning into the riverbed, multi-level cremation terraces, and medieval stone haveli facades overlooking the water.',
      whyWorthVisiting: 'A profound, humbling spiritual experience that strips away material illusions and reveals the deepest philosophical soul of India.',
      whatToExperience: 'Observe respectfully from a distance or from a passing wooden riverboat, absorb the quiet dignity of the families, view the ancient Manikarnika Kund sacred well, and reflect on the impermanence of mortal life.',
      location: 'Near Scindia Ghat, Manikarnika Ghat Road, Varanasi 221001',
      coordinates: [25.3108, 83.0142],
      suggestedDuration: '45 minutes',
      bestTimeToVisit: 'Quiet observation from a riverboat at dawn or late afternoon.',
      entryFeeInfo: 'Free public sacred ghat.',
      openingHoursInfo: 'Open 24 hours continuously.',
      accessibilityInfo: 'Stone steps are crowded, slippery with river water, and hot near pyres. Best observed respectfully from a hired boat on the river.',
      familySuitability: 'Deeply solemn and solemn; not recommended for very young children; requires deep cultural sensitivity.',
      photographyNotes: 'PHOTOGRAPHY OF CREMATION PYRES AND MOURNERS IS STRICTLY FORBIDDEN. Respect the solemn dignity of the families and keep cameras away.',
      nearbyCombinations: ['Scindia Ghat (Leaning Temple)', 'Kashi Vishwanath Corridor', 'Panchganga Ghat'],
      transitAdvice: 'Easily viewed during a morning rowboat ride from Dashashwamedh Ghat or reached through the narrow medieval gallis of old Kashi.',
      visitorTips: ['Never take photographs of funeral pyres or grieving families; guards and locals will intervene firmly.', 'Beware of touts who approach tourists asking for "charity donations for wood for poor families"—this is a common scam; do not hand over money.'],
      officialLinks: [{ title: 'Uttar Pradesh Tourism — Varanasi Sacred Geography', url: 'https://uptourism.gov.in' }],
      sourceNote: 'Varanasi Heritage Society & Kashi Dharma Parishad Records.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Historic stone buildings and cremation terraces along the sacred Ganga',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1000 BCE – 6th Century BCE',
      title: 'Vedic Kashi & Emergence of Sarnath',
      description: 'Kashi thrives as a center of Vedic scholarship, philosophy, and textile crafts. In 528 BCE, the Buddha delivers his first sermon at nearby Sarnath, establishing Buddhism.',
      keySites: ['Sarnath Dhamek Stupa', 'Ancient Ghats original sites']
    },
    {
      epoch: '8th – 17th Century CE',
      title: 'Philosophical Renaissance & Bhakti Saints',
      description: 'Adi Shankaracharya composes masterworks in Kashi; Bhakti saint-poets Kabir, Ravidas, and Goswami Tulsidas (who composes the Ramcharitmanas at Assi Ghat) democratize devotion.',
      keySites: ['Tulsi Ghat', 'Kabir Chaura Math', 'Assi Ghat']
    },
    {
      epoch: '18th Century – Present',
      title: 'Maratha Reconstruction & Modern Corridor',
      description: 'Maratha rulers Ahilyabai Holkar and the Peshwas rebuild the city’s stone ghats and temples following medieval devastation. The 2021 Kashi Vishwanath Corridor reconnects the shrine to the holy river.',
      keySites: ['Kashi Vishwanath Corridor', 'Ahilyabai Ghat', 'Dashashwamedh Ghat']
    }
  ],

  architecturalHeritageOverview: 'Varanasi is unique in its riverfront morphology: 84 monumental stone ghats constructed of sturdy red and buff Chunar sandstone that step down directly into the holy Ganga, crowned by palaces, temples, and havelis built by royal dynasties from across India (Marathas, Holkars, Scindias, and Bengalis).',

  traditionsAndFestivals: [
    {
      title: 'Dev Deepawali (Festival of Lights of the Gods)',
      seasonOrFrequency: 'Kartik Poornima (November full moon, fifteen days after Diwali)',
      description: 'The supreme visual spectacle on Earth. All 84 ghats along the four-mile crescent of the Ganga are illuminated by over one million flickering earthen oil lamps (diyas), while priests chant and fireworks illuminate the night sky.',
      visitorEtiquette: 'Book riverboats months in advance; millions of pilgrims line the banks; move with calm patience in the crowds.'
    },
    {
      title: 'Subah-e-Banaras (Dawn at Assi Ghat)',
      seasonOrFrequency: 'Every sunrise year-round',
      description: 'A serene daily cultural ceremony at Assi Ghat commencing before dawn: Vedic yajna fire rituals, classical shehnai and flute performances by master musicians, and mass sunrise yoga on the riverfront.',
      visitorEtiquette: 'Arrive at Assi Ghat by 5:15 AM; visitors of all backgrounds are welcome to join the open yoga session.'
    }
  ],

  dishes: [
    {
      id: 'varanasi-kachori-sabzi',
      name: 'Banarasi Kachori Sabzi & Jalebi',
      localName: 'बनारसी कचौरी सब्जी आणि जिलेबी',
      culturalOrigin: 'The sacred dawn breakfast ritual of every Banarasi citizen before morning prayers.',
      description: 'Crisp, flaky puris stuffed with a spiced ground lentil paste (dal kachori), served with a hearty, no-onion, no-garlic (satvik) potato curry simmered in mustard oil with asafoetida, cumin, and dried mango powder, accompanied by hot, crisp, coiled golden jalebis soaked in saffron-scented sugar syrup.',
      typicalIngredients: ['Flaky lentil kachori', 'Mustard oil potato curry', 'Hing (asafoetida)', 'Crisp fermented jalebi', 'Saffron syrup'],
      isVeg: true,
      whereToFind: 'Ram Bhandar (Thatheri Bazaar), Madhur Milan (Dashashwamedh), Netaji Subhash Chowk stalls.',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian (satvik, no onion or garlic). Served traditionally on dried sal leaf plates (dona).',
      etiquetteTips: 'Eat breakfast early between 7:00 AM and 9:30 AM before shops sell out their daily morning batch.',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'varanasi-malaiyo',
      name: 'Banarasi Malaiyo (Winter Saffron Dew)',
      localName: 'बनारसी मलइयो',
      culturalOrigin: 'An ephemeral winter culinary art form practiced only in the labyrinthine alleys of old Kashi.',
      description: 'Available exclusively during chilly winter months (November to February). Raw milk is boiled with saffron, cardamom, and pistachios, left outdoors overnight on city rooftops so the cold winter dew aerates the cream. Churned vigorously at dawn, it forms an ethereal cloud of golden foam that melts instantly on the tongue, leaving a delicate whisper of saffron and sweet cream.',
      typicalIngredients: ['Saffron milk', 'Winter dew condensation', 'Cardamom', 'Crushed pistachios', 'Almonds', 'Clay kullad cup'],
      isVeg: true,
      whereToFind: 'Markandey Sardar Malaiyo (Chaukhamba), Shreeji Sweets (Godowlia).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Highly perishable; collapses in heat and must be consumed cold at the shop.',
      etiquetteTips: 'Sip gently directly from the earthen kullad to enjoy the cloud-like texture without stirring.',
      image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'varanasi-banarasi-paan',
      name: 'Authentic Banarasi Paan',
      localName: 'बनारसी पान',
      culturalOrigin: 'Celebrated across Indian poetry, cinema, and history as the supreme digestive and hospitality art.',
      description: 'A tender, pale betel leaf (maghai or jagannathi paan) meticulously layered with slaked lime (chuna), catechu (kattha), sweet fragrant preserves (gulkand), fennel seeds, candied fruit, menthol, and slivered areca nut, folded into a delicate triangle and often decorated with edible silver leaf (varq).',
      typicalIngredients: ['Tender Maghai betel leaf', 'Sweet rose gulkand', 'Kattha & chuna', 'Fennel seeds', 'Menthol & cardamom'],
      isVeg: true,
      whereToFind: 'Keshav Tambool Bhandar (near Lanka gate, BHU), Deepak Tambool (Dashashwamedh).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Can be ordered "meetha paan" (sweet, tobacco-free) or traditional.',
      etiquetteTips: 'Chew slowly and allow the sweet rose and menthol essences to release naturally; do not swallow whole.',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Godowlia Chowk & Thatheri Bazaar',
      character: 'Historic pedestrian shopping district famed for dawn kachoris, sweet lassi in clay pots, and street sweets.',
      bestTime: 'Morning 7:00 AM – 10:30 AM and Evening 5:00 PM – 9:30 PM.',
      highlights: ['Kachori sabzi at Ram Bhandar', 'Peda and sweets at Ksheer Sagar', 'Paan at Godowlia'],
      visitorAdvice: 'The avenue is closed to four-wheeled traffic; travel on foot or via cycle rickshaw.'
    },
    {
      name: 'Assi Ghat & Lanka (BHU Corridor)',
      character: 'Relaxed student and traveler hub filled with riverside cafes, wood-fired pizza spots, and rabdi lassi joints.',
      bestTime: 'Afternoon through night (12:00 PM – 10:00 PM).',
      highlights: ['Thick malai lassi at Pahalwan Lassi', 'Apple pie and tea at riverside cafes', 'Evening chai at Assi steps'],
      visitorAdvice: 'Assi Ghat has open seating; lovely spot for evening journaling and sunset conversations.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Varanasi is safe and deeply welcoming to pilgrims, but dense ghat crowds and labyrinthine medieval alleys require basic alertness.',
      'Around Manikarnika Ghat, beware of assertive touts claiming to collect "wood cremation donations for the destitute"; this is an established confidence trick. Respectfully walk away.',
      'Never drink unboiled river water from the Ganga; always drink bottled or filtered water.'
    ],
    transportPedestrian: [
      'The medieval gallis (lanes) of Old Kashi are strictly pedestrian; keep your bearings by asking locals for directions to the river ("Ganga ji kidhar hai?") or to Godowlia Chowk.',
      'Electric e-rickshaws are the primary city transit mode; confirm the destination and fare before climbing aboard.',
      'When hiring boats, use registered municipal boatmen with fixed government tariff cards posted at major ghats.'
    ],
    nightTravel: [
      'The riverfront ghats between Assi and Dashashwamedh are active, illuminated, and safe until 10:30 PM.',
      'Deep interior alleyways can be dimly lit late at night; carry a small torch or smartphone light when returning to riverside guesthouses.'
    ],
    accessibilityNotes: [
      'Historic stone ghat stairs are steep, irregular, and lack handrails in most sections.',
      'The new Kashi Vishwanath Corridor features modern elevators, escalators, and golf-cart shuttles from the road to the river.'
    ],
    emergencyContacts: [
      { title: 'Varanasi Police Emergency', number: '112', note: '24/7 central emergency response' },
      { title: 'Varanasi Tourist Police Helpdesk', number: '0542 250 8023', note: 'Dedicated tourist kiosk at Dashashwamedh' },
      { title: 'Sir Sunderlal Hospital Emergency (BHU)', number: '0542 236 9901', note: 'Premier university tertiary medical trauma center' },
      { title: 'Water Police Helpdesk', number: '94544 04388', note: 'Boat assistance and river safety' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Uttar Pradesh Tourism Development Corporation and Varanasi Police Commissionerate notifications.'
  },

  neighbourhoods: [
    {
      id: 'varanasi-old-gallis',
      name: 'Old Kashi Medieval Gallis & Central Ghats',
      cityId: 'varanasi',
      character: 'The timeless medieval core: narrow winding stone alleys accessible only on foot, filled with ancient shrines, silk weavers, and sacred bulls.',
      budgetTier: 'Budget-friendly',
      transitScore: 'Moderate (Strictly pedestrian inside; e-rickshaws available at perimeter roads like Godowlia)',
      transitDetails: 'Best navigated on foot; wooden boats connect ghats easily along the river.',
      walkabilityRating: 'Very High for agile pedestrians; cars are completely barred, offering an intimate sensory experience.',
      accessibilityNotes: 'Challenging for wheelchairs due to steep ghat steps and narrow alley stone thresholds.',
      heritageHighlights: ['Kashi Vishwanath Temple', 'Dashashwamedh Ghat', 'Manikarnika Ghat', 'Nepali Wooden Temple'],
      foodHighlights: ['Ram Bhandar', 'Blue Lassi Shop', 'Deepak Tambool'],
      greenSpaceNotes: 'Limited parks; the wide expanse of the holy Ganga provides endless natural sky and water views.',
      safetyContext: 'High social safety due to round-the-clock spiritual pilgrim traffic and police posts.',
      methodologyNote: 'Evaluated using urban morphological studies of historic Indian riverfront cities.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'varanasi-assi-lanka',
      name: 'Assi Ghat & Banaras Hindu University (BHU)',
      cityId: 'varanasi',
      character: 'Vibrant academic, artistic, and yogic cultural district anchored by the sprawling 1,300-acre green campus of BHU.',
      budgetTier: 'Budget-friendly to Moderate',
      transitScore: 'High (Wide roads, frequent e-rickshaws, and auto-rickshaws to Cantt station)',
      transitDetails: 'Good vehicular connectivity; ample parking at Assi and Lanka.',
      walkabilityRating: 'Very High (Broad river steps at Assi, tree-canopied avenues inside BHU campus).',
      accessibilityNotes: 'Assi Ghat has a ramped vehicular approach to the upper platform.',
      heritageHighlights: ['Bharat Kala Bhavan Museum (BHU)', 'New Vishwanath Temple (VT)', 'Tulsi Manas Mandir'],
      foodHighlights: ['Pahalwan Lassi', 'Pizzeria Vaatika Cafe', 'Keshari Sweets'],
      greenSpaceNotes: 'BHU campus contains over 1,000 acres of tranquil mango orchards, gardens, and deer parks.',
      safetyContext: 'One of the safest, most student-friendly and peaceful districts in Varanasi.',
      methodologyNote: 'Calculated from university cultural assets and riverfront public space assessments.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-varanasi-silk-weavers',
      cityId: 'varanasi',
      title: 'Threads of Gold: The Muslim Weavers of Hindu Wedding Brocades',
      preview: 'How for centuries, Muslim Ansari master weavers have crafted the sacred Banarasi silk sarees worn by Hindu brides across India.',
      fullArticle: 'In the narrow, dim-lit workshops of Madanpura and Peeli Kothi, the wooden rhythm of jacquard pit-looms has tapped out a steady beat for five hundred years. Here, the world-famous Banarasi silk saree is born. In a profound testament to Ganga-Jamuni tehzeeb (syncretic Indian culture), the hereditary weavers are almost entirely Muslim Ansaris, while the traditional patrons are Hindu brides and temple deities. Using fine mulberry silk interwoven with real gold and silver zari metallic threads, a master weaver and his apprentice spend up to six months crafting a single bridal saree. They execute complex Persian and Mughal motifs—the ambi (paisley), shikargah (hunting scenes), and bel (creeper floral vines)—creating an heirloom that is treasured across generations and forms an irreplaceable cornerstone of India’s handloom heritage.',
      locationName: 'Madanpura & Chowk Silk Bazaars',
      factualExplanation: 'Documented in Handloom Census of India and Varanasi District Craft Archives.',
      sources: ['The Sacred City of the Hindus by M.A. Sherring', 'Benares: City of Light by Diana L. Eck'],
      relatedDestinationIds: ['varanasi-dashashwamedh', 'varanasi-kashi-vishwanath'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Intricate golden handwoven Banarasi silk textile'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '9°C – 25°C', advice: 'Peak travel season; crisp cool mornings with ethereal river mist, pleasant sunshine, and winter delicacies like Malaiyo.' },
      { season: 'Monsoon (Jul – Sep)', temperatureRange: '26°C – 34°C', advice: 'Ganga river levels rise dramatically; lower ghat steps and boat operations may be suspended for safety during peak floods.' },
      { season: 'Summer (Apr – Jun)', temperatureRange: '28°C – 44°C', advice: 'Severe dry heat; plan riverboat excursions strictly before 7:30 AM or after 6:00 PM.' }
    ],
    transportInfrastructure: [
      { mode: 'E-Rickshaws & Cycle Rickshaws', coverage: 'Everywhere across the city', tip: 'Eco-friendly and nimble enough to navigate crowded perimeter market streets.' },
      { mode: 'Wooden Hand-Rowed Riverboats', coverage: 'Across all 84 river ghats', tip: 'Far quieter and more atmospheric than loud motorized boats; negotiate prices respectfully in advance.' },
      { mode: 'App Cabs (Uber & Ola)', coverage: 'City highways, airport, and railway connections', tip: 'Cars cannot enter the inner gallis; alight at Godowlia Chowk or Maidagin.' }
    ],
    environmentalNotes: 'The National Mission for Clean Ganga (Namami Gange) operates ongoing sewage treatment plants and electric river crematoriums to protect the river’s aquatic ecology, including the endangered Gangetic river dolphin.',
    dataAttribution: 'Uttar Pradesh Tourism Development Corporation & Varanasi Smart City Mission'
  }
};
