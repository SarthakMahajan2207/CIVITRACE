import React, { useState } from 'react';
import {
  UtensilsCrossed,
  MapPin,
  Clock,
  Sparkles,
  AlertCircle,
  HelpCircle,
  Leaf,
  Beef,
  Compass
} from 'lucide-react';
import { RegionalDish, FoodDistrict } from '../types';

interface FoodSectionProps {
  cityName: string;
  dishes: RegionalDish[];
  foodDistricts: FoodDistrict[];
}

export const FoodSection: React.FC<FoodSectionProps> = ({
  cityName,
  dishes,
  foodDistricts,
}) => {
  const [filterVegOnly, setFilterVegOnly] = useState(false);

  const displayedDishes = filterVegOnly
    ? dishes.filter((d) => d.isVeg)
    : dishes;

  return (
    <section id="food" className="py-16 sm:py-24 bg-[#0a0e17] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 sm:mb-14">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
              <UtensilsCrossed className="w-4 h-4" />
              <span>Gastronomic Lineage</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
              Culinary Heritage & Food of {cityName}
            </h2>
            <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-2xl leading-relaxed">
              Generational street institutions, regional flavour profiles, and respectful dining customs verified through local culinary histories.
            </p>
          </div>

          {/* Filter Veg Toggle */}
          <div className="flex items-center gap-2 self-start md:self-auto bg-slate-900 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setFilterVegOnly(false)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                !filterVegOnly
                  ? 'bg-amber-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Traditions
            </button>
            <button
              onClick={() => setFilterVegOnly(true)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                filterVegOnly
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Leaf className="w-3.5 h-3.5 text-emerald-400" />
              <span>Vegetarian Only</span>
            </button>
          </div>
        </div>

        {/* Regional Dishes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-16 sm:mb-20">
          {displayedDishes.map((dish) => (
            <div
              key={dish.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden flex flex-col justify-between hover:border-slate-700 shadow-md transition-all group"
            >
              <div>
                {/* Photo Header */}
                <div className="relative h-44 w-full overflow-hidden bg-slate-950">
                  <img
                    src={dish.image}
                    alt={dish.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                  {/* Veg / Non-Veg Badge */}
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-slate-900/90 backdrop-blur-md border border-slate-700 text-xs font-semibold flex items-center gap-1.5 shadow-md">
                    {dish.isVeg ? (
                      <>
                        <div className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="text-emerald-200">Vegetarian</span>
                      </>
                    ) : (
                      <>
                        <div className="w-2 h-2 rounded-full bg-rose-400" />
                        <span className="text-rose-200">Non-Vegetarian</span>
                      </>
                    )}
                  </div>

                  {/* Price Tier */}
                  <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-black/70 text-[11px] text-amber-300 font-mono">
                    {dish.priceCategory}
                  </div>

                  {/* Dish Title on Image */}
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-lg font-editorial font-bold text-white line-clamp-1">
                      {dish.name}
                    </h3>
                    <span className="text-xs text-amber-200/80 font-serif">
                      {dish.localName}
                    </span>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-4 sm:p-5 space-y-3">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {dish.description}
                  </p>

                  <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 text-[11px] text-slate-400">
                    <span className="text-amber-400 font-semibold block mb-0.5">Cultural Origin:</span>
                    <span>{dish.culturalOrigin}</span>
                  </div>

                  {/* Typical Ingredients */}
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block mb-1">
                      Key Ingredients:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {dish.typicalIngredients.map((ing, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded bg-slate-800 text-[11px] text-slate-300"
                        >
                          {ing}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Where to Find */}
                  <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                    <span className="text-amber-400 font-semibold block mb-0.5 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" /> Iconic Institutions:
                    </span>
                    <span className="text-slate-300 font-medium">{dish.whereToFind}</span>
                  </div>
                </div>
              </div>

              {/* Etiquette & Dietary Footer */}
              <div className="p-4 bg-slate-950/60 border-t border-slate-800 space-y-1.5 text-[11px]">
                <div className="text-slate-300 flex items-start gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{dish.dietaryAdvice}</span>
                </div>
                <div className="text-teal-300/90 italic flex items-start gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                  <span>"{dish.etiquetteTips}"</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Historic Food Districts & Market Guidance */}
        <div className="space-y-6">
          <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white flex items-center gap-2">
            <Compass className="w-5 h-5 text-amber-400" />
            <span>Historic Food Quarters & Market Navigation</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {foodDistricts.map((district, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-md"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-lg font-editorial font-bold text-white">
                      {district.name}
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-300 mt-1">
                      {district.character}
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700 text-amber-300 text-[11px] font-medium shrink-0 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {district.bestTime}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Quarter Highlights:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {district.highlights.map((h, hIdx) => (
                      <span
                        key={hIdx}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 text-xs text-amber-200"
                      >
                        • {h}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 text-xs text-slate-400 bg-slate-950/40 p-3 rounded-xl">
                  <span className="font-semibold text-slate-300 block mb-0.5">Visitor & Transport Advice:</span>
                  <span>{district.visitorAdvice}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
