import { City, CommunityReport, Destination, CityStory, RegionalDish } from '../../types';
import { puneData } from './pune';
import { mumbaiData } from './mumbai';
import { bengaluruData } from './bengaluru';
import { delhiData } from './delhi';
import { jaipurData } from './jaipur';
import { goaData } from './goa';
import { chennaiData } from './chennai';
import { hyderabadData } from './hyderabad';
import { kolkataData } from './kolkata';
import { kochiData } from './kochi';
import { varanasiData } from './varanasi';
import { ahmedabadData } from './ahmedabad';

export const allCities: City[] = [
  puneData,
  mumbaiData,
  bengaluruData,
  delhiData,
  jaipurData,
  goaData,
  chennaiData,
  hyderabadData,
  kolkataData,
  kochiData,
  varanasiData,
  ahmedabadData,
];

export const getCityById = (id: string): City | undefined => {
  return allCities.find((c) => c.id.toLowerCase() === id.toLowerCase());
};

export const defaultCity = puneData;

export const initialCommunityReports: CommunityReport[] = [
  {
    id: 'rep-pune-01',
    cityId: 'pune',
    category: 'Pedestrian Safety',
    title: 'Footpath restoration underway on Kumthekar Road',
    description: 'PMC Heritage Cell has begun repaving stone flagstones outside Vishrambaug Wada. Watch for loose curb stones during evening shopping hours.',
    neighbourhood: 'Sadashiv Peth',
    status: 'Verified by civic/editorial source',
    timestamp: '1 day ago',
    verifiedBy: 'Pune Municipal Heritage Cell field monitor',
  },
  {
    id: 'rep-pune-02',
    cityId: 'pune',
    category: 'Crowd Congestion',
    title: 'Heavy weekend vehicle queue on Sinhagad Fort ghat road',
    description: 'Forest Department gate experienced vehicle back-ups between 10:00 AM and 2:00 PM on Sunday. Recommend using shared shuttle jeeps from Donje village or arriving prior to 7:30 AM.',
    neighbourhood: 'Sinhagad Foothills',
    status: 'Verified by civic/editorial source',
    timestamp: '3 days ago',
    verifiedBy: 'District Forest Ranger Station Donje',
  },
  {
    id: 'rep-mumbai-01',
    cityId: 'mumbai',
    category: 'Lighting & Night Walkability',
    title: 'Marine Drive street lamps operational throughout Back Bay promenade',
    description: 'All Queen’s Necklace sodium and LED street fittings confirmed functional from Nariman Point up to Girgaon Chowpatty. Very well lit for late-evening walkers.',
    neighbourhood: 'Marine Drive / Churchgate',
    status: 'Verified by civic/editorial source',
    timestamp: '2 days ago',
    verifiedBy: 'BMC Ward A Engineering Inspection',
  },
  {
    id: 'rep-delhi-01',
    cityId: 'delhi',
    category: 'Transit Accessibility',
    title: 'E-rickshaw stand organized outside Chandni Chowk Metro Gate 1',
    description: 'Fixed-rate pre-paid e-rickshaw queuing initiated by Delhi Traffic Police for transit to Jama Masjid Gate 1 and Fatehpuri.',
    neighbourhood: 'Shahjahanabad',
    status: 'Verified by civic/editorial source',
    timestamp: '4 days ago',
    verifiedBy: 'Delhi Traffic Police Central Division',
  },
  {
    id: 'rep-blr-01',
    cityId: 'bengaluru',
    category: 'Civic Note',
    title: 'Vehicle-free Sunday policy in Cubbon Park strictly enforced',
    description: 'Gates closed to all motor vehicles from 6:00 AM to 7:00 PM on Sundays. Bicycles and pedestrian joggers only.',
    neighbourhood: 'Cubbon Park / Sampangi Rama Nagar',
    status: 'Verified by civic/editorial source',
    timestamp: '5 days ago',
    verifiedBy: 'Karnataka Horticulture Directorate',
  },
  {
    id: 'rep-jaipur-01',
    cityId: 'jaipur',
    category: 'Civic Note',
    title: 'Restoration scaffoldings removed from Hawa Mahal street facade',
    description: 'Annual monsoon lime-wash and stone joint pointing completed. Full 953-window facade is completely unobstructed for photography.',
    neighbourhood: 'Walled City (Badi Chaupar)',
    status: 'Verified by civic/editorial source',
    timestamp: '6 days ago',
    verifiedBy: 'Rajasthan Archaeology Field Division',
  },
  {
    id: 'rep-varanasi-01',
    cityId: 'varanasi',
    category: 'Transit Accessibility',
    title: 'Riverfront escalators operational at Lalita Ghat Corridor entry',
    description: 'Direct step-free escalator access operational from river level up into the main temple chowk for mobility-impaired pilgrims.',
    neighbourhood: 'Lalita Ghat / Vishwanath Corridor',
    status: 'Verified by civic/editorial source',
    timestamp: '1 week ago',
    verifiedBy: 'Shri Kashi Vishwanath Temple Trust Administration',
  },
];

export interface SearchResultItem {
  type: 'city' | 'destination' | 'story' | 'dish';
  id: string;
  title: string;
  subtitle: string;
  cityId: string;
  cityName: string;
  image?: string;
}

export const searchGlobal = (query: string): SearchResultItem[] => {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const results: SearchResultItem[] = [];

  // Match cities
  for (const city of allCities) {
    if (
      city.name.toLowerCase().includes(q) ||
      city.state.toLowerCase().includes(q) ||
      city.tagline.toLowerCase().includes(q)
    ) {
      results.push({
        type: 'city',
        id: city.id,
        title: city.name,
        subtitle: `${city.state} • ${city.tagline}`,
        cityId: city.id,
        cityName: city.name,
        image: city.heroImage,
      });
    }

    // Match destinations
    for (const dest of city.destinations) {
      if (
        dest.name.toLowerCase().includes(q) ||
        dest.category.toLowerCase().includes(q) ||
        dest.shortSummary.toLowerCase().includes(q) ||
        dest.historicalBackground.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'destination',
          id: dest.id,
          title: dest.name,
          subtitle: `${dest.category} in ${city.name} • ${dest.suggestedDuration}`,
          cityId: city.id,
          cityName: city.name,
          image: dest.image,
        });
      }
    }

    // Match stories
    for (const story of city.stories) {
      if (
        story.title.toLowerCase().includes(q) ||
        story.preview.toLowerCase().includes(q) ||
        story.fullArticle.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'story',
          id: story.id,
          title: story.title,
          subtitle: `Story from ${city.name} • ${story.readTimeMinutes} min read`,
          cityId: city.id,
          cityName: city.name,
          image: story.image,
        });
      }
    }

    // Match dishes
    for (const dish of city.dishes) {
      if (
        dish.name.toLowerCase().includes(q) ||
        dish.localName.toLowerCase().includes(q) ||
        dish.description.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'dish',
          id: dish.id,
          title: dish.name,
          subtitle: `Cuisine of ${city.name} (${dish.isVeg ? 'Vegetarian' : 'Non-Vegetarian'})`,
          cityId: city.id,
          cityName: city.name,
          image: dish.image,
        });
      }
    }
  }

  return results.slice(0, 15);
};
