import React from 'react';
import { Compass, ShieldCheck, MapPin, Heart, Sparkles } from 'lucide-react';
import { City } from '../types';
import { allCities } from '../data/cities';

interface FooterProps {
  onSelectCity: (city: City) => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCity,
  onNavigateSection,
}) => {
  return (
    <footer className="bg-[#05080e] border-t border-slate-800 text-slate-400 text-xs sm:text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand Info (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-600 to-teal-700 flex items-center justify-center border border-amber-500/30">
                <Compass className="w-4 h-4 text-amber-100" />
              </div>
              <span className="font-cinzel text-xl font-bold tracking-wider text-white">
                CIVITRACE
              </span>
            </div>
            <p className="text-amber-200/90 font-serif italic text-sm">
              "See Beyond the Streets."
            </p>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              A cinematic, factually grounded city-exploration web platform. Built for travelers, students, residents, and solo explorers discovering the architectural, historical, and culinary soul of Indian cultural capitals.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-2 border-t border-slate-900">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Grounded in verified academic, municipal, and archaeological archives.</span>
            </div>
          </div>

          {/* Supported Cities */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-sans">
              12 Supported Capitals
            </h4>
            <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 text-xs">
              {allCities.map((city) => (
                <button
                  key={city.id}
                  onClick={() => {
                    onSelectCity(city);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-left text-slate-400 hover:text-amber-300 transition-colors py-0.5"
                >
                  {city.name}
                </button>
              ))}
            </div>
          </div>

          {/* Exploration Sections */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-sans">
              Exploration Modules
            </h4>
            <ul className="space-y-1.5 text-xs">
              {[
                { id: 'explore', label: 'Cultural Discoveries' },
                { id: 'heritage', label: 'Heritage & Lineage' },
                { id: 'food', label: 'Local Food & Life' },
                { id: 'safety', label: 'Safety & Observations' },
                { id: 'compare', label: 'Neighbourhood Comparison' },
                { id: 'insights', label: 'City Intelligence' },
                { id: 'stories', label: 'Editorial Chronicles' },
                { id: 'map', label: 'Interactive Map' },
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => onNavigateSection(link.id)}
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Sources & Editorial Integrity */}
          <div className="space-y-3 text-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-sans">
              Source Attribution
            </h4>
            <ul className="space-y-1 text-slate-400 text-[11px] leading-relaxed">
              <li>• Archaeological Survey of India (ASI)</li>
              <li>• UNESCO World Heritage Centre</li>
              <li>• Indian Meteorological Department (IMD)</li>
              <li>• Municipal Heritage Conservation Cells</li>
              <li>• State Tourism Development Corporations</li>
            </ul>
            <p className="text-[10px] text-slate-500 pt-2 border-t border-slate-900">
              CIVITRACE does not fabricate crime indices or live conditions. Content is curated for thoughtful cultural exploration.
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} CIVITRACE. All architectural and cultural dossiers verified for responsible exploration.
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Respectful Heritage Travel</span>
            <span>•</span>
            <span>Fact-Grounded Intelligence</span>
            <span>•</span>
            <span>No Artificial Slop</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
