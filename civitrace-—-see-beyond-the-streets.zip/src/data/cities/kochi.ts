import { City } from '../../types';

export const kochiData: City = {
  id: 'kochi',
  name: 'Kochi',
  state: 'Kerala',
  region: 'Malabar Coast & Vembanad Estuary',
  tagline: 'Queen of the Arabian Sea & Maritime Spice Crossroads',
  heroDescription: 'Flanked by the Arabian Sea and the tranquil backwaters of Vembanad Lake, Kochi has welcomed global maritime traders for over six centuries. Chinese cantilevered fishing nets dip into tidal waters; 16th-century Portuguese and Dutch palaces house breathtaking mythological murals; antique spice warehouses in Jew Town waft with black pepper and ginger; and ancient Syrian Christian and Jewish communities preserve a profound pluralistic coastal heritage.',
  introSentence: 'An enchanted Malabar spice port where Chinese fishing nets, Dutch colonial palaces, Jewish synagogues, and palm-fringed lagoons embody centuries of cosmopolitan trade.',
  coordinates: [9.9312, 76.2673],
  accentColor: 'teal',
  hexAccent: '#0d9488',
  heroImage: 'https://images.unsplash.com/photo-1593693397690-362cb9666fc2?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Silhouetted Chinese fishing nets against golden sunset waters in Fort Kochi',
  imageCredit: 'Unsplash / Kerala Tourism Department',
  heritageThemes: ['Malabar Spice Trade (Black Pepper, Cardamom)', 'Chinese Cantilever Fishing Nets (14th Century)', 'Portuguese, Dutch & British Colonial Overlays', 'Paradesi Jewish & Syrian Christian Heritage', 'Kathakali Dance & Kalaripayattu Martial Arts'],

  destinations: [
    {
      id: 'kochi-chinese-nets',
      name: 'Chinese Fishing Nets (Cheena Vala)',
      cityId: 'kochi',
      category: 'History & Heritage',
      shortSummary: '14th-century cantilevered shore-operated fishing nets introduced by court traders of Kublai Khan.',
      fullDescription: 'Lining the northern shoreline of Fort Kochi where the backwaters meet the open Arabian Sea, the Cheena Vala are magnificent, cantilevered shore-operated fishing nets that have operated here for over six centuries. Believed to have been introduced in the 14th century by Chinese traders from the court of Mongol Emperor Kublai Khan or the legendary explorer Zheng He, each net is a brilliant triumph of balanced mechanical physics. Supported on teakwood and bamboo poles spanning twenty metres, the colossal horizontal nets are counterweighted by heavy suspended river stones. A coordinated team of six fishermen works in synchronized rhythm, hauling ropes to lower the net into the tidal current for five minutes before raising the glistening catch of pomfret, red snapper, and tiger prawns.',
      historicalBackground: 'Recorded by traveler Ma Huan in 1409. Stands as the only place outside China where these ancient shore nets operate continuously.',
      culturalSignificance: 'The defining visual icon of Kerala and an irreplaceable living maritime heritage preserved through generational fishing collectives.',
      architecturalFeatures: 'Cantilevered bamboo and teak truss frame, counterbalancing suspended stones, hand-woven cotton and nylon netting, and shoreline timber stilts.',
      whyWorthVisiting: 'Experience an ancient mechanical fishing spectacle against the golden backdrop of ocean shipping channels.',
      whatToExperience: 'Watch the fishermen lower and raise the nets, assist them in pulling the stone counterweights, photograph the nets silhouetted against sunset, and purchase fresh fish to be cooked on-site by shoreline stalls.',
      location: 'River Road, Fort Kochi, Kochi 682001',
      coordinates: [9.9664, 76.2422],
      suggestedDuration: '1 to 1.5 hours',
      bestTimeToVisit: 'Sunrise (6:00 AM – 7:30 AM) or sunset (5:00 PM – 6:45 PM) when the sky turns crimson behind the wooden nets.',
      entryFeeInfo: 'Free public viewing along the promenade; a small tip (₹50–₹100) is appreciated if fishermen invite you to pull the counterweights.',
      openingHoursInfo: 'Nets operate daily: 6:00 AM – 7:00 PM.',
      accessibilityInfo: 'Paved, wide waterfront promenade along Vasco da Gama Square; fully accessible for wheelchairs and strollers.',
      familySuitability: 'Fascinating for children and photographers of all ages.',
      photographyNotes: 'Iconic sunset silhouette shots; long exposures capturing the tidal current flowing through the net mesh.',
      nearbyCombinations: ['St. Francis Church', 'Vasco da Gama Square', 'Fort Kochi Beach'],
      transitAdvice: 'Take the public ferry from Ernakulam jetty to Fort Kochi (₹6, 20 mins) or auto-rickshaw from Ernakulam.',
      visitorTips: ['Beware of touts claiming private "ticket fees" to view the nets; the public promenade is completely free.', 'Walk along the promenade to St. Francis Church immediately afterwards.'],
      officialLinks: [{ title: 'Kerala Tourism — Fort Kochi Heritage Zone', url: 'https://keralatourism.org' }],
      sourceNote: 'Kerala State Department of Tourism & Fort Kochi Fishermen Cooperatives.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1593693397690-362cb9666fc2?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Silhouetted wooden Chinese fishing nets against pink sunset in Fort Kochi',
      imageCredit: 'Unsplash'
    },
    {
      id: 'kochi-mattancherry-palace',
      name: 'Mattancherry Palace (The Dutch Palace)',
      cityId: 'kochi',
      category: 'History & Heritage',
      shortSummary: '1555 palace presented by the Portuguese to the Raja of Kochi, housing India’s finest mythological tempera murals.',
      fullDescription: 'Built around 1555 by the Portuguese as a gift of diplomacy to Raja Veera Kerala Varma (and to compensate for plundering a nearby temple) and renovated by the Dutch in 1663, the Mattancherry Palace is an exquisite two-storey quadrangular structure built in traditional Kerala Nalukettu style. While its exterior is deceptively simple with whitewashed walls and sloping terracotta-tiled roofs, its interior chambers house some of the greatest narrative art in Asia. The royal bedchamber (Palliyara) and coronation halls are covered with 300 square metres of vibrant, 16th-century tempera murals depicting episodes from the Ramayana, Mahabharata, and Krishna Lila. Rendered in five natural organic pigments (panchavarna), the figures display astonishing expressive fluidity and intricate ornamentation.',
      historicalBackground: 'Presented to the Kochi royal family in 1555; renovated extensively by the Dutch East India Company (VOC) in 1663. Now an ASI protected museum.',
      culturalSignificance: 'Houses India’s most celebrated classical mural paintings alongside royal coronation robes, ivory palanquins, and historic Dutch maps.',
      architecturalFeatures: 'Kerala Nalukettu courtyard, carved wooden coffered ceilings, polished black lime floors (made of burnt coconut shells, egg whites, and plant juices), and European arched windows.',
      whyWorthVisiting: 'Stand before world-class 16th-century indigenous tempera murals that rival the Renaissance frescoes of Europe in grace and narrative depth.',
      whatToExperience: 'Examine the Ramayana murals in the royal bedchamber, admire the polished dark herbal floor, view the royal coronation robes of the Kochi Rajas, and visit the central courtyard temple.',
      location: 'Palace Road, Mattancherry, Kochi 682002',
      coordinates: [9.9583, 76.2592],
      suggestedDuration: '1.5 hours',
      bestTimeToVisit: 'Morning hours (9:45 AM – 12:30 PM) for cool interiors and uncrowded galleries.',
      entryFeeInfo: '₹5 for Indian citizens, ₹25 for foreign visitors (ASI monument ticketing).',
      openingHoursInfo: 'Open Saturday to Thursday: 9:45 AM – 1:00 PM and 2:00 PM – 4:45 PM. Closed Fridays and National Holidays.',
      accessibilityInfo: 'Ground floor is level; the historic wooden staircase to the upper mural chambers is steep and narrow without elevator access.',
      familySuitability: 'Engaging and educational for history and art enthusiasts; keep quiet reverence in the mural rooms.',
      photographyNotes: 'Photography is strictly prohibited inside the mural galleries to preserve the natural pigments from light damage.',
      nearbyCombinations: ['Paradesi Synagogue (Jew Town)', 'Jew Town Antique Market', 'Ginger House Museum Hotel'],
      transitAdvice: 'Take a public ferry from Ernakulam to Mattancherry jetty (10-minute walk to palace) or auto-rickshaw from Fort Kochi (3 km).',
      visitorTips: ['Look closely at the floor in the dining hall; it looks like polished black marble but is an indigenous organic compound that stays naturally cool.', 'Walk down the spice-scented street into Jew Town immediately after exiting.'],
      officialLinks: [{ title: 'ASI Thrissur Circle — Mattancherry Palace', url: 'https://asithrissurcircle.in' }],
      sourceNote: 'Archaeological Survey of India & Cochin Royal Family Historical Records.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Traditional Kerala-style sloping roof and courtyard of Mattancherry Palace',
      imageCredit: 'Unsplash'
    },
    {
      id: 'kochi-paradesi-synagogue',
      name: 'Paradesi Synagogue & Jew Town',
      cityId: 'kochi',
      category: 'Spiritual & Sacred',
      shortSummary: '1568 active synagogue in the Commonwealth, paved with hand-painted 18th-century blue Cantonese willow-pattern tiles.',
      fullDescription: 'Constructed in 1568 by Spanish, Portuguese, and Dutch Sephardic Jewish merchants (known as Paradesi, meaning "foreigners") adjacent to the Raja of Kochi’s royal palace, this is the oldest active synagogue in the Commonwealth of Nations. Entering barefoot, visitors step onto an extraordinary floor paved with over a thousand hand-painted blue-and-white porcelain tiles imported from Canton in 1762, each bearing a unique floral willow-pattern design. Above hang glittering Belgian crystal oil chandeliers in blue and amber glass. In the center stands a solid brass pulpit (bimah), while the teak Ark enshrines four gold- and silver-crowned Torah scrolls dating back centuries. Outside stands the 1760 clock tower featuring four dials displaying Arabic, Hebrew, Malayalam, and Roman numerals.',
      historicalBackground: 'Built on land granted by the tolerant Hindu Raja of Kochi. Partially damaged during Portuguese cannon bombardment in 1662 and restored under Dutch patronage in 1664.',
      culturalSignificance: 'A testament to Kochi’s centuries of religious tolerance, where Jewish, Christian, Muslim, and Hindu communities lived as peaceful neighbors.',
      architecturalFeatures: 'Hand-painted Chinese blue porcelain tiles, Belgian crystal chandeliers, 1760 clock tower with multi-script dials, and brass bimah.',
      whyWorthVisiting: 'Experience the unique, peaceful beauty of one of the world’s most distinctive Jewish sanctuaries, surrounded by centuries-old spice and antique warehouses.',
      whatToExperience: 'Step barefoot across the cool hand-painted porcelain tiles, admire the crystal chandeliers, look up at the Hebrew clock tower, and browse the spice, cardamoms, and antique shops of Jew Town.',
      location: 'Synagogue Lane, Jew Town, Mattancherry, Kochi 682002',
      coordinates: [9.9575, 76.2597],
      suggestedDuration: '1 hour',
      bestTimeToVisit: 'Morning (10:00 AM – 12:30 PM) on non-Sabbath weekdays.',
      entryFeeInfo: '₹10 per person.',
      openingHoursInfo: 'Open Sunday to Thursday: 10:00 AM – 1:00 PM and 2:00 PM – 5:00 PM; Friday: 10:00 AM – 1:00 PM. Closed Saturdays (Sabbath) and Jewish holidays.',
      accessibilityInfo: 'Footwear must be deposited at the entrance porch; interior prayer hall is level with low stone threshold.',
      familySuitability: 'Deeply moving cultural landmark; dress respectfully (sleeveless tops and shorts are not permitted).',
      photographyNotes: 'Photography inside the synagogue prayer hall is strictly prohibited; the exterior courtyard and clock tower can be photographed.',
      nearbyCombinations: ['Mattancherry Palace', 'Jew Town spice emporiums', 'Cochin Spice Market'],
      transitAdvice: 'Located at the end of Synagogue Lane in Jew Town. Easily reached on foot from Mattancherry Palace (300m).',
      visitorTips: ['Cover shoulders and knees; hats or head coverings are respected.', 'Breathe deeply while walking through Synagogue Lane: sacks of fresh ginger, black pepper, and nutmeg are dried on sidewalks.'],
      officialLinks: [{ title: 'Cochin Synagogue Trust & Kerala Tourism', url: 'https://keralatourism.org' }],
      sourceNote: 'Cochin Paradesi Synagogue Elders & Kerala State Archaeology Records.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Historic whitewashed walls and clock tower of Paradesi Synagogue in Jew Town',
      imageCredit: 'Unsplash'
    },
    {
      id: 'kochi-st-francis-church',
      name: 'St. Francis Church (Fort Kochi)',
      cityId: 'kochi',
      category: 'History & Heritage',
      shortSummary: 'India’s oldest European church (1503), original burial site of explorer Vasco da Gama.',
      fullDescription: 'Constructed in 1503 by Portuguese Franciscan friars as a simple timber chapel and rebuilt in stone in 1516, St. Francis Church is the oldest European church building in India. It stood as a silent witness to the European struggle for dominance in the subcontinent: starting as Catholic under the Portuguese, transitioning to Protestant under the Dutch in 1663, and becoming Anglican under the British in 1795. Its most famous historical distinction is that Portuguese explorer Vasco da Gama, who died in Kochi on Christmas Eve in 1524 during his third voyage, was buried here beneath the floor; his tombstone remains clearly visible in the nave floor, although his mortal remains were returned to Lisbon in 1538. The interior features manually operated cloth fans (punkahs) suspended from high timber rafters.',
      historicalBackground: 'Conquered successively by three European colonial empires over four centuries, reflecting the violent history of the Indian Ocean spice trade.',
      culturalSignificance: 'The foundational physical monument of European colonial presence in Asia.',
      architecturalFeatures: 'Gabled timber facade, tiled bell-turret, stepped stone pinnacles, ancient colonial tombstones mounted on walls, and manual ceiling punkahs.',
      whyWorthVisiting: 'Stand at the exact physical intersection where the global age of European maritime colonialism began in 1498.',
      whatToExperience: 'View the marked burial tomb of Vasco da Gama, read the 17th-century Dutch and Portuguese carved stone epitaphs, admire the massive wooden punkahs, and walk through the tranquil surrounding graveyard.',
      location: 'Headland and Parade Ground, Fort Kochi, Kochi 682001',
      coordinates: [9.9658, 76.2414],
      suggestedDuration: '45 minutes',
      bestTimeToVisit: 'Morning (9:00 AM – 11:30 AM) or afternoon (2:30 PM – 4:30 PM).',
      entryFeeInfo: 'Free entry (ASI protected monument).',
      openingHoursInfo: 'Monday to Saturday: 7:00 AM – 6:30 PM; Sunday: 8:30 AM – 6:30 PM (except during Sunday service).',
      accessibilityInfo: 'Level stone pathways with gentle ramped thresholds into the nave; wheelchair accessible.',
      familySuitability: 'Peaceful and reflective; ideal for history lovers and students.',
      photographyNotes: 'Exterior church facade and historic tombstones can be photographed; keep cameras silent during prayer hours.',
      nearbyCombinations: ['Chinese Fishing Nets', 'Princess Street', 'Santa Cruz Cathedral Basilica'],
      transitAdvice: 'Located on the historic Parade Ground in Fort Kochi. 5 minutes walk from the Chinese Fishing Nets.',
      visitorTips: ['Read the engraved Dutch tombstones along the nave walls, which feature intricate 17th-century coat-of-arms crests.', 'Rent a bicycle nearby to explore the quiet colonial lanes of Fort Kochi.'],
      officialLinks: [{ title: 'ASI Thrissur Circle — St. Francis Church', url: 'https://asithrissurcircle.in' }],
      sourceNote: 'Archaeological Survey of India & Church of South India Records.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Whitewashed gabled facade of historic St. Francis Church in Fort Kochi',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1341 – 1500 CE',
      title: 'The Great Flood of 1341 & Rise of Kochi Port',
      description: 'A cataclysmic flood of the Periyar river silts up the ancient port of Muziris (Kodungallur) and tears open the natural harbour of Kochi, transforming it into the spice capital of the Arabian Sea.',
      keySites: ['Kochi Harbour Mouth', 'Chinese Fishing Nets early site']
    },
    {
      epoch: '1500 – 1663 CE',
      title: 'Portuguese Settlement & Fort Emmanuel',
      description: 'Pedro Álvares Cabral and Vasco da Gama arrive; the Portuguese construct Fort Emmanuel, Mattancherry Palace, and St. Francis Church, dominating the black pepper trade.',
      keySites: ['St. Francis Church', 'Mattancherry Palace', 'Paradesi Synagogue (1568)']
    },
    {
      epoch: '1663 – 1795 CE',
      title: 'Dutch East India Company (VOC) Golden Era',
      description: 'The Dutch capture Kochi, rebuild the palace, introduce botanical studies (Hortus Malabaricus), and foster merchant settlements in Jew Town and Fort Kochi.',
      keySites: ['Dutch Palace renovations', 'Bolgatty Palace (1744)', 'VOC Gate']
    },
    {
      epoch: '1795 – Present',
      title: 'British Modernization & Contemporary Biennale',
      description: 'British modern engineering turns Kochi into a modern deep-water port. In 2012, Kochi founds the Kochi-Muziris Biennale, turning heritage spice warehouses into the epicenter of contemporary global art.',
      keySites: ['Willingdon Island', 'Aspinwall House (Biennale hub)', 'Water Metro']
    }
  ],

  architecturalHeritageOverview: 'Kochi’s built environment is an extraordinary maritime layering: steep-pitched timber roofs with clay Mangalore tiles designed to shed monsoon downpours, Portuguese colonnades, Dutch pediments and lime floors, and Jewish timber bimahs—coexisting with traditional Kerala Nalukettu courtyards.',

  traditionsAndFestivals: [
    {
      title: 'Kochi-Muziris Biennale',
      seasonOrFrequency: 'Biannual (December to April, 4 months)',
      description: 'South Asia’s premier contemporary art exhibition. World-renowned international artists display site-specific installations, sculptures, and video projections inside restored 19th-century spice and coir warehouses across Fort Kochi and Mattancherry.',
      visitorEtiquette: 'Purchase season passes; take time to engage with docents and artists.'
    },
    {
      title: 'Cochin Carnival (New Year)',
      seasonOrFrequency: 'Last week of December',
      description: 'A vibrant community carnival ending on New Year’s Eve with the burning of a colossal 40-foot effigy of Pappanji (an old Portuguese patriarch figure) on Fort Kochi beach, welcoming the new year with fireworks and midnight street brass bands.',
      visitorEtiquette: 'Vibrant, packed beach crowds; travel on foot or bicycle within Fort Kochi.'
    }
  ],

  dishes: [
    {
      id: 'kochi-karimeen-pollichathu',
      name: 'Karimeen Pollichathu',
      localName: 'കരിമീൻ പൊള്ളിച്ചത്',
      culturalOrigin: 'The signature delicacy of the Vembanad backwaters and Syrian Christian kitchens.',
      description: 'Pearl spot fish (Karimeen) indigenous to Kerala’s brackish lagoons, marinated in red chilli, turmeric, and lime. Sautéed with an aromatic paste of shallots, ginger, garlic, green chillies, curry leaves, and tomatoes in coconut oil, tightly wrapped inside a fresh banana leaf, and slow-pan-roasted on a cast-iron tawa until the fish steams in its own juices and leaf aroma.',
      typicalIngredients: ['Fresh pearl spot (Karimeen) fish', 'Shallots (cheriya ulli)', 'Fresh curry leaves', 'Coconut oil', 'Banana leaf wrapper'],
      isVeg: false,
      whereToFind: 'Grand Pavilion (MG Road, Ernakulam), Paragon Restaurant, Fort House Restaurant (Fort Kochi), Oceanos.',
      priceCategory: 'Moderate',
      dietaryAdvice: 'Non-vegetarian (seafood). Rich in coconut oil and shallot masala. Contains fine central bones.',
      etiquetteTips: 'Carefully unwrap the charred banana leaf at your table to release the aromatic burst of steam; pair with fluffy appams.',
      image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'kochi-appam-stew',
      name: 'Fluffy Appam with Vegetable / Chicken Stew',
      localName: 'അപ്പവും ഇഷ്‌ട്യൂവും',
      culturalOrigin: 'Traditional Syrian Christian Sunday breakfast, celebrated across central Kerala.',
      description: 'Lacy, bowl-shaped pancakes made from fermented rice batter and coconut milk, characterized by a thick, pillowy, spongy center and paper-thin, crispy edges. Paired with a delicate, fragrant stew of chicken or fresh vegetables gently simmered in mild first-press coconut milk, cardamom, cinnamon, cloves, green chillies, and fresh curry leaves.',
      typicalIngredients: ['Fermented rice-coconut batter', 'Fresh coconut milk', 'Cardamom & cinnamon', 'Curry leaves', 'Potatoes & carrots'],
      isVeg: true,
      whereToFind: 'Kashi Art Café (Fort Kochi), Dhe Puttu, Malabar Junction, local tiffin tea houses.',
      priceCategory: 'Budget to Moderate',
      dietaryAdvice: 'Vegetarian and non-vegetarian versions available. Naturally gluten-free. Mild, soothing spice profile.',
      etiquetteTips: 'Tear a piece of the fluffy center, dip into the warm coconut milk stew, and spoon extra gravy over the bowl.',
      image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Fort Kochi: Princess Street & Peter Celli Street',
      character: 'Atmospheric colonial streets filled with garden art cafes, coastal seafood courtyards, and specialty coffee houses.',
      bestTime: 'Morning breakfast 8:30 AM – 11:00 AM and Evening dinner 7:00 PM – 10:30 PM.',
      highlights: ['Appam and breakfast at Kashi Art Café', 'Fresh grilled fish at Fort House waterfront', 'Pastries at Teapot Cafe'],
      visitorAdvice: 'The area is pedestrian and bicycle friendly; rent a bicycle to hop between cafes.'
    },
    {
      name: 'Mattancherry Spice Bazaars',
      character: 'Historic spice trading lanes filled with wholesale sacks of black pepper, dry ginger, cloves, and local Muslim biryani houses.',
      bestTime: 'Midday lunch 12:00 PM – 3:30 PM.',
      highlights: ['Kayees Rahmathulla Hotel for legendary mutton biryani', 'Fresh ginger juice at Jew Town stalls'],
      visitorAdvice: 'Kayees biryani often sells out by 2:00 PM; arrive early.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Kochi is one of India’s most relaxed, peaceful, and visitor-friendly cities.',
      'When hiring water ferries or private backwater shikara boats, ensure that all passengers are provided with certified life jackets.',
      'Tropical monsoon showers between June and August can be heavy; carry a sturdy umbrella and non-slip sandals.'
    ],
    transportPedestrian: [
      'The Kochi Water Metro connects Ernakulam to Fort Kochi and surrounding islands via sleek, air-conditioned battery-powered catamarans.',
      'Public SWTD passenger ferries between Ernakulam Jetty and Fort Kochi run every 20 minutes for just ₹6 per ticket; the most scenic and practical way to cross the harbor.',
      'Auto-rickshaws in Fort Kochi are convenient; confirm the destination and rate or book via Uber/Ola.'
    ],
    nightTravel: [
      'Fort Kochi and Marine Drive Ernakulam are peaceful, well-lit, and very safe for evening strolls.',
      'App cabs operate reliably across the mainland and island hubs.'
    ],
    accessibilityNotes: [
      'Kochi Metro and Water Metro stations are state-of-the-art with full step-free wheelchair boarding and lifts.',
      'Fort Kochi seaside promenade is flat, broad, and accessible.'
    ],
    emergencyContacts: [
      { title: 'Kerala Police Central Emergency', number: '112', note: '24/7 central emergency line' },
      { title: 'Fort Kochi Tourist Police Station', number: '0484 221 5455', note: 'Dedicated heritage zone tourist station' },
      { title: 'Coastal Police Helpdesk', number: '1093', note: 'Maritime safety and harbour rescue' },
      { title: 'General Hospital Ernakulam Emergency', number: '0484 236 1251', note: 'Government tertiary hospital' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Kerala State Police and Kerala Tourism Infrastructure Development Corporation reports.'
  },

  neighbourhoods: [
    {
      id: 'kochi-fort-kochi',
      name: 'Fort Kochi Heritage Quarter',
      cityId: 'kochi',
      character: 'Breezy coastal colonial island characterized by ancient rain trees, Portuguese and Dutch bungalows, art cafes, and sea promenades.',
      budgetTier: 'Moderate to Upscale',
      transitScore: 'Very High (Frequent public passenger ferries, Water Metro catamarans, and buses)',
      transitDetails: 'Direct ferry connections to Ernakulam in 20 minutes; highly walkable or bicycle-friendly.',
      walkabilityRating: 'Very High (Shaded streets, pedestrian waterfronts, and low vehicular speed).',
      accessibilityNotes: 'Vasco da Gama promenade is paved and level; historic churches have ramped entries.',
      heritageHighlights: ['Chinese Fishing Nets', 'St. Francis Church', 'Santa Cruz Basilica', 'Parade Ground'],
      foodHighlights: ['Kashi Art Café', 'Fort House Restaurant', 'Old Harbour Hotel dining'],
      greenSpaceNotes: 'Vasco da Gama Square, Parade Ground, and beachfront parkways.',
      safetyContext: 'One of the safest, most peaceful travel destinations in South Asia with round-the-clock safety.',
      methodologyNote: 'Evaluated using urban conservation guidelines and sustainable tourism management metrics.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'kochi-jew-town',
      name: 'Mattancherry & Jew Town',
      cityId: 'kochi',
      character: 'Historic spice and antique trading district filled with wholesale pepper merchants, historic synagogues, and royal palaces.',
      budgetTier: 'Budget-friendly to Moderate',
      transitScore: 'High (Mattancherry ferry jetty, auto-rickshaws, easy 15-minute walk from Fort Kochi)',
      transitDetails: 'Quick ferry connection; 3 km scenic auto ride from Fort Kochi.',
      walkabilityRating: 'High along Synagogue Lane and Palace Road; lively pedestrian streetscape.',
      accessibilityNotes: 'Streets are generally flat; shops have low stone thresholds.',
      heritageHighlights: ['Paradesi Synagogue', 'Mattancherry Palace', 'Dharmanath Jain Temple'],
      foodHighlights: ['Kayees Rahmathulla Hotel', 'Ginger House Restaurant on the waterfront'],
      greenSpaceNotes: 'Waterfront jetties overlooking backwater lagoons.',
      safetyContext: 'Very high social safety due to active generational merchant and resident community.',
      methodologyNote: 'Calculated from historical spice market density and heritage building inventories.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-kochi-black-gold',
      cityId: 'kochi',
      title: 'The Scent of Black Gold: How Pepper Conquered Empires',
      preview: 'Why ancient Roman senators, Portuguese caravels, and Dutch fleets all sailed across the globe for this single Malabar berry.',
      fullArticle: 'To walk down Bazaar Road in Mattancherry today is to breathe the same pungent fragrance that altered the political map of the world. Two thousand years ago, Roman historian Pliny the Elder complained that the Roman Empire was drained of over fifty million sesterces every year to purchase black pepper (Piper nigrum) from the Malabar coast, calling it "Black Gold". When the Ottoman Empire captured Constantinople in 1453 and blocked the overland Silk Road spice routes, European nations were desperate to find a direct sea route to Kochi’s pepper groves. It was this singular quest that drove Christopher Columbus west across the Atlantic and sent Vasco da Gama around the Cape of Good Hope to land in Kerala in 1498. As the Zamorin of Calicut famously remarked to a worried courtier about the Portuguese: "They may take our pepper vines, but they cannot take our Malabar rains."',
      locationName: 'Mattancherry Bazaar Road',
      factualExplanation: 'Documented in Pliny’s Naturalis Historia and Malabar Manual by William Logan.',
      sources: ['Malabar Manual by William Logan', 'The Pepper Coast by Robin Jeffrey'],
      relatedDestinationIds: ['kochi-mattancherry-palace', 'kochi-paradesi-synagogue'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1593693397690-362cb9666fc2?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Historic spice warehouses along the waters of Kochi'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '23°C – 31°C', advice: 'Peak travel season; pleasant humidity, sunny skies, and cool ocean breezes. Ideal for walking heritage lanes and taking backwater boat cruises.' },
      { season: 'Monsoon (Jun – Sep)', temperatureRange: '24°C – 29°C', advice: 'Heavy tropical monsoon rains; lush emerald vegetation, swollen backwaters, and Ayurvedic wellness season.' },
      { season: 'Summer (Mar – May)', temperatureRange: '26°C – 35°C', advice: 'Warm and humid; stay hydrated with fresh tender coconuts.' }
    ],
    transportInfrastructure: [
      { mode: 'Kochi Water Metro', coverage: 'High-speed electric AC catamarans connecting Ernakulam, Fort Kochi, Vypin, and islands', tip: 'Modern, air-conditioned, scenic, and costs just ₹20–₹40.' },
      { mode: 'SWTD Public Passenger Ferries', coverage: 'Runs every 20 minutes between Ernakulam Main Jetty and Fort Kochi', tip: 'Unbeatable value (₹6) and classic views of shipping channels.' },
      { mode: 'Kochi Metro Rail (KMRL)', coverage: 'Aluva to Thykoodam through Ernakulam city center', tip: 'Clean, elevated, connects seamlessly with the Water Metro hub at High Court Jetty.' }
    ],
    environmentalNotes: 'Vembanad Lake is an internationally recognized Ramsar wetland site. Kochi has prioritized green urban mobility through the world’s first solar-powered airport (CIAL) and electric Water Metro catamarans.',
    dataAttribution: 'Kerala Tourism Department & Kochi Metropolitan Transport Authority'
  }
};
