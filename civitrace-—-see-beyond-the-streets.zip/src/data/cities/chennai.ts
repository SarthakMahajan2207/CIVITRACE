import { City } from '../../types';

export const chennaiData: City = {
  id: 'chennai',
  name: 'Chennai',
  state: 'Tamil Nadu',
  region: 'Coromandel Coast',
  tagline: 'Gateway of South India & Classical Cultural Citadel',
  heroDescription: 'Overlooking the rolling surf of the Bay of Bengal along the ancient Coromandel coast, Chennai is the cultural heart of Tamil civilization. Here, 7th-century Pallava and Chola temples with soaring polychrome gopurams stand alongside 1640 colonial basalt fortresses, the second-longest urban beach in the world, the sublime bronze sculptures of the Chola empire, and the winter December Music Season (Marghazi)—the world’s largest festival of classical Carnatic music.',
  introSentence: 'A coastal cultural metropolis where ancient Dravidian temple gopurams, Carnatic vocal ragas, and Coromandel maritime history meet modern industrial dynamism.',
  coordinates: [13.0827, 80.2707],
  accentColor: 'amber',
  hexAccent: '#d97706',
  heroImage: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Soaring Dravidian gopuram with intricate sculptures of Kapaleeshwarar Temple in Mylapore, Chennai',
  imageCredit: 'Unsplash / Tamil Nadu Tourism Development Corporation',
  heritageThemes: ['Pallava & Chola Dravidian Roots', 'Mylapore Temple Urbanism', 'Colonial Fort St. George & Coromandel Trade', 'Carnatic Classical Music & Bharatanatyam', 'Filter Coffee & Vegetarian Tiffin Culture'],

  destinations: [
    {
      id: 'chennai-kapaleeshwarar',
      name: 'Kapaleeshwarar Temple & Mylapore Tank',
      cityId: 'chennai',
      category: 'Spiritual & Sacred',
      shortSummary: '7th-century Dravidian temple in Mylapore featuring a 37-metre polychrome gopuram and monumental sacred water tank.',
      fullDescription: 'Dedicated to Lord Shiva as Kapaleeshwarar and his consort Parvati as Karpagambal ("Goddess of the Wish-Yielding Tree"), this sacred complex in the ancient peacock settlement of Mylapore is the cultural soul of Chennai. While the original seaside temple was recorded in 7th-century hymns by the Nayanmar saints Appar and Sambandar, the current complex was reconstructed by Vijayanagara rulers in the 16th century after coastal erosion and Portuguese incursions. The temple is dominated by a majestic 37-metre east-facing gopuram (tower) encrusted with hundreds of stucco sculptures depicting Hindu mythology in brilliant polychrome hues. Across the street lies the colossal granite-stepped temple tank (teppakulam), where the annual float festival (Teppam) draws tens of thousands under the full moon.',
      historicalBackground: 'Hymned in ancient Sangam and devotional Bhakti poetry; historically associated with the sacred peacock (Mayil) legend that gave Mylapore its name.',
      culturalSignificance: 'The epicentre of Carnatic music sabhas, Bharatanatyam classical dance, and morning kolam (rice-powder sacred drawings) on threshold stones.',
      architecturalFeatures: 'Tiered Dravidian gopuram, granite pillared mandapas with musical stones, bronze vahana shrines, and massive stepped stone tank.',
      whyWorthVisiting: 'Experience the living spiritual and sensory core of Tamil culture, with wafting camphor, temple elephants, and ringing bronze bells.',
      whatToExperience: 'Walk barefoot through the granite temple corridors, study the intricate stucco figures on the gopuram, stroll around the sacred temple tank at sunset, and sample hot filter coffee at the mada street stalls.',
      location: '12, Vadakku Mada Street, Mylapore, Chennai 600004',
      coordinates: [13.0339, 80.2694],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Early morning (6:30 AM – 9:00 AM) or evening (5:00 PM – 7:30 PM) during evening aarti.',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Open daily: 6:00 AM – 12:30 PM and 4:00 PM – 9:30 PM.',
      accessibilityInfo: 'Footwear must be deposited at the outer shoe stand. Flat granite paving within the main courtyard; gentle ramps at the northern gate.',
      familySuitability: 'Deeply enriching cultural experience; dress conservatively (shoulders and knees covered).',
      photographyNotes: 'Gopuram exterior and temple tank can be freely photographed; photography inside the inner sanctum is strictly prohibited.',
      nearbyCombinations: ['San Thome Basilica', 'Ramakrishna Math', 'Mylapore Mada Street shopping'],
      transitAdvice: 'Thirumayilai MRTS Railway Station is 400m away; easily accessible via auto-rickshaw from Central or T. Nagar.',
      visitorTips: ['Visit Rayar’s Mess in the morning for their legendary mini-idlis and sweet pongal.', 'Look at the doorways along the Mada streets in the early morning to see women drawing intricate hand-drawn kolam geometric patterns.'],
      officialLinks: [{ title: 'Tamil Nadu Hindu Religious & Charitable Endowments (HR&CE)', url: 'https://hrce.tn.gov.in' }],
      sourceNote: 'Tamil Nadu HR&CE Department Archives & Mylapore Heritage Trust.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Soaring Dravidian gopuram of Kapaleeshwarar Temple in Chennai',
      imageCredit: 'Unsplash'
    },
    {
      id: 'chennai-san-thome',
      name: 'San Thome Basilica (Tomb of St. Thomas)',
      cityId: 'chennai',
      category: 'History & Heritage',
      shortSummary: 'Neo-Gothic Roman Catholic cathedral built over the 1st-century tomb of St. Thomas the Apostle.',
      fullDescription: 'Rising in pristine white spires above the sands of the Coromandel coast, the San Thome Basilica is one of only three known churches in the world constructed directly over the tomb of an Apostle of Jesus Christ (the other two being St. Peter’s Basilica in Rome and Santiago de Compostela in Spain). According to ancient Christian tradition, St. Thomas arrived in southern India in 52 CE, preaching along the Malabar and Coromandel coasts before being martyred on nearby St. Thomas Mount in 72 CE. Originally built by Portuguese navigators in 1523 over the tomb, the current cathedral was erected in 1896 by British architects in soaring Neo-Gothic style, featuring ribbed vaults, stained glass windows depicting the life of the Apostle, and a subterranean crypt chapel preserving his sacred relics.',
      historicalBackground: 'Recorded by Marco Polo who visited the shrine in 1292 CE. Elevated to the status of Minor Basilica by Pope Pius XII in 1956.',
      culturalSignificance: 'A cornerstone of two millennia of Indian Christianity and a revered pilgrimage site for believers of all denominations.',
      architecturalFeatures: 'Neo-Gothic spires reaching 47 metres, pointed lancet windows with stained glass imported from Germany, and subterranean marble crypt.',
      whyWorthVisiting: 'Experience one of the rarest apostolic pilgrimage sanctuaries on Earth located right along the ocean shoreline.',
      whatToExperience: 'Descend into the quiet subterranean crypt to view the tomb of St. Thomas, study the stained-glass panels, and visit the museum displaying ancient stone inscriptions, coins, and the spearhead associated with his martyrdom.',
      location: '38, Santhome High Road, Mylapore, Chennai 600004',
      coordinates: [13.0333, 80.2783],
      suggestedDuration: '1 hour',
      bestTimeToVisit: 'Morning (9:00 AM – 11:30 AM) or late afternoon (4:00 PM – 6:00 PM).',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Cathedral open daily: 6:00 AM – 9:00 PM; Museum open: 9:00 AM – 6:00 PM.',
      accessibilityInfo: 'Ground floor cathedral is fully wheelchair accessible with stone ramps at the side entrance.',
      familySuitability: 'Peaceful, contemplative atmosphere for all generations.',
      photographyNotes: 'Cathedral exterior and gardens can be photographed; keep cameras silent in the crypt chapel.',
      nearbyCombinations: ['Marina Beach Promenade', 'Kapaleeshwarar Temple', 'Light House Metro'],
      transitAdvice: 'Located directly on Santhome High Road. Bus stops outside the gate; Light House railway station is 1 km north.',
      visitorTips: ['Spend quiet moments in the museum behind the church to view the 16th-century stone Portuguese inscriptions.', 'Follow with an evening walk on the adjacent Marina Beach promenade.'],
      officialLinks: [{ title: 'San Thome Cathedral Basilica Official Portal', url: 'https://santhomecathedral.com' }],
      sourceNote: 'Archdiocese of Madras-Mylapore Historical Archives.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Soaring white Neo-Gothic spires of San Thome Basilica against blue sky',
      imageCredit: 'Unsplash'
    },
    {
      id: 'chennai-bronze-gallery',
      name: 'Government Museum & Chola Bronze Gallery (Egmore)',
      cityId: 'chennai',
      category: 'Art & Museums',
      shortSummary: 'India’s second oldest museum (1851) housing the world’s most magnificent collection of 9th-century Chola bronzes.',
      fullDescription: 'Established in 1851 on Pantheon Road in Egmore, the Government Museum complex is a treasure house of Indian archaeology and art, housed within striking Indo-Saracenic and Italianate heritage buildings. Its absolute crown jewel is the Bronze Gallery, which preserves the world’s supreme collection of 9th- to 13th-century lost-wax cast bronzes from the Imperial Chola dynasty. Foremost among them is the iconic 11th-century Nataraja—Shiva as the Cosmic Dancer—depicted balancing upon the demon of ignorance within an aureole of cosmic fire, hailed by sculptor Auguste Rodin as one of humanity’s greatest masterpieces. Other galleries showcase 2nd-century BCE Buddhist limestone sculptures from Amaravati, tribal ethnographic weapons, and British colonial oil paintings.',
      historicalBackground: 'Founded by the Madras Literary Society; expanded under colonial superintendents and Indian art historians into South Asia’s premier classical art repository.',
      culturalSignificance: 'Preserves the zenith of world metallurgy and sacred lost-wax (cire perdue) casting technique.',
      architecturalFeatures: 'Indo-Saracenic museum buildings with red brick and lime mortar, onion domes, stained glass skylights, and tiered teak balconies.',
      whyWorthVisiting: 'Nowhere else in the world can visitors stand face-to-face with such an overwhelming congregation of genuine imperial Chola masterworks.',
      whatToExperience: 'Study the divine kinetic poise of the Chola Nataraja, view the sublime statues of Parvati and Rama, and inspect the Amaravati Buddhist marble railings.',
      location: 'Pantheon Road, Egmore, Chennai 600008',
      coordinates: [13.0694, 80.2583],
      suggestedDuration: '2.5 to 3 hours',
      bestTimeToVisit: 'Morning hours (10:00 AM – 1:00 PM) for unhurried viewing of the bronze galleries.',
      entryFeeInfo: '₹15 for Indian citizens, ₹250 for foreign visitors; camera fee ₹200.',
      openingHoursInfo: 'Open Saturday to Thursday: 9:30 AM – 5:00 PM. Closed Fridays and National Holidays.',
      accessibilityInfo: 'Paved ground paths; ramps connect several historic wings, but upper galleries have stone stairs.',
      familySuitability: 'Inspiring and educational for children, historians, and art lovers.',
      photographyNotes: 'Camera permit required at ticketing; no flash permitted inside bronze and painting galleries.',
      nearbyCombinations: ['Connemara Public Library', 'National Art Gallery', 'Egmore Railway Station heritage facade'],
      transitAdvice: 'Egmore Metro Station and Egmore Railway Station are 800m away; easily accessible via auto-rickshaw.',
      visitorTips: ['Do not miss the adjoining Connemara Public Library, one of India’s four National Depository Libraries, with its breathtaking 1890 Victorian timber reading hall.', 'Hire an official museum audio guide to appreciate the iconographic nuances of the Chola bronzes.'],
      officialLinks: [{ title: 'Department of Museums, Government of Tamil Nadu', url: 'https://govtmuseumchennai.org' }],
      sourceNote: 'Government Museum Egmore Official Archaeological Catalogues.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Sculpted bronze figures and museum exhibits in classical gallery',
      imageCredit: 'Unsplash'
    },
    {
      id: 'chennai-marina-beach',
      name: 'Marina Beach & Bay Promenade',
      cityId: 'chennai',
      category: 'Nature & Outdoors',
      shortSummary: 'The world’s second-longest natural urban beach (13 km), buzzing with seaside carnival life and evening sea breezes.',
      fullDescription: 'Stretching 13 kilometres along the Coromandel coast from Fort St. George in the north to Besant Nagar in the south, Marina Beach is the democratic open-air living room of Chennai. Transformed into an elegant seaside promenade in the 1880s by Mountstuart Elphinstone Grant Duff, Governor of Madras, the broad sands are flanked by statues of Tamil literary giants (Thiruvalluvar, Avvaiyar, Kannagi) and monumental colonial buildings along Kamarajar Salai. Every evening, hundreds of thousands of citizens gather on the sands to enjoy the cooling sea breeze (thenral), sample freshly fried fish and spicy sundal (boiled seasoned chickpeas), ride miniature carousels, and watch the waves break against the Coromandel shore.',
      historicalBackground: 'Developed as a public esplanade in 1884. Has served as the epicentre of major civil rights movements, including the historic 2017 Jallikattu demonstrations.',
      culturalSignificance: 'The ultimate civic equalizer where people of every economic class gather to share sea air, street snacks, and conversation.',
      architecturalFeatures: 'Wide paved promenade, granite balustrades, historic Indo-Saracenic public facades (Madras University, Chepauk Palace) across the road.',
      whyWorthVisiting: 'Experience the electric, joyous spectacle of authentic Indian coastal life at dusk.',
      whatToExperience: 'Walk along the promenade from the Triumph of Labour statue, sample freshly made sundal served in paper cones, climb the Marina Lighthouse for a panoramic view over the ocean, and watch fishermen haul wooden catamarans.',
      location: 'Kamarajar Salai, Triplicane to Mylapore, Chennai',
      coordinates: [13.0500, 80.2824],
      suggestedDuration: '1.5 to 2 hours',
      bestTimeToVisit: 'Sunset (5:00 PM – 7:30 PM) when sea breezes pick up and street food vendors ignite their stoves.',
      entryFeeInfo: 'Beach entry is free; Marina Lighthouse climb: ₹20 for Indian citizens, ₹50 for foreign tourists.',
      openingHoursInfo: 'Open 24 hours. Lighthouse open: 10:00 AM – 1:00 PM and 3:00 PM – 5:00 PM (Closed Mondays). Swimming in the ocean is strictly prohibited by police due to treacherous undertows.',
      accessibilityInfo: 'Paved, wide promenade runs parallel to the beach; a dedicated permanent wooden ramp allows wheelchair users to reach close to the water’s edge near the Triumph of Labour statue.',
      familySuitability: 'Wonderful for families, evening walks, and people watching.',
      photographyNotes: 'Sunset silhouettes over catamarans; long shadows across the wide sandy beach.',
      nearbyCombinations: ['San Thome Basilica', 'Vivekanandar Illam (Ice House)', 'Chepauk Palace'],
      transitAdvice: 'Directly accessible via Light House, Tiruvallikeni, and Chepauk MRTS stations.',
      visitorTips: ['Never enter the sea for swimming; the Coromandel undertow is dangerous and strongly policed.', 'Carry small cash for sundal, roasted corn, and fresh fried fish.'],
      officialLinks: [{ title: 'Greater Chennai Corporation — Marina Promenade', url: 'https://chennaicorporation.gov.in' }],
      sourceNote: 'Greater Chennai Corporation & Tamil Nadu Maritime Board.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1566552881560-0be862a7c445?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Wide sandy beach and ocean waves of Marina Beach in Chennai at sunset',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1st – 9th Century CE',
      title: 'Pallava Dynasty & Ancient Port of Mylapore',
      description: 'Mylapore thrives as a major Indian Ocean trade port exporting peacocks and textiles to the Roman Empire; Pallavas carve monolithic temples nearby at Mamallapuram.',
      keySites: ['Kapaleeshwarar original site', 'San Thome St. Thomas relics', 'Mamallapuram (coastal heritage)']
    },
    {
      epoch: '1639 – 1947 CE',
      title: 'British Fort St. George & Madras Presidency',
      description: 'The British East India Company acquires a strip of sandy beach in 1639 and builds Fort St. George, establishing the capital of the Madras Presidency and the roots of modern urban administration.',
      keySites: ['Fort St. George & St. Mary’s Church', 'Government Museum Egmore', 'High Court of Madras']
    },
    {
      epoch: 'Post-Independence',
      title: 'Dravidian Renaissance & Cultural Capital',
      description: 'Chennai becomes the hub of the Dravidian political movement, Tamil cinema (Kollywood), automobile manufacturing, and the global revitalization of Carnatic classical arts.',
      keySites: ['Kalakshetra Foundation', 'The Music Academy (TTK Road)', 'Valluvar Kottam']
    }
  ],

  architecturalHeritageOverview: 'Chennai is the global capital of both classical Dravidian temple architecture—with towering granite and stucco gopurams—and the 19th-century "Indo-Saracenic" style pioneered by British architects Robert Chisholm and Henry Irwin, who fused Islamic arches and Hindu domes with Victorian administrative brickwork.',

  traditionsAndFestivals: [
    {
      title: 'The December Music Season (Marghazi Festival)',
      seasonOrFrequency: 'Mid-December to mid-January (Marghazi month)',
      description: 'The world’s largest classical music festival, running continuously since 1927. Over 2,000 concerts of classical Carnatic vocal, veena, mridangam, and Bharatanatyam dance are performed across historic sabhas like The Music Academy and Narada Gana Sabha, paired with legendary sabha canteen tiffins.',
      visitorEtiquette: 'Arrive before concert start times; audience silence is strictly observed during raga alapana.'
    },
    {
      title: 'Pongal Harvest Festival',
      seasonOrFrequency: 'Mid-January (Thai month, 4 days)',
      description: 'The premier Tamil thanksgiving festival celebrating harvest and the sun god. Clay pots boil over with fresh rice, milk, and jaggery to shouts of "Pongalo Pongal!", while cows are washed and adorned with garlands.',
      visitorEtiquette: 'Experience traditional festivities in residential areas like Mylapore and Triplicane with joyful community warmth.'
    }
  ],

  dishes: [
    {
      id: 'chennai-filter-coffee',
      name: 'Madras Degree Filter Coffee',
      localName: 'மதராஸ் ஃபில்டர் காபி',
      culturalOrigin: 'The defining social and sensory ritual of Tamil culture, refined over a century in Brahmin tiffin houses.',
      description: 'A rich, aromatic concoction brewed using dark-roasted plantation peaberry and robusta coffee beans with a touch of chicory, steeped in a brass filter. The thick decoction is mixed with scalding pure cow’s milk and aerated vigorously by pouring between a brass dabarah and tumbler from arm’s length, creating a frothy, velvety crema.',
      typicalIngredients: ['Dark-roasted coffee-chicory blend', 'Fresh boiled cow milk', 'Cane sugar', 'Brass drip decoction'],
      isVeg: true,
      whereToFind: 'Rayar’s Mess (Mylapore), Madras Coffee House, Vishranthi (Besant Nagar), Saravana Bhavan.',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Can be ordered "strong" (kadum kaapi) or "sugar kam".',
      etiquetteTips: 'Never drink through a plastic straw; sip directly from the curved lip of the brass tumbler, or cool small sips in the dabarah bowl.',
      image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'chennai-chettinad-chicken',
      name: 'Chettinad Chicken Pepper Fry',
      localName: 'செட்டிநாடு சிக்கன் வறுவல்',
      culturalOrigin: 'The culinary heritage of the wealthy Nattukottai Chettiar trading merchants of southern Tamil Nadu.',
      description: 'Tender country chicken braised in a freshly dry-roasted masala of star anise, kalpasi (black stone flower), fennel, cinnamon, and whole black peppercorns, tempered with fresh curry leaves and shallots in cold-pressed sesame (gingelly) oil until intensely aromatic and dark.',
      typicalIngredients: ['Country chicken', 'Kalpasi (stone flower)', 'Black peppercorns', 'Star anise', 'Curry leaves', 'Gingelly oil'],
      isVeg: false,
      whereToFind: 'Anjappar Chettinad, Ponnusamy Hotel, Karaikudi Restaurant (Mylapore), Dindigul Thalappakatti.',
      priceCategory: 'Moderate',
      dietaryAdvice: 'Non-vegetarian. Peppery and intensely spiced; enjoy with flaky parotta or steamed rice.',
      etiquetteTips: 'Order a cooling bowl of curd rice (thayir sadam) at the end of the meal to soothe the palate.',
      image: 'https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Mylapore Mada Streets',
      character: 'Sacred streets surrounding the temple, famous for hundred-year-old vegetarian mess halls, ghee podi idlis, and crispy medu vadas.',
      bestTime: 'Morning 7:00 AM – 10:30 AM and Evening 5:00 PM – 8:00 PM.',
      highlights: ['Mini idli and pongal at Rayar’s Mess', 'Ghee roast dosa at Karpagambal Mess', 'Degree coffee at Mylapore filter coffee stalls'],
      visitorAdvice: 'Rayar’s Mess is located in a tiny residential alley with limited seating; expect to wait on weekend mornings.'
    },
    {
      name: 'George Town & Sowcarpet',
      character: 'Historic northern commercial lanes offering north-south fusion street food, kachoris, murukku sandwiches, and sweets.',
      bestTime: 'Afternoon and evening (3:30 PM – 9:00 PM).',
      highlights: ['Murukku sandwich at Kakada Ramprasad', 'Onion kachoris', 'Badam milk at Anmol'],
      visitorAdvice: 'Labyrinthine lanes; best explored on foot after taking the Metro to High Court or Chennai Central.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Chennai is widely celebrated as one of the safest metropolitan cities in India for solo, female, and family travelers.',
      'Coromandel summer humidity from April to June is intense; explore monuments early in the morning and drink fresh tender coconut water.',
      'Ocean rip currents at Marina and Elliot’s beaches are strong; never enter the water past ankle depth.'
    ],
    transportPedestrian: [
      'Chennai Metro (Blue and Green Lines) is modern, air-conditioned, and connects Central, Egmore, and the airport seamlessly.',
      'Auto-rickshaw drivers frequently quote arbitrary rates; book via Ola, Uber, or Rapido apps for transparent fares.',
      'Suburban and MRTS trains run frequently along the coastal corridor from Central to Beach and Velachery.'
    ],
    nightTravel: [
      'Besant Nagar (Elliot’s Beach), Mylapore, and Nungambakkam are safe, family-friendly, and active until midnight.',
      'App cabs operate reliably 24/7 with instant airport pickups.'
    ],
    accessibilityNotes: [
      'Chennai Metro stations feature elevators, tactile pathways, and level train boarding.',
      'Marina Beach features a permanent accessible wooden ramp allowing wheelchair users to reach close to the surf line.'
    ],
    emergencyContacts: [
      { title: 'Chennai City Police Emergency', number: '112', note: 'Unified 24/7 emergency dispatch' },
      { title: 'Women Police Helpline', number: '1091', note: 'All Women Police Stations (AWPS)' },
      { title: 'Tourist Police Assistance', number: '044 2846 1422', note: 'Dedicated visitor kiosks at Central and Marina' },
      { title: 'Government General Hospital Emergency', number: '044 2530 5000', note: 'Premier tertiary medical trauma center' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Greater Chennai Police Commissionerate and Tamil Nadu Tourism Development Corporation.'
  },

  neighbourhoods: [
    {
      id: 'chennai-mylapore',
      name: 'Mylapore Heritage Precinct',
      cityId: 'chennai',
      character: 'The classical soul of Chennai, filled with temple tanks, Carnatic music sabhas, traditional silk saree shops, and generational mess kitchens.',
      budgetTier: 'Budget-friendly to Moderate',
      transitScore: 'High (Thirumayilai MRTS station, abundant buses, short auto ride to Metro)',
      transitDetails: 'Direct connection along the MRTS corridor; highly walkable around the temple precinct.',
      walkabilityRating: 'High around the four Mada streets, with vibrant shopfronts and pedestrian pace.',
      accessibilityNotes: 'Level streets with tree shade; temples require bare feet and have low stone thresholds.',
      heritageHighlights: ['Kapaleeshwarar Temple', 'San Thome Basilica', 'Ramakrishna Math'],
      foodHighlights: ['Rayar’s Mess', 'Karpagambal Mess', 'Mami Tiffin Stall'],
      greenSpaceNotes: 'Nageswara Rao Park offers a peaceful walking trail with Carnatic weekend morning acoustic sessions.',
      safetyContext: 'One of Chennai’s most peaceful and socially cohesive traditional neighbourhoods.',
      methodologyNote: 'Evaluated using heritage conservation listings and community vibrancy surveys.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'chennai-besant-nagar',
      name: 'Besant Nagar & Elliot’s Beach',
      cityId: 'chennai',
      character: 'Relaxed, bohemian coastal neighbourhood anchored by Elliot’s Beach, the Theosophical Society gardens, and contemporary cafes.',
      budgetTier: 'Moderate to Upscale',
      transitScore: 'High (Easily reached by app cabs, city buses, and autos from Adyar)',
      transitDetails: 'Broad, tree-shaded avenues with low traffic congestion.',
      walkabilityRating: 'Very High (Pedestrian beach promenade and shaded avenues around Damodar gardens).',
      accessibilityNotes: 'Paved beach promenade; curb ramps present across major residential cross-streets.',
      heritageHighlights: ['Karl Schmidt Memorial', 'Theosophical Society H.Q. & 450-year-old banyan tree', 'Ashtalakshmi Temple'],
      foodHighlights: ['Murugan Idli Shop', 'Mash Restobar', 'Artisanal coastal bakeries'],
      greenSpaceNotes: 'Theosophical Society grounds span 260 acres of tropical forest and estuary.',
      safetyContext: 'Extremely safe day and night, popular with families, joggers, and evening walkers.',
      methodologyNote: 'Based on coastal public space accessibility and residential safety indexes.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-chennai-december-season',
      cityId: 'chennai',
      title: 'The Great Marghazi Miracle: The World’s Biggest Classical Music Festival',
      preview: 'How every December, over 2,000 concerts transform Chennai into an acoustic wonderland where temple ragas and sabha canteen tiffins reign supreme.',
      fullArticle: 'Every December, as cool sea breezes replace the Coromandel heat, Chennai transforms into the global capital of acoustic music. Known as the Marghazi Festival or December Music Season, this tradition began in 1927 to celebrate the founding of the Madras Music Academy. Across six weeks, more than 80 voluntary cultural societies (sabhas) host over two thousand live concerts of Carnatic vocal music, veena, mridangam, and classical Bharatanatyam dance. The festival is renowned not only for its uncompromising artistic rigor—where vocalists improvise complex ragas and mathematical rhythmic kalpanaswarams for hours—but also for its culinary culture. Every sabha contracts a master wedding caterer to run an on-site canteen, where patrons debate the subtleties of a Todi raga while relishing piping hot asoka halwa, ghee roast dosas, and degree filter coffee.',
      locationName: 'The Music Academy & Mylapore Sabhas',
      factualExplanation: 'Documented by the Madras Music Academy and UNESCO Creative Cities Network (Chennai was designated a UNESCO Creative City of Music in 2017).',
      sources: ['A Southern Music by T.M. Krishna', 'Madras Music Academy Centennial Archives'],
      relatedDestinationIds: ['chennai-kapaleeshwarar'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Classical Indian music and heritage performance hall'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '21°C – 30°C', advice: 'Best time to visit; pleasant coastal breezes, cultural music festivals, and outdoor heritage walks.' },
      { season: 'Northeast Monsoon (Oct – Nov)', temperatureRange: '23°C – 29°C', advice: 'Chennai receives its primary rainfall during this period; check local weather advisories for heavy coastal rains.' },
      { season: 'Summer (Apr – Jun)', temperatureRange: '28°C – 41°C', advice: 'High humidity and tropical heat (Agni Nakshatram); stay hydrated with tender coconut water.' }
    ],
    transportInfrastructure: [
      { mode: 'Chennai Metro', coverage: 'Direct connection from Chennai International Airport to Central and Egmore rail hubs', tip: 'Fast, step-free, fully air-conditioned; best way to reach downtown from the airport.' },
      { mode: 'MRTS & Suburban Trains', coverage: 'Runs along the coast from Central to Beach, Mylapore, and Velachery', tip: 'Very cheap (₹5–₹10), great views of the city canal and coastline.' },
      { mode: 'App-Based Cabs & Autos', coverage: 'Wide availability via Uber, Ola, and Rapido', tip: 'Saves you from having to negotiate on the street with auto drivers.' }
    ],
    environmentalNotes: 'The Coromandel sea breeze provides natural atmospheric ventilation. The city’s wetlands, notably the Pallikaranai Marsh and Adyar Estuary, serve as critical bird sanctuaries and flood buffers.',
    dataAttribution: 'Tamil Nadu Tourism Development Corporation & Greater Chennai Corporation'
  }
};
