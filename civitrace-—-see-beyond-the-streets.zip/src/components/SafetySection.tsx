import React, { useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  PhoneCall,
  PlusCircle,
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Send,
  X
} from 'lucide-react';
import { SafetyGuide, CommunityReport } from '../types';

interface SafetySectionProps {
  cityName: string;
  cityId: string;
  safetyGuide: SafetyGuide;
  communityReports: CommunityReport[];
  onAddCommunityReport: (report: Omit<CommunityReport, 'id' | 'timestamp' | 'status'>) => void;
}

export const SafetySection: React.FC<SafetySectionProps> = ({
  cityName,
  cityId,
  safetyGuide,
  communityReports,
  onAddCommunityReport,
}) => {
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportTitle, setReportTitle] = useState('');
  const [reportCategory, setReportCategory] = useState<CommunityReport['category']>('Pedestrian Safety');
  const [reportNeighbourhood, setReportNeighbourhood] = useState('');
  const [reportDescription, setReportDescription] = useState('');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportTitle.trim() || !reportDescription.trim()) return;

    onAddCommunityReport({
      cityId,
      category: reportCategory,
      title: reportTitle.trim(),
      neighbourhood: reportNeighbourhood.trim() || 'General City Area',
      description: reportDescription.trim(),
    });

    setSubmittedFeedback(true);
    setTimeout(() => {
      setSubmittedFeedback(false);
      setShowReportModal(false);
      setReportTitle('');
      setReportDescription('');
      setReportNeighbourhood('');
    }, 1500);
  };

  const getStatusBadge = (status: CommunityReport['status']) => {
    switch (status) {
      case 'Verified by civic/editorial source':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-[11px] font-semibold flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> Verified by Civic / Editorial Source
          </span>
        );
      case 'Under review':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-[11px] font-semibold flex items-center gap-1">
            <Clock className="w-3 h-3" /> Under Review
          </span>
        );
      case 'Resolved / Outdated':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-slate-700 border border-slate-600 text-slate-300 text-[11px] font-semibold">
            Resolved / Outdated
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-semibold flex items-center gap-1">
            <AlertCircle className="w-3 h-3 text-slate-400" /> Unverified Community Report
          </span>
        );
    }
  };

  return (
    <section id="safety" className="py-16 sm:py-24 bg-[#080c14] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span>Responsible Exploration</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
            Safety & Travel Planning for {cityName}
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Practical visitor guidelines grounded in municipal transport notices and emergency infrastructure. No fabricated crime statistics or arbitrary risk scores.
          </p>
        </div>

        {/* 4 Core Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12 sm:mb-16">
          {/* General Precautions */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 space-y-3 shadow-md">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" /> General Precautions
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {safetyGuide.generalPrecautions.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Transport & Pedestrian */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 space-y-3 shadow-md">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> Transport & Pedestrian
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {safetyGuide.transportPedestrian.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-400 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Night-time Planning */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 space-y-3 shadow-md">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> Night-Time Guidance
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {safetyGuide.nightTravel.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Accessibility Notes */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 space-y-3 shadow-md">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4" /> Terrain & Accessibility
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {safetyGuide.accessibilityNotes.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Emergency Contacts Banner */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 mb-12 sm:mb-16">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-xs uppercase tracking-wider text-red-400 font-bold flex items-center gap-1.5 mb-1">
                <PhoneCall className="w-4 h-4" /> Official Emergency Services
              </span>
              <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white">
                Emergency Helplines & Civic Contacts
              </h3>
            </div>
            <span className="text-xs text-slate-400 max-w-sm">
              Sourced from central government and municipal police commissionerate databases.
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {safetyGuide.emergencyContacts.map((contact, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <span className="text-xs text-slate-400 block mb-1">{contact.title}</span>
                  <span className="text-xl font-bold font-mono text-white tracking-wide block">
                    {contact.number}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">{contact.note}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Data Limitations Disclosure */}
        <div className="rounded-2xl bg-amber-950/15 border border-amber-500/30 p-6 mb-12 sm:mb-16 flex flex-col md:flex-row gap-4 items-start">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 shrink-0">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-base font-editorial font-bold text-amber-200">
              CIVITRACE Data Transparency & Limitations
            </h4>
            <p className="text-xs sm:text-sm text-amber-100/80 mt-1 leading-relaxed">
              {safetyGuide.limitationsDisclaimer}
            </p>
            <p className="text-xs text-slate-400 mt-2">
              We never fabricate "crime scores" or label entire historic neighbourhoods dangerous based on isolated incidents. If reliable verified data is unavailable for a metric, we report "Insufficient verified data".
            </p>
          </div>
        </div>

        {/* Community Observations & Reporting Section */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <span>Community Observations & Field Reports</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Moderated civic observations submitted by residents and travelers with explicit verification labels.
              </p>
            </div>

            <button
              onClick={() => setShowReportModal(true)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs sm:text-sm shadow-md transition-all self-start sm:self-auto"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Submit Community Observation</span>
            </button>
          </div>

          {/* Reports Feed */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {communityReports.map((report) => (
              <div
                key={report.id}
                className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3 flex flex-col justify-between shadow-xs"
              >
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-semibold text-amber-300">
                      [{report.category}]
                    </span>
                    {getStatusBadge(report.status)}
                  </div>
                  <h4 className="text-base font-editorial font-bold text-white">
                    {report.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1.5 leading-relaxed">
                    {report.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Location: <strong className="text-slate-300">{report.neighbourhood}</strong></span>
                  <span>{report.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Community Report Submission Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowReportModal(false)}
          />

          <div className="relative w-full max-w-lg bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl p-6 z-10 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div>
                <h3 className="text-lg font-editorial font-bold text-white">
                  Submit Community Observation for {cityName}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Reports are published transparently under review. Never submit emergency calls or personal private information here.
                </p>
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {submittedFeedback ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto" />
                <h4 className="text-lg font-bold text-white">Observation Submitted</h4>
                <p className="text-xs text-slate-400">
                  Your report has been logged and marked "Under review" by the CIVITRACE community desk.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReport} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Reporting Category *
                  </label>
                  <select
                    value={reportCategory}
                    onChange={(e: any) => setReportCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                  >
                    <option value="Pedestrian Safety">Pedestrian Safety (Footpaths, crossings)</option>
                    <option value="Lighting & Night Walkability">Lighting & Night Walkability</option>
                    <option value="Crowd Congestion">Crowd Congestion / Festive Queue Advice</option>
                    <option value="Transit Accessibility">Transit Accessibility / Wheelchair ramps</option>
                    <option value="Civic Note">Civic Note / Helpful Travel Tip</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Neighbourhood / Specific Street *
                  </label>
                  <input
                    type="text"
                    required
                    value={reportNeighbourhood}
                    onChange={(e) => setReportNeighbourhood(e.target.value)}
                    placeholder="e.g. Sadashiv Peth, Colaba Causeway, Badi Chaupar..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Observation Headline *
                  </label>
                  <input
                    type="text"
                    required
                    value={reportTitle}
                    onChange={(e) => setReportTitle(e.target.value)}
                    placeholder="Concise factual description of what visitors should know..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Detailed Observation & Advice *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={reportDescription}
                    onChange={(e) => setReportDescription(e.target.value)}
                    placeholder="Provide details on conditions, timing, alternative routes, or practical tips..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowReportModal(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow-md transition-all"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Report</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
