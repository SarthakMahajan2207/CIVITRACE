import React, { useState } from 'react';
import {
  BarChart3,
  CloudSun,
  Train,
  Leaf,
  Navigation,
  Compass,
  MapPin,
  CheckCircle2,
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import { City, Destination } from '../types';

interface CityInsightsSectionProps {
  city: City;
  onOpenDestination: (destination: Destination) => void;
}

export const CityInsightsSection: React.FC<CityInsightsSectionProps> = ({
  city,
  onOpenDestination,
}) => {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [geoStatus, setGeoStatus] = useState<'idle' | 'requesting' | 'granted' | 'denied'>('idle');
  const [geoError, setGeoError] = useState<string | null>(null);

  // Haversine distance formula in kilometres
  const calculateDistanceKm = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const handleRequestLocation = () => {
    if (!navigator.geolocation) {
      setGeoStatus('denied');
      setGeoError('Geolocation is not supported by your browser.');
      return;
    }

    setGeoStatus('requesting');
    setGeoError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setGeoStatus('granted');
      },
      (error) => {
        setGeoStatus('denied');
        setGeoError(
          error.code === 1
            ? 'Location permission was denied. You can still explore all destinations on the map.'
            : 'Unable to retrieve location. Please check your network or device settings.'
        );
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  // Sort destinations by distance if user location is granted
  const nearbyDestinations = userLocation
    ? [...city.destinations]
        .map((d) => ({
          ...d,
          distanceKm: calculateDistanceKm(
            userLocation.lat,
            userLocation.lng,
            d.coordinates[0],
            d.coordinates[1]
          ),
        }))
        .sort((a, b) => a.distanceKm - b.distanceKm)
    : [];

  return (
    <section id="insights" className="py-16 sm:py-24 bg-[#080c14] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
            <BarChart3 className="w-4 h-4" />
            <span>Civic & Environmental Intelligence</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
            City Intelligence & Travel Context
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Consolidated seasonal climate analysis, transit network structure, and transparent environmental disclosures for {city.name}.
          </p>
        </div>

        {/* 3 Columns: Climate, Mobility, Environment */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 sm:mb-16">
          {/* Seasonal Climate Guide */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-md flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-amber-400 text-sm font-semibold mb-2">
                <CloudSun className="w-4 h-4" />
                <span>Seasonal Climate Dynamics</span>
              </div>
              <h3 className="text-lg font-editorial font-bold text-white mb-3">
                Weather & Seasonality Guide
              </h3>
              <div className="space-y-3">
                {city.insights.seasonalClimate.map((c, i) => (
                  <div key={i} className="p-3 rounded-xl bg-slate-950/70 border border-slate-850 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-white">{c.season}</span>
                      <span className="text-amber-300 font-mono text-[11px]">{c.temperatureRange}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">{c.advice}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500">
              Source: India Meteorological Department (IMD) historical climatology.
            </div>
          </div>

          {/* Transport Infrastructure */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-md flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-teal-400 text-sm font-semibold mb-2">
                <Train className="w-4 h-4" />
                <span>Mobility Infrastructure</span>
              </div>
              <h3 className="text-lg font-editorial font-bold text-white mb-3">
                Public Transit Networks
              </h3>
              <div className="space-y-3">
                {city.insights.transportInfrastructure.map((t, i) => (
                  <div key={i} className="p-3 rounded-xl bg-slate-950/70 border border-slate-850 space-y-1">
                    <span className="font-semibold text-white text-xs block">{t.mode}</span>
                    <span className="text-[11px] text-teal-300/80 block">{t.coverage}</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed mt-0.5">{t.tip}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500">
              Source: State Urban Transit Authorities & Railway zones.
            </div>
          </div>

          {/* Environmental Conditions */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-md flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold mb-2">
                <Leaf className="w-4 h-4" />
                <span>Environmental Disclosures</span>
              </div>
              <h3 className="text-lg font-editorial font-bold text-white mb-3">
                Air & Ecological Conditions
              </h3>
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-850 text-xs text-slate-300 leading-relaxed space-y-3">
                <p>{city.insights.environmentalNotes}</p>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-amber-200/90">
                  Notice: Real-time AQI fluctuates with wind patterns and seasonal agricultural cycles. We do not present static models as live sensor readings.
                </div>
              </div>
            </div>
            <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500">
              Source: {city.insights.dataAttribution}.
            </div>
          </div>
        </div>

        {/* Geolocation Tool: "Find Nearest Discoveries" */}
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-850 border border-slate-800 p-6 sm:p-8 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
                <Navigation className="w-4 h-4" />
                <span>Geospatial Proximity Assistant</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-editorial font-bold text-white">
                Find Nearest Cultural Discoveries in {city.name}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
                We strictly ask your explicit browser permission before accessing device coordinates. Your location is processed solely within your browser and is never stored or tracked.
              </p>
            </div>

            {geoStatus !== 'granted' && (
              <button
                onClick={handleRequestLocation}
                disabled={geoStatus === 'requesting'}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:bg-slate-800 text-white font-semibold text-xs sm:text-sm shadow-md transition-all self-start md:self-auto shrink-0"
              >
                <Compass className="w-4 h-4" />
                <span>{geoStatus === 'requesting' ? 'Locating...' : 'Enable Location Proximity'}</span>
              </button>
            )}
          </div>

          {geoError && (
            <div className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 mb-4">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{geoError}</span>
            </div>
          )}

          {geoStatus === 'granted' && nearbyDestinations.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Location found! Closest cultural destinations to your position in {city.name}:</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {nearbyDestinations.slice(0, 3).map((d) => (
                  <div
                    key={d.id}
                    className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-colors flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-amber-300 font-bold mb-1">
                        <span>{d.name}</span>
                        <span className="font-mono text-emerald-400">~{d.distanceKm.toFixed(1)} km</span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mb-2">{d.location}</span>
                      <p className="text-xs text-slate-300 line-clamp-2">{d.shortSummary}</p>
                    </div>

                    <button
                      onClick={() => onOpenDestination(d)}
                      className="mt-3 text-xs text-amber-400 hover:underline font-semibold flex items-center gap-1 self-start"
                    >
                      View Dossier →
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
