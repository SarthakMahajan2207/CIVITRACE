import { City } from '../../types';

export const hyderabadData: City = {
  id: 'hyderabad',
  name: 'Hyderabad',
  state: 'Telangana',
  region: 'Northern Deccan Plateau',
  tagline: 'City of Pearls & Sultanate Diamond Capital',
  heroDescription: 'Perched on the granite boulders of the Musi river valley, Hyderabad is a royal city forged by the Qutb Shahi sultans and the Asaf Jahi Nizams. Renowned as the historic source of the world’s most legendary diamonds—including the Koh-i-Noor and Hope diamonds—Hyderabad seamlessly bridges medieval acoustic fortresses, French-chateau palaces, fragrant saffron-infused dum biryanis, and cutting-edge biotechnology corridors.',
  introSentence: 'A majestic Deccan sultanate capital where granite hilltop fortresses, stucco minarets, Irani chai cafes, and royal pearl bazaars tell stories of imperial grandeur.',
  coordinates: [17.3850, 78.4867],
  accentColor: 'indigo',
  hexAccent: '#4f46e5',
  heroImage: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Charminar illuminated at dusk in the historic heart of Old Hyderabad',
  imageCredit: 'Unsplash / Telangana Heritage & Tourism Department',
  heritageThemes: ['Qutb Shahi Dynasty & Charminar (1591)', 'Golconda Diamond Mining & Acoustic Engineering', 'Asaf Jahi Nizami Splendour & Chowmahalla', 'Irani Cafe & Culinary Dum Tradition', 'HITEC City & Contemporary Technology'],

  destinations: [
    {
      id: 'hyd-charminar',
      name: 'Charminar & Laad Bazaar',
      cityId: 'hyderabad',
      category: 'History & Heritage',
      shortSummary: '1591 four-columned triumphal arch and mosque erected by Sultan Muhammad Quli Qutb Shah.',
      fullDescription: 'Erected in 1591 by Sultan Muhammad Quli Qutb Shah to mark the cessation of a devastating plague and celebrate the founding of his new capital, Charminar is the defining architectural symbol of Hyderabad. Standing at the intersection of historic trade routes, this square granite and lime-mortar monument features four monumental grand arches facing the cardinal directions, each 11 metres wide. At its four corners rise four soaring 48.7-metre minarets crowned by fluted bulbous domes, featuring 149 winding stone steps. The second floor houses the city’s oldest functioning mosque with 45 prayer spaces. Radiating west from the monument is Laad Bazaar, an enchanting historic market fragrant with attar (perfume) and glittering with thousands of hand-crafted lac bangles, pearls, and bridal brocades.',
      historicalBackground: 'Built to commemorate the eradication of cholera and plague; planned as the central pivot of a grid city modeled on the Persian concept of paradise.',
      culturalSignificance: 'The soul of Dakhni culture, Hyderabadi communal harmony, and the vibrant night markets of Ramadan.',
      architecturalFeatures: 'Qutb Shahi Indo-Islamic architecture with Persian geometric symmetry, cusped multi-foil arches, ornamental stucco screens, and double-storey arcades.',
      whyWorthVisiting: 'Experience the kinetic pulse of 430 years of uninterrupted bazaar commerce directly beneath an imperial stone icon.',
      whatToExperience: 'Climb the spiral stone staircase to the upper gallery for views over Mecca Masjid and the surrounding bazaar, browse lac bangles in Laad Bazaar, and sip Irani chai at Nimrah Café.',
      location: 'Charminar Road, Char Kaman, Ghansi Bazaar, Hyderabad 500002',
      coordinates: [17.3616, 78.4747],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Morning (8:30 AM – 10:30 AM) for tranquil architecture viewing, or evening (6:30 PM – 9:00 PM) for illuminated night markets.',
      entryFeeInfo: '₹25 for Indian citizens, ₹300 for foreign visitors (ASI digital ticketing).',
      openingHoursInfo: 'Open daily: 9:00 AM – 5:30 PM. Bazaar stalls remain open until 11:00 PM.',
      accessibilityInfo: 'The pedestrianized heritage plaza surrounding Charminar is level and paved; climbing the upper monument minarets requires navigating narrow, steep stone spiral stairs.',
      familySuitability: 'Colourful and exhilarating; keep hold of young children in dense bazaar shopping lanes.',
      photographyNotes: 'Breathtaking symmetrical framing through the Char Kaman gateway arches; night illumination against the dark sky.',
      nearbyCombinations: ['Mecca Masjid', 'Chowmahalla Palace', 'Nimrah Café & Bakery'],
      transitAdvice: 'Charminar Metro Station (Green Line) is 800m away; easily accessible via auto-rickshaw or TSRTC buses.',
      visitorTips: ['Sit at Nimrah Café directly opposite the monument for hot Irani chai paired with crumbly, salted Osmania biscuits.', 'Polite bargaining is expected for unbranded bangles and textiles in Laad Bazaar.'],
      officialLinks: [{ title: 'Telangana State Tourism Development Corporation — Charminar', url: 'https://tourism.telangana.gov.in' }],
      sourceNote: 'Archaeological Survey of India Hyderabad Circle & State Department of Archaeology.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Illuminated minarets and stone arches of Charminar in Hyderabad',
      imageCredit: 'Unsplash'
    },
    {
      id: 'hyd-golconda-fort',
      name: 'Golconda Fort (The Acoustic Citadel)',
      cityId: 'hyderabad',
      category: 'History & Heritage',
      shortSummary: 'Legendary 16th-century granite fortress renowned for its acoustic military engineering and diamond trade.',
      fullDescription: 'Rising dramatically 120 metres atop a solitary granite hill 11 km west of Hyderabad, Golconda was the fortified capital of the Qutb Shahi kingdom and the commercial diamond capital of the medieval world. Famous for its brilliant acoustic engineering, a handclap struck at the center of the outer entrance portico (Fateh Darwaza) travels through subterranean stone sound conduits and reverberates clearly at the Bala Hissar royal pavilion perched 400 feet above on the hillcrest, alerting sentries to potential surprise attacks. The massive 10-kilometre outer stone wall encloses eight monumental gates reinforced with iron elephant spikes, royal palaces, hydraulic water wheels that lifted mountain streams to high palace gardens, and the royal armouries.',
      historicalBackground: 'Originally a mud fort constructed by the Kakatiyas in the 13th century; massively fortified in stone by Qutb Shahi sultans between 1518 and 1687 until conquered by Mughal Emperor Aurangzeb after an eight-month siege.',
      culturalSignificance: 'The source of world-renowned diamonds mined in the nearby Krishna river valley, including the Koh-i-Noor, Daria-i-Noor, and Hope diamonds.',
      architecturalFeatures: 'Cyclopean granite masonry, acoustic vaults, multi-tiered defensive ramparts, hydraulic water-lifting conduits, and decorative peacock stucco motifs.',
      whyWorthVisiting: 'Experience the breathtaking military scale, test the acoustic clapping phenomenon yourself, and enjoy panoramic 360-degree views stretching to HITEC City.',
      whatToExperience: 'Clap beneath the Fateh Darwaza dome, climb the 380 stone steps past royal gardens to the Bala Hissar pavilion, inspect the subterranean prison of Bhakta Ramadasu, and attend the evening sound and light show.',
      location: 'Ibrahim Bagh, Golconda, Hyderabad 500008',
      coordinates: [17.3833, 78.4011],
      suggestedDuration: '3 to 3.5 hours',
      bestTimeToVisit: 'Early morning (8:00 AM – 10:30 AM) to climb the stairs before midday heat, or late afternoon for the sound and light show.',
      entryFeeInfo: '₹25 for Indian citizens, ₹300 for foreign visitors; evening Sound & Light Show ₹140 (English/Telugu/Hindi).',
      openingHoursInfo: 'Open daily: 8:30 AM – 5:30 PM; Sound & Light show operates seasonally from 6:30 PM.',
      accessibilityInfo: 'The lower courtyards are accessible via stone ramps, but the ascent to the top Bala Hissar involves climbing hundreds of steep, uneven stone stairs without elevator or handrails in parts.',
      familySuitability: 'Thrilling adventure for active families, photographers, and history buffs.',
      photographyNotes: 'Sunset over Hyderabad’s skyline framed through ancient stone battlements; monumental stone gate arches.',
      nearbyCombinations: ['Qutb Shahi Tombs (1 km away)', 'Taramati Baradari', 'Gandipet Lake'],
      transitAdvice: 'Easily reached via taxi or auto-rickshaw (11 km from city center). Dedicated car parking at the main gate.',
      visitorTips: ['Wear sturdy walking shoes with rubber soles for climbing the smooth, worn granite steps.', 'Hire an accredited ASI guide at the ticket window to demonstrate the acoustic secrets.'],
      officialLinks: [{ title: 'ASI Hyderabad Circle — Golconda Fort', url: 'https://asiregionhyd.gov.in' }],
      sourceNote: 'Archaeological Survey of India & Telangana State Archaeology Department.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Ancient granite stone bastions and ramparts of Golconda Fort',
      imageCredit: 'Unsplash'
    },
    {
      id: 'hyd-chowmahalla',
      name: 'Chowmahalla Palace',
      cityId: 'hyderabad',
      category: 'Architecture',
      shortSummary: 'The 18th-century royal palace of the Nizams of Hyderabad, modeled on the Shah of Iran’s palace in Tehran.',
      fullDescription: 'Commenced in 1750 by Nizam Salabat Jung and completed under Nizam Afzar-ud-Daulah in 1869, Chowmahalla (meaning "Four Palaces") was the official seat of the Asaf Jahi dynasty, where the Nizams entertained visiting viceroys and European royalty. Spanning twelve tranquil acres behind Charminar, the palace synthesizes Persian, Neo-classical, and Indo-Saracenic architectural styles. The centerpiece is the Khilwat Mubarak (Grand Durbar Hall): a palatial marble hall crowned by 19 colossal Belgian crystal chandeliers, where the pure marble Takht-e-Nishan (royal throne) stands in dignified quietude. The outer courtyards feature tranquil fountains, lush gardens, and a remarkable vintage automobile gallery housing the 1912 yellow Rolls-Royce Silver Ghost owned by the 7th Nizam, Mir Osman Ali Khan.',
      historicalBackground: 'Restored over five years under the patronage of Princess Esra Jah and awarded the prestigious UNESCO Asia-Pacific Heritage Award for Cultural Heritage Conservation in 2010.',
      culturalSignificance: 'The supreme surviving monument to the legendary wealth, court etiquette, and cosmopolitan taste of the Nizams of Hyderabad.',
      architecturalFeatures: 'Neoclassical Corinthian colonnades, Persian domes, intricate lime-stucco ceilings, Belgian cut-crystal chandeliers, and historic clock towers.',
      whyWorthVisiting: 'Experience the regal elegance of the world’s wealthiest royal court, preserved with pristine museum standards away from urban noise.',
      whatToExperience: 'Marvel at the 19 glittering chandeliers inside the Khilwat Mubarak, view the royal collection of vintage armaments and porcelain, inspect the 1912 Rolls-Royce Silver Ghost, and walk through the tranquil southern courtyard.',
      location: '20-4-236, Motigalli, Khilwat, Hyderabad 500002',
      coordinates: [17.3578, 78.4717],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Morning or early afternoon (10:00 AM – 1:00 PM).',
      entryFeeInfo: '₹100 for Indian citizens, ₹400 for foreign visitors; camera pass ₹100.',
      openingHoursInfo: 'Saturday to Thursday: 10:00 AM – 5:00 PM. Closed Fridays and National Holidays.',
      accessibilityInfo: 'Level stone pathways across the gardens; gentle ramps provide step-free access into the Khilwat Mubarak durbar hall.',
      familySuitability: 'Excellent for families, royal heritage admirers, and architecture enthusiasts.',
      photographyNotes: 'Non-flash photography allowed; the reflection of chandeliers in the polished marble durbar floor is spectacular.',
      nearbyCombinations: ['Charminar', 'Laad Bazaar', 'Salar Jung Museum'],
      transitAdvice: 'Located 1 km south-west of Charminar. An easy 10-minute walk through the heritage bazaar or short auto-rickshaw ride.',
      visitorTips: ['Plan at least two hours to properly explore the royal textile gallery and vintage carriage pavilion.', 'Pick up certified books on Hyderabadi court history at the palace souvenir boutique.'],
      officialLinks: [{ title: 'Chowmahalla Palace Official Trust', url: 'https://chowmahalla.org' }],
      sourceNote: 'UNESCO Asia-Pacific Heritage Documentation & Asaf Jahi Dynasty Archives.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Neoclassical marble colonnade and fountains of Chowmahalla Palace',
      imageCredit: 'Unsplash'
    },
    {
      id: 'hyd-salar-jung',
      name: 'Salar Jung Museum',
      cityId: 'hyderabad',
      category: 'Art & Museums',
      shortSummary: 'One of the world’s largest one-man art collections, containing 40,000 global antiquities and the Veiled Rebecca.',
      fullDescription: 'Situated along the southern bank of the Musi river, the Salar Jung Museum houses the extraordinary private treasury amassed by Mir Yousuf Ali Khan (Salar Jung III), who served as the Prime Minister of the 7th Nizam. Spending a substantial portion of his personal royal income over thirty-five years, Salar Jung collected more than 40,000 antiquities, 8,000 rare manuscripts, and 50,000 books spanning Europe, Persia, the Far East, and India. Foremost among the masterpieces is the mesmerizing 1876 marble sculpture "Veiled Rebecca" by Italian master Giovanni Maria Benzoni: a breathtaking tour de force where the stone appears miraculously transformed into sheer, translucent flowing fabric. Other highlights include the Mephistopheles and Margaretta double-faced wooden statue, jade daggers belonging to Mughal Emperor Jahangir and Empress Noor Jahan, and the famous 19th-century musical bracket clock with mechanical toy figures.',
      historicalBackground: 'Opened to the public in 1951 at Diwan Deodi; relocated to its present grand purpose-built museum edifice on the Musi river in 1968. Declared an Institution of National Importance by an Act of Parliament in 1961.',
      culturalSignificance: 'One of India’s three National Museums, demonstrating how Indian nobility engaged with global connoisseurship.',
      architecturalFeatures: 'Monumental modern museum campus with 38 specialised galleries, high vaulted exhibition halls, and climate-controlled textile vaults.',
      whyWorthVisiting: 'Experience the astonishing breadth of human artistic craft across four continents collected by a single visionary collector.',
      whatToExperience: 'Stand in awe before the Veiled Rebecca, gather in the central atrium at the top of the hour to watch the 19th-century mechanical clock strike, inspect Tipu Sultan’s royal wardrobe, and admire Chinese celadon ceramics.',
      location: 'Salar Jung Marg, Darulshifa, Hyderabad 500002',
      coordinates: [17.3713, 78.4804],
      suggestedDuration: '2.5 to 3 hours',
      bestTimeToVisit: 'Morning hours (10:00 AM – 1:00 PM) on weekdays to avoid school tour crowds.',
      entryFeeInfo: '₹50 for Indian citizens, ₹500 for foreign visitors; children under 18 free with student ID.',
      openingHoursInfo: 'Saturday to Thursday: 10:00 AM – 5:00 PM. Closed Fridays and National Holidays.',
      accessibilityInfo: 'Fully equipped with elevators, level corridors, ramps, and wheelchairs available at the entrance reception.',
      familySuitability: 'Profoundly engaging for students, collectors, and families; children adore the mechanical clock.',
      photographyNotes: 'Camera pass can be purchased at the ticket counter; no flash or tripod allowed in art galleries.',
      nearbyCombinations: ['High Court of Telangana heritage building', 'City College building', 'Charminar'],
      transitAdvice: 'MGBS (Mahatma Gandhi Bus Station) Metro Station is an 800m walk across the Musi river bridge.',
      visitorTips: ['Plan to be in the central clock gallery five minutes before any hour to watch the mechanical timekeeper emerge from his niche.', 'Audio guides in English and Hindi are highly recommended.'],
      officialLinks: [{ title: 'Salar Jung Museum Official Portal', url: 'https://salarjungmuseum.gov.in' }],
      sourceNote: 'Ministry of Culture, Government of India & Salar Jung Museum Board.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Sculptures and classical artwork displayed in Salar Jung Museum gallery',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1518 – 1687 CE',
      title: 'Qutb Shahi Sultanate of Golconda',
      description: 'The Turkmen Qutb Shahi rulers build the massive stone citadel of Golconda, trade diamonds globally, and found the planned garden metropolis of Hyderabad in 1591.',
      keySites: ['Golconda Fort', 'Charminar', 'Qutb Shahi Tombs', 'Mecca Masjid']
    },
    {
      epoch: '1724 – 1948 CE',
      title: 'The Asaf Jahi Nizams of Hyderabad',
      description: 'Nizam-ul-Mulk establishes the sovereign state of Hyderabad, creating India’s wealthiest princely realm with lavish French-style palaces, modern railways, and Osman Sagar lake systems.',
      keySites: ['Chowmahalla Palace', 'Falaknuma Palace', 'Osmania University Arts College']
    },
    {
      epoch: 'Post-1990s',
      title: 'HITEC City & Cyberabad Evolution',
      description: 'Hyderabad emerges as a global powerhouse of biotechnology and software engineering, seamlessly connecting its 400-year-old culinary traditions with cutting-edge global innovation.',
      keySites: ['HITEC City Cyber Towers', 'T-Hub', 'Durgam Cheruvu Cable Bridge']
    }
  ],

  architecturalHeritageOverview: 'Hyderabad’s architecture is defined by rough-hewn Deccan pink and grey granite blocks juxtaposed against delicate stucco plasterwork featuring pineapple, lotus, and urn motifs under the Qutb Shahis, followed by neoclassical European porticos and Italianate marble arcades under the Nizams.',

  traditionsAndFestivals: [
    {
      title: 'Ramadan Night Bazaars & Haleem Season',
      seasonOrFrequency: 'Holy month of Ramadan (lunar calendar, 30 days)',
      description: 'During Ramadan, the Old City around Charminar turns into an illuminated 24-hour festival. Massive wood-fired cauldrons (bhattis) simmer all day across the city, preparing Hyderabadi Haleem—a velvety stew of pounded meat, broken wheat, lentils, and ghee.',
      visitorEtiquette: 'Experience the electric, joyful midnight atmosphere around Charminar; sample haleem at renowned culinary institutions.'
    },
    {
      title: 'Bonalu Folk Festival',
      seasonOrFrequency: 'Ashada month (July – August, Sundays)',
      description: 'An ancient Telangana folk festival dedicated to Goddess Mahakali. Women carry brass pots decorated with neem leaves and turmeric on their heads as offerings (bonam), accompanied by intense rhythmic drumming and the ferocious Pothuraju whip dancers.',
      visitorEtiquette: 'Witness the colorful village procession at Golconda Fort with festive community spirit.'
    }
  ],

  dishes: [
    {
      id: 'hyd-dum-biryani',
      name: 'Kacchi Gosht Ki Dum Biryani',
      localName: 'कच्ची गोश्त की हैदराबादी दम बिरयानी',
      culturalOrigin: 'Born in the royal royal kitchens of the Nizams, synthesizing Mughal court cooking with fiery Andhra spices.',
      description: 'The pinnacle of subcontinental rice cookery. Tender raw goat meat (gosht) is marinated overnight in yogurt, papaya paste, green chillies, ginger-garlic, mint, and fried onions (birista). Layered in a heavy copper deg with partially cooked fragrant aged basmati rice, drizzled with saffron milk and pure ghee, and sealed airtight with dough to slow-cook entirely in its own steam over gentle charcoal embers (dum).',
      typicalIngredients: ['Tender raw mutton', 'Aged basmati rice', 'Raw papaya tenderizer', 'Saffron milk', 'Pudina (mint) & coriander', 'Mirchi ka salan (accompanying pepper gravy)'],
      isVeg: false,
      whereToFind: 'Bawarchi (RTC X Roads), Shadab (Near Madina, Old City), Paradise (Secunderabad original branch), Cafe Bahar (Hyderguda).',
      priceCategory: 'Moderate',
      dietaryAdvice: 'Non-vegetarian. Fragrant, rich, and deeply spiced. Accompanied by mirchi ka salan (tangy peanut-sesame chilli curry) and dahi ki chutney (onion-mint raita).',
      etiquetteTips: 'Gently fluff the rice from the side of the plate with a spoon to reveal the aromatic gradation from white to yellow to spiced orange rice.',
      image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'hyd-irani-chai-osmania',
      name: 'Hyderabadi Irani Chai & Osmania Biscuits',
      localName: 'इराणी चहा आणि उस्मानिया बिस्किटे',
      culturalOrigin: 'Zoroastrian and Persian merchants who established community corners in early 20th-century Hyderabad.',
      description: 'A velvety, sweet tea brewed in a sealed copper samovar. Condensed, slow-simmered milk is cooked separately until thickened, then poured over a concentrated dark tea decoction (khash) directly into glass cups. Served alongside Osmania biscuits: crumbly, golden-baked buttery shortbread with a distinctive hint of sweet cardamom and salt, originally named in honor of the 7th Nizam Mir Osman Ali Khan.',
      typicalIngredients: ['Strong black tea decoction', 'Full-cream evaporated milk', 'Sugar', 'Osmania salted shortbread biscuits'],
      isVeg: true,
      whereToFind: 'Nimrah Café & Bakery (opposite Charminar), Niloufer Café (Lakdikapul), Grand Hotel (Abids).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian. Rich, milky, and comforting.',
      etiquetteTips: 'Dip the Osmania biscuit lightly into the hot Irani chai for exactly two seconds before biting.',
      image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Old City: Charminar & Madina',
      character: 'Densely packed historic culinary district famous for biryani, kebabs, nihari, and Irani bakeries.',
      bestTime: 'Evening 6:30 PM until late midnight.',
      highlights: ['Mutton biryani at Hotel Shadab', 'Irani chai at Nimrah Café', 'Pathar ka gosht (stone-grilled meat)'],
      visitorAdvice: 'The area around Charminar is pedestrianized; arrive via metro or auto-rickshaw to avoid traffic.'
    },
    {
      name: 'Banjara Hills & Jubilee Hills',
      character: 'Upscale modern dining enclave featuring contemporary Deccan restaurants, luxury lounges, and heritage sweet shops.',
      bestTime: 'Lunch (12:30 PM – 3:30 PM) and Dinner (7:30 PM – 11:00 PM).',
      highlights: ['Artisanal Hyderabadi dishes at Jewel of Nizam', 'Rayalaseema spice cuisine', 'Specialty craft coffee roasteries'],
      visitorAdvice: 'Reservations recommended for dinner at fine-dining institutions.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Hyderabad is widely recognized for its warm Deccan hospitality and low violent crime rates.',
      'Summer temperatures in April and May routinely surpass 42°C; explore forts and open monuments early in the morning and carry electrolytes.',
      'In crowded markets like Laad Bazaar and Begum Bazaar, keep phones and bags close to avoid opportunistic pickpocketing.'
    ],
    transportPedestrian: [
      'Hyderabad Metro (Red, Blue, and Green lines) is clean, air-conditioned, and connects Old City, Secunderabad, and HITEC City seamlessly.',
      'Auto-rickshaws frequently refuse electronic meters; book via app-based aggregators (Ola, Uber, Rapido) or use pre-paid stands at railway stations.',
      'Arterial roads in HITEC City and Banjara Hills carry fast traffic; use designated pedestrian overbridges (foot over bridges).'
    ],
    nightTravel: [
      'Banjara Hills, Jubilee Hills, and HITEC City have vibrant night activity and are well-patrolled by police.',
      'Old City areas around Charminar remain lively with shoppers and diners until past midnight.'
    ],
    accessibilityNotes: [
      'Hyderabad Metro stations are modern and step-free with braille buttons, lifts, and wide ticket gates.',
      'Chowmahalla Palace and Salar Jung Museum offer good level access and wheelchair availability, whereas Golconda Fort involves strenuous stone stair climbs.'
    ],
    emergencyContacts: [
      { title: 'Hyderabad Police Emergency Response', number: '112', note: 'Unified 24/7 emergency dispatch' },
      { title: 'SHE Teams Women Safety Helpline', number: '94906 16555', note: 'Dedicated Telangana Police women safety squad' },
      { title: 'Ambulance Medical Emergency', number: '108', note: 'Telangana Emergency Medical Service' },
      { title: 'Osmania General Hospital Emergency', number: '040 2460 0146', note: 'Historic government tertiary medical center' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Hyderabad City Police notifications and Telangana State Tourism Development Corporation reports.'
  },

  neighbourhoods: [
    {
      id: 'hyd-old-city',
      name: 'Old City & Charminar Precinct',
      cityId: 'hyderabad',
      character: 'The historic 16th-century Qutb Shahi heart, filled with grand palaces, stone minarets, pearl markets, and century-old biryani institutions.',
      budgetTier: 'Budget-friendly',
      transitScore: 'Very High (Charminar & MGBS Metro stations, extensive bus terminal)',
      transitDetails: 'Direct Metro connection; walking and cycle-rickshaws through the inner bazaar lanes.',
      walkabilityRating: 'High around the Charminar pedestrianized plaza; side bazaars are lively and crowded.',
      accessibilityNotes: 'Charminar plaza is paved and flat; historic palaces offer ramped entries.',
      heritageHighlights: ['Charminar', 'Chowmahalla Palace', 'Mecca Masjid', 'Salar Jung Museum'],
      foodHighlights: ['Hotel Shadab', 'Nimrah Café', 'Nayab Hotel'],
      greenSpaceNotes: 'Chowmahalla Palace gardens and riverside riverfront promenades.',
      safetyContext: 'High social safety due to constant merchant and family presence until late at night.',
      methodologyNote: 'Evaluated using urban heritage conservation surveys and pedestrian density audits.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'hyd-banjara-hills',
      name: 'Banjara Hills & Jubilee Hills',
      cityId: 'hyderabad',
      character: 'Leafy, undulating residential and lifestyle enclave featuring granite rock formations, design boutiques, luxury dining, and serene lakes.',
      budgetTier: 'Upscale / High-end',
      transitScore: 'High (Road #5 and Jubilee Hills Check Post metro stations on the Blue Line)',
      transitDetails: 'Direct Blue Line Metro access; wide roads and plentiful app cabs.',
      walkabilityRating: 'Moderate (Hilly topography with winding avenues; good sidewalks along main commercial roads).',
      accessibilityNotes: 'Modern restaurants and shopping galleries feature ramped street access.',
      heritageHighlights: ['Lotus Pond', 'KBR National Park', 'Durgam Cheruvu Secret Lake'],
      foodHighlights: ['Jewel of Nizam', 'Rayalaseema Ruchulu', 'Specialty third-wave cafes'],
      greenSpaceNotes: 'Kasu Brahmananda Reddy (KBR) National Park offers 390 acres of protected jungle habitat in the heart of the city.',
      safetyContext: 'One of the most affluent and well-patrolled districts in the state.',
      methodologyNote: 'Calculated from lifestyle amenity density and urban green-canopy surveys.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-hyd-golconda-diamonds',
      cityId: 'hyderabad',
      title: 'The Diamond Fortress: When Golconda Ruled the World’s Jewels',
      preview: 'Why every legendary diamond in world history—from the Koh-i-Noor to the Hope Diamond—flowed through this single Deccan fortress.',
      fullArticle: 'Until the discovery of diamonds in Brazil in the 1720s, India was the only known commercial source of diamonds on Earth. And the epicenter of that global gem empire was Golconda. Mined in the alluvial gravels of the Krishna and Godavari river basins at locations like Kollur, rough stones were brought under armed guard into the fortified vaults of Golconda Fort, where royal lapidaries graded, cut, and polished them for global trade. Golconda diamonds were prized for their legendary "Type IIa" chemical purity—completely free of nitrogen impurities, resulting in an extraordinary water-like transparency and limpid brilliance. It was here that the Koh-i-Noor, the Hope Diamond (which once adorned French royal crowns), the Daria-i-Noor, and the Regent Diamond were cut and traded. To this day, the term "Golconda Diamond" remains the gold standard in gemology, denoting stones of peerless, celestial clarity.',
      locationName: 'Golconda Fort & Karwan Bazaars',
      factualExplanation: 'Documented in Jean-Baptiste Tavernier’s 1676 travelogue Travels in India and Geological Survey of India records.',
      sources: ['Travels in India by Jean-Baptiste Tavernier', 'The Jewels of the Nizams by Usha Balakrishnan'],
      relatedDestinationIds: ['hyd-golconda-fort', 'hyd-chowmahalla'],
      readTimeMinutes: 4,
      image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Stone fortress walls and vaults of Golconda Fort'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '15°C – 29°C', advice: 'Pleasant and sunny; cool evenings. The best time for climbing Golconda Fort and exploring the Old City.' },
      { season: 'Monsoon (Jul – Sep)', temperatureRange: '23°C – 31°C', advice: 'Moderate showers; granite rock formations turn picturesque and lakes fill up.' },
      { season: 'Summer (Mar – May)', temperatureRange: '26°C – 42°C', advice: 'Intense Deccan heat; plan outdoor heritage explorations before 10:00 AM or after 5:30 PM.' }
    ],
    transportInfrastructure: [
      { mode: 'Hyderabad Metro Rail', coverage: 'Red (Miyapur-LB Nagar), Blue (Nagole-Raidurg), Green (JBS-MGBS)', tip: 'World-class, elevated, air-conditioned; connects Old City to HITEC City with speed.' },
      { mode: 'App Cabs & Autos', coverage: 'Full city coverage', tip: 'Uber, Ola, and Rapido are widely used and reliably priced.' },
      { mode: 'Pushpak Airport Liners (TSRTC)', coverage: 'Direct luxury AC buses connecting Rajiv Gandhi International Airport (RGIA) to all major city zones', tip: 'Cost-effective, reliable, and luggage-friendly.' }
    ],
    environmentalNotes: 'Hyderabad’s granite geological landscape provides natural rock-garden buffers. The Musi River Clean-Up Project and urban lake rehabilitation efforts (Durgam Cheruvu, Hussain Sagar) are active municipal priorities.',
    dataAttribution: 'Telangana State Tourism Development Corporation & Greater Hyderabad Municipal Corporation'
  }
};
