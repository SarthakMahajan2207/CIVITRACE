import React, { useState } from 'react';
import {
  Compass,
  MapPin,
  Search,
  Bookmark,
  Sparkles,
  Menu,
  X,
  ChevronDown,
  ShieldCheck,
  Columns,
  BookOpen,
  Map as MapIcon,
  UtensilsCrossed,
  Landmark,
  BarChart3
} from 'lucide-react';
import { City } from '../types';

interface NavbarProps {
  currentCity: City;
  onSelectCityClick: () => void;
  onOpenSearch: () => void;
  onOpenSaved: () => void;
  onOpenPulseAi: () => void;
  savedCount: number;
  activeSection: string;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentCity,
  onSelectCityClick,
  onOpenSearch,
  onOpenSaved,
  onOpenPulseAi,
  savedCount,
  activeSection,
  onNavigateSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'explore', label: 'Explore', icon: Compass },
    { id: 'heritage', label: 'Heritage', icon: Landmark },
    { id: 'food', label: 'Food & Life', icon: UtensilsCrossed },
    { id: 'safety', label: 'Safety', icon: ShieldCheck },
    { id: 'compare', label: 'Compare', icon: Columns },
    { id: 'insights', label: 'Insights', icon: BarChart3 },
    { id: 'stories', label: 'Stories', icon: BookOpen },
    { id: 'map', label: 'Map', icon: MapIcon },
  ];

  const handleNavClick = (id: string) => {
    onNavigateSection(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0a0e17]/90 backdrop-blur-md border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Brand Wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('hero')}
              className="group text-left flex items-center gap-2.5 focus:outline-none"
            >
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-600 to-teal-700 flex items-center justify-center shadow-md shadow-amber-950/40 border border-amber-500/30">
                <Compass className="w-5 h-5 text-amber-100 group-hover:rotate-45 transition-transform duration-300" />
              </div>
              <div>
                <span className="font-cinzel text-xl sm:text-2xl font-bold tracking-wider text-[#f4efe6] block leading-none">
                  CIVITRACE
                </span>
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-sans block mt-0.5">
                  See Beyond the Streets
                </span>
              </div>
            </button>

            {/* City Selector Pill */}
            <button
              onClick={onSelectCityClick}
              className="ml-2 sm:ml-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 hover:border-amber-500/50 hover:bg-slate-850 text-slate-200 transition-all text-xs sm:text-sm font-medium shadow-sm group"
              title="Change active city"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
              <span className="font-medium text-amber-100">{currentCity.name}</span>
              <span className="text-[11px] text-slate-400 hidden md:inline">({currentCity.state})</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-300 transition-colors" />
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1 2xl:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs lg:text-sm font-medium transition-all ${
                    isActive
                      ? 'text-amber-300 bg-amber-500/10 border border-amber-500/30 shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Global Search Button */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-600 text-xs sm:text-sm transition-all shadow-xs"
              aria-label="Search places and stories"
            >
              <Search className="w-4 h-4 text-slate-400" />
              <span className="hidden sm:inline text-slate-300">Search</span>
              <kbd className="hidden lg:inline px-1.5 py-0.5 text-[10px] font-mono bg-slate-800 border border-slate-700 text-slate-400 rounded">
                ⌘K
              </kbd>
            </button>

            {/* Saved Bookmarks */}
            <button
              onClick={onOpenSaved}
              className="relative p-2 rounded-lg bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-600 transition-all shadow-xs"
              title="Saved places"
              aria-label="View saved places"
            >
              <Bookmark className="w-4 h-4 text-amber-400" />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-600 text-amber-50 text-[10px] font-bold flex items-center justify-center ring-2 ring-[#0a0e17]">
                  {savedCount}
                </span>
              )}
            </button>

            {/* Pulse AI Trigger */}
            <button
              onClick={onOpenPulseAi}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-teal-700/90 to-amber-700/90 hover:from-teal-600 hover:to-amber-600 text-white text-xs sm:text-sm font-medium border border-teal-500/40 shadow-sm shadow-teal-950/40 transition-all hover:scale-[1.02] active:scale-[0.98]"
              title="Open Pulse AI City Guide"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-200 animate-pulse" />
              <span>Pulse AI</span>
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-800 bg-[#0a0e17] px-4 pt-3 pb-5 space-y-1 shadow-2xl animate-in slide-in-from-top-2 duration-200">
          <div className="pb-2 mb-2 border-b border-slate-800/80 flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Exploring {currentCity.name}
            </span>
            <button
              onClick={() => {
                onSelectCityClick();
                setMobileMenuOpen(false);
              }}
              className="text-xs text-amber-400 hover:underline flex items-center gap-1"
            >
              <MapPin className="w-3 h-3" /> Change City
            </button>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'text-amber-300 bg-amber-500/15 border border-amber-500/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-850'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
