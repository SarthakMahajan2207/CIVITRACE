import React, { useState, useEffect } from 'react';
import { Search, X, MapPin, Compass, BookOpen, UtensilsCrossed, ArrowRight } from 'lucide-react';
import { searchGlobal, SearchResultItem } from '../data/cities';
import { City, Destination } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (item: SearchResultItem) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectResult,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResultItem[]>([]);

  useEffect(() => {
    if (query.trim()) {
      setResults(searchGlobal(query));
    } else {
      setResults([]);
    }
  }, [query]);

  // Keyboard shortcut for ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const getTypeIcon = (type: SearchResultItem['type']) => {
    switch (type) {
      case 'city':
        return <MapPin className="w-4 h-4 text-amber-400" />;
      case 'destination':
        return <Compass className="w-4 h-4 text-teal-400" />;
      case 'story':
        return <BookOpen className="w-4 h-4 text-indigo-400" />;
      case 'dish':
        return <UtensilsCrossed className="w-4 h-4 text-rose-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 pt-16 sm:pt-24 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Search Container */}
      <div className="relative w-full max-w-2xl bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3 bg-slate-900">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search across all 12 cities, monuments, dishes, or stories..."
            className="flex-1 bg-transparent text-white placeholder-slate-400 text-sm sm:text-base focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2 py-1 text-xs rounded bg-slate-800 text-slate-400 hover:text-white"
          >
            ESC
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-1">
          {query.trim() === '' ? (
            <div className="p-6 text-center text-slate-500 text-xs">
              <span className="block mb-2 font-medium text-slate-400">Search suggestions:</span>
              <div className="flex flex-wrap justify-center gap-2">
                {['Shaniwar Wada', 'Marine Drive', 'Lalbagh', 'Qutb Minar', 'Hawa Mahal', 'Fontainhas', 'Misal Pav', 'Dum Biryani'].map((item) => (
                  <button
                    key={item}
                    onClick={() => setQuery(item)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-200 transition-colors"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length > 0 ? (
            results.map((item) => (
              <div
                key={`${item.type}-${item.id}`}
                onClick={() => {
                  onSelectResult(item);
                  onClose();
                }}
                className="p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-all flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center shrink-0">
                    {getTypeIcon(item.type)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-white group-hover:text-amber-300 transition-colors truncate">
                      {item.title}
                    </h4>
                    <span className="text-xs text-slate-400 block truncate">
                      {item.subtitle}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 text-xs text-slate-500 group-hover:text-amber-400 transition-colors">
                  <span className="capitalize">{item.type}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-slate-400">
              <p className="text-sm">No results found for "{query}"</p>
              <p className="text-xs text-slate-500 mt-1">Try another landmark or regional dish name.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between px-4">
          <span>Global Search across 12 Indian cultural capitals</span>
          <span>Press ESC to exit</span>
        </div>
      </div>
    </div>
  );
};
