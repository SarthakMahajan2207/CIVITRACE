import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  MapPin,
  Navigation,
  Compass,
  Filter,
  Layers,
  ExternalLink,
  Locate,
  Route,
  ArrowRight,
  Info
} from 'lucide-react';
import { City, Destination, CategoryType } from '../types';

interface InteractiveMapProps {
  city: City;
  onOpenDestination: (destination: Destination) => void;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  city,
  onOpenDestination,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.Polyline | null>(null);

  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('All');
  const [activeDestination, setActiveDestination] = useState<Destination | null>(null);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [routeOriginId, setRouteOriginId] = useState<string>('');
  const [routeDestId, setRouteDestId] = useState<string>('');
  const [routeInfo, setRouteInfo] = useState<{ distanceKm: number; estWalkMinutes: number } | null>(null);
  const [locatingUser, setLocatingUser] = useState(false);

  const categories: CategoryType[] = [
    'All',
    'History & Heritage',
    'Architecture',
    'Nature & Outdoors',
    'Local Food & Markets',
    'Art & Museums',
    'Spiritual & Sacred'
  ];

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    const map = L.map(mapContainerRef.current, {
      center: city.coordinates,
      zoom: 12,
      zoomControl: true,
      attributionControl: true,
    });

    // Dark high-contrast OpenStreetMap CartoDB Tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, [city.id]);

  // Update Markers based on Category Filter
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();

    const filtered = city.destinations.filter(
      (d) => selectedCategory === 'All' || d.category === selectedCategory
    );

    const customIcon = L.divIcon({
      className: 'civitrace-custom-pin',
      html: `<div style="
        background: #d97706;
        color: #fff;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid #ffffff;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        cursor: pointer;
      ">
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>
      </div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 28],
      popupAnchor: [0, -28],
    });

    filtered.forEach((dest) => {
      const marker = L.marker(dest.coordinates, { icon: customIcon });

      marker.on('click', () => {
        setActiveDestination(dest);
      });

      marker.bindPopup(`
        <div style="font-family: inherit; padding: 4px; max-width: 220px;">
          <h4 style="font-weight: 700; color: #fff; margin: 0 0 4px 0; font-size: 14px;">${dest.name}</h4>
          <p style="color: #cbd5e1; font-size: 11px; margin: 0 0 6px 0; line-height: 1.4;">${dest.shortSummary}</p>
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: #fbbf24;">
            <span>${dest.category}</span>
            <span>${dest.suggestedDuration}</span>
          </div>
        </div>
      `);

      layer.addLayer(marker);
    });

    // If active destination exists, center map on it
    if (activeDestination) {
      map.panTo(activeDestination.coordinates);
    }
  }, [city, selectedCategory, activeDestination]);

  // Handle Route Calculation
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (routeLayerRef.current) {
      map.removeLayer(routeLayerRef.current);
      routeLayerRef.current = null;
    }

    if (!routeOriginId || !routeDestId || routeOriginId === routeDestId) {
      setRouteInfo(null);
      return;
    }

    const origin = city.destinations.find((d) => d.id === routeOriginId);
    const dest = city.destinations.find((d) => d.id === routeDestId);

    if (!origin || !dest) return;

    // Draw geodesic preview line
    const polyline = L.polyline([origin.coordinates, dest.coordinates], {
      color: '#38bdf8',
      weight: 4,
      dashArray: '8, 8',
      opacity: 0.85,
    }).addTo(map);

    routeLayerRef.current = polyline;
    map.fitBounds(polyline.getBounds(), { padding: [40, 40] });

    // Calculate approximate distance
    const distMeters = map.distance(origin.coordinates, dest.coordinates);
    const distKm = distMeters / 1000;
    // Estimate average walking time (approx 4.5 km/h walking speed)
    const estMinutes = Math.round((distKm / 4.5) * 60);

    setRouteInfo({
      distanceKm: parseFloat(distKm.toFixed(2)),
      estWalkMinutes: estMinutes,
    });
  }, [routeOriginId, routeDestId, city]);

  const handleLocateUser = () => {
    if (!navigator.geolocation) return;
    setLocatingUser(true);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords: [number, number] = [pos.coords.latitude, pos.coords.longitude];
        setUserLocation(coords);
        setLocatingUser(false);

        const map = mapInstanceRef.current;
        if (map) {
          map.setView(coords, 14);

          const userPin = L.divIcon({
            className: 'user-location-pin',
            html: `<div style="
              background: #0284c7;
              width: 16px;
              height: 16px;
              border-radius: 50%;
              border: 3px solid #ffffff;
              box-shadow: 0 0 12px #38bdf8;
            "></div>`,
            iconSize: [16, 16],
            iconAnchor: [8, 8],
          });

          L.marker(coords, { icon: userPin }).addTo(map).bindPopup('Your Current Position').openPopup();
        }
      },
      () => {
        setLocatingUser(false);
      },
      { timeout: 8000 }
    );
  };

  return (
    <section id="map" className="py-16 sm:py-24 bg-[#0a0e17] border-t border-slate-800/80 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
              <Compass className="w-4 h-4" />
              <span>Geospatial Exploration</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-bold text-white tracking-tight">
              Interactive Cultural Map of {city.name}
            </h2>
            <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-2xl leading-relaxed">
              Explore destinations across {city.name} using real street tiles, inspect coordinates, view nearby cultural nodes, and plan itinerary walks.
            </p>
          </div>

          {/* User Location Button */}
          <button
            onClick={handleLocateUser}
            disabled={locatingUser}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-sky-400 text-slate-200 hover:text-white text-xs font-medium transition-all shadow-md self-start md:self-auto"
          >
            <Locate className="w-4 h-4 text-sky-400" />
            <span>{locatingUser ? 'Finding location...' : 'Show My Position'}</span>
          </button>
        </div>

        {/* Category Filters Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-4 scrollbar-none text-xs">
          <span className="text-slate-400 font-semibold mr-1 shrink-0 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Filter Markers:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-amber-600 text-amber-50 border border-amber-500 shadow-xs'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Main Map & Route Control Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Leaflet Map Canvas (2 cols) */}
          <div className="lg:col-span-2 relative h-[500px] sm:h-[580px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
            <div ref={mapContainerRef} className="w-full h-full" />

            {/* In-Map Active Destination Banner */}
            {activeDestination && (
              <div className="absolute bottom-4 left-4 right-4 z-[1000] p-4 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-2xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200">
                <div className="min-w-0">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block mb-0.5">
                    Selected Node • {activeDestination.category}
                  </span>
                  <h4 className="text-sm sm:text-base font-editorial font-bold text-white truncate">
                    {activeDestination.name}
                  </h4>
                  <p className="text-xs text-slate-400 truncate mt-0.5">
                    {activeDestination.location}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onOpenDestination(activeDestination)}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow-md transition-all"
                  >
                    View Dossier
                  </button>
                  <button
                    onClick={() => setActiveDestination(null)}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
                  >
                    ×
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Route Planning & Nearby Node Sidebar (1 col) */}
          <div className="space-y-6">
            {/* Route Planning Widget */}
            <div className="p-5 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-400">
                <Route className="w-4 h-4" />
                <span>Geodesic Route Planner</span>
              </div>
              <h3 className="text-lg font-editorial font-bold text-white">
                Calculate Itinerary Distance
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Starting Discovery (A):</label>
                  <select
                    value={routeOriginId}
                    onChange={(e) => setRouteOriginId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                  >
                    <option value="">Select departure place...</option>
                    {city.destinations.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.category})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Destination Discovery (B):</label>
                  <select
                    value={routeDestId}
                    onChange={(e) => setRouteDestId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                  >
                    <option value="">Select destination place...</option>
                    {city.destinations.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.category})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {routeInfo && (
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-sky-500/30 space-y-2 text-xs animate-in fade-in">
                  <div className="flex items-center justify-between text-slate-300">
                    <span>Direct Air Distance:</span>
                    <strong className="text-sky-300 font-mono text-sm">{routeInfo.distanceKm} km</strong>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span>Approx. Walking Time:</span>
                    <strong className="text-amber-300 font-mono text-sm">~{routeInfo.estWalkMinutes} mins</strong>
                  </div>
                  <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-850">
                    Straight-line path shown. Street walking duration accounts for historic pedestrian lanes.
                  </p>

                  <a
                    href={`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(
                      city.destinations.find((d) => d.id === routeOriginId)?.name || ''
                    )}&destination=${encodeURIComponent(
                      city.destinations.find((d) => d.id === routeDestId)?.name || ''
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full mt-2 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>Open Turn-by-Turn Navigation</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>

            {/* Quick Destination Directory in Sidebar */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl max-h-72 overflow-y-auto">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Visible Cultural Nodes ({city.destinations.length})
              </h4>
              <div className="space-y-2">
                {city.destinations.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => {
                      setActiveDestination(d);
                      if (mapInstanceRef.current) {
                        mapInstanceRef.current.setView(d.coordinates, 15);
                      }
                    }}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-950/60 hover:bg-slate-800 border border-slate-850 hover:border-amber-500/40 text-xs transition-colors flex items-center justify-between"
                  >
                    <div>
                      <span className="font-semibold text-white block">{d.name}</span>
                      <span className="text-[10px] text-slate-400">{d.category}</span>
                    </div>
                    <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
