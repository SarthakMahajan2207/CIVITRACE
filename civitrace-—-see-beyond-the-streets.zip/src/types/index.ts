export type CategoryType =
  | 'All'
  | 'History & Heritage'
  | 'Architecture'
  | 'Nature & Outdoors'
  | 'Local Food & Markets'
  | 'Art & Museums'
  | 'Spiritual & Sacred'
  | 'Photography';

export interface Destination {
  id: string;
  name: string;
  cityId: string;
  category: 'History & Heritage' | 'Architecture' | 'Nature & Outdoors' | 'Local Food & Markets' | 'Art & Museums' | 'Spiritual & Sacred' | 'Photography';
  shortSummary: string;
  fullDescription: string;
  historicalBackground: string;
  culturalSignificance: string;
  architecturalFeatures: string;
  whyWorthVisiting: string;
  whatToExperience: string;
  location: string;
  coordinates: [number, number]; // [lat, lng]
  suggestedDuration: string;
  bestTimeToVisit: string;
  entryFeeInfo: string;
  openingHoursInfo: string;
  accessibilityInfo: string;
  familySuitability: string;
  photographyNotes: string;
  nearbyCombinations: string[];
  transitAdvice: string;
  visitorTips: string[];
  officialLinks: { title: string; url: string }[];
  sourceNote: string;
  verifiedDate: string;
  image: string;
  imageAlt: string;
  imageCredit: string;
}

export interface HeritageEpoch {
  epoch: string;
  title: string;
  description: string;
  keySites: string[];
}

export interface CulturalTradition {
  title: string;
  seasonOrFrequency: string;
  description: string;
  visitorEtiquette: string;
}

export interface RegionalDish {
  id: string;
  name: string;
  localName: string;
  culturalOrigin: string;
  description: string;
  typicalIngredients: string[];
  isVeg: boolean;
  whereToFind: string;
  priceCategory: 'Budget' | 'Moderate' | 'Specialty' | 'Budget to Moderate' | 'Moderate to Specialty';
  dietaryAdvice: string;
  etiquetteTips: string;
  image: string;
}

export interface FoodDistrict {
  name: string;
  character: string;
  bestTime: string;
  highlights: string[];
  visitorAdvice: string;
}

export interface EmergencyContact {
  title: string;
  number: string;
  note: string;
}

export interface SafetyGuide {
  generalPrecautions: string[];
  transportPedestrian: string[];
  nightTravel: string[];
  accessibilityNotes: string[];
  emergencyContacts: EmergencyContact[];
  limitationsDisclaimer: string;
}

export interface CommunityReport {
  id: string;
  cityId: string;
  category: 'Pedestrian Safety' | 'Lighting & Night Walkability' | 'Crowd Congestion' | 'Transit Accessibility' | 'Civic Note';
  title: string;
  description: string;
  neighbourhood: string;
  status: 'Unverified community report' | 'Under review' | 'Verified by civic/editorial source' | 'Resolved / Outdated';
  timestamp: string;
  verifiedBy?: string;
}

export interface Neighbourhood {
  id: string;
  name: string;
  cityId: string;
  character: string;
  budgetTier: 'Budget-friendly' | 'Moderate' | 'Upscale / High-end' | 'Budget-friendly to Moderate' | 'Moderate to Upscale';
  transitScore: string;
  transitDetails: string;
  walkabilityRating: string;
  accessibilityNotes: string;
  heritageHighlights: string[];
  foodHighlights: string[];
  greenSpaceNotes: string;
  safetyContext: string;
  methodologyNote: string;
  dataFreshness: string;
}

export interface CityStory {
  id: string;
  cityId: string;
  title: string;
  preview: string;
  fullArticle: string;
  locationName: string;
  factualExplanation: string;
  sources: string[];
  relatedDestinationIds: string[];
  readTimeMinutes: number;
  image: string;
  imageAlt: string;
}

export interface SeasonalClimate {
  season: string;
  temperatureRange: string;
  advice: string;
}

export interface TransportInfrastructure {
  mode: string;
  coverage: string;
  tip: string;
}

export interface CityInsights {
  seasonalClimate: SeasonalClimate[];
  transportInfrastructure: TransportInfrastructure[];
  environmentalNotes: string;
  dataAttribution: string;
}

export interface City {
  id: string;
  name: string;
  state: string;
  region: string;
  tagline: string;
  heroDescription: string;
  introSentence: string;
  coordinates: [number, number];
  accentColor: string; // e.g., 'teal', 'amber', 'rose', 'indigo'
  hexAccent: string;
  heroImage: string;
  imageAlt: string;
  imageCredit: string;
  heritageThemes: string[];
  destinations: Destination[];
  heritagePeriods: HeritageEpoch[];
  architecturalHeritageOverview: string;
  traditionsAndFestivals: CulturalTradition[];
  dishes: RegionalDish[];
  foodDistricts: FoodDistrict[];
  safetyGuide: SafetyGuide;
  neighbourhoods: Neighbourhood[];
  stories: CityStory[];
  insights: CityInsights;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isLive?: boolean;
  modelUsed?: string;
  sources?: string[];
}
