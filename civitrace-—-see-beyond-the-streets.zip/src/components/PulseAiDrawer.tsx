import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  X,
  Send,
  Bot,
  User,
  Compass,
  MapPin,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
  Layers,
  ArrowRight
} from 'lucide-react';
import { City, ChatMessage } from '../types';

interface PulseAiDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  city: City;
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

export const PulseAiDrawer: React.FC<PulseAiDrawerProps> = ({
  isOpen,
  onClose,
  city,
  initialPrompt,
  onClearInitialPrompt,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      role: 'assistant',
      content: `Welcome to Pulse AI for **${city.name}** ("${city.tagline}"). 

I am your fact-grounded editorial city intelligence guide. I can help you with:
- Crafting geographically logical afternoon or one-day itineraries
- Deep architectural & historical backgrounds of local monuments
- Authentic regional food recommendations and iconic institutions
- Comparing neighbourhoods by transit, budget, and walkability
- Practical etiquette, dress codes, and visitor safety considerations

Ask me anything about ${city.name}, or tap one of the suggested prompts below!`,
      timestamp: 'Just now',
      modelUsed: 'Grounded City Intelligence',
      sources: ['CIVITRACE Verified City Dossiers', 'Archaeological Survey of India'],
    },
  ]);

  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const starterPrompts = [
    `I have one afternoon in ${city.name}. What should I explore?`,
    `Explain the history and architecture of ${city.destinations[0]?.name || 'the main fort'}.`,
    `What authentic regional food must I try in ${city.name}, and where?`,
    `Which attractions in ${city.name} are close together to walk?`,
    `Can you suggest a budget-friendly 1-day itinerary with timings?`,
    `Compare the neighbourhoods in ${city.name}.`,
  ];

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle incoming initial prompt
  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSendMessage(initialPrompt);
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt, isOpen]);

  // Smart Local Fallback Intelligence Engine (Grounded directly in our authentic dataset)
  const generateLocalFallbackAnswer = (userQuery: string): { text: string; sources: string[] } => {
    const q = userQuery.toLowerCase();

    // 1. Afternoon or 1-day itinerary
    if (q.includes('afternoon') || q.includes('itinerary') || q.includes('1-day') || q.includes('one day') || q.includes('budget-friendly')) {
      const top3 = city.destinations.slice(0, 3);
      const dish = city.dishes[0];
      return {
        text: `Here is a curated, geographically logical itinerary for **${city.name}**:

**Morning (08:30 AM – 11:30 AM):**
- **${top3[0]?.name}**: Start early to explore before midday heat. ${top3[0]?.whyWorthVisiting} Suggested visit time: ${top3[0]?.suggestedDuration}. 
- *Visitor Tip*: ${top3[0]?.visitorTips?.[0] || 'Wear walking shoes.'}

**Midday Lunch & Culinary Pause:**
- Savor **${dish?.name}** (${dish?.localName}) at iconic spots like ${dish?.whereToFind}.
- *Dining Tip*: ${dish?.etiquetteTips || 'Best paired with local beverages.'}

**Afternoon to Sunset (03:30 PM – 06:30 PM):**
- **${top3[1]?.name}**: ${top3[1]?.shortSummary} 
- Finish at **${top3[2]?.name || 'the riverfront / evening market'}** for twilight atmosphere and street life.

*Transit advice*: ${city.insights.transportInfrastructure[0]?.tip || 'Utilize Metro where available.'}`,
        sources: [`${city.name} Heritage Planning Archives`, top3[0]?.sourceNote || 'CIVITRACE Dossiers'],
      };
    }

    // 2. Specific destination check
    const matchedDest = city.destinations.find(
      (d) => q.includes(d.name.toLowerCase()) || d.name.toLowerCase().includes(q)
    );
    if (matchedDest) {
      return {
        text: `### Historical & Architectural Dossier: **${matchedDest.name}**

**Historical Significance:**
${matchedDest.historicalBackground}

**Architectural Features:**
${matchedDest.architecturalFeatures}

**Why It Is Worth Visiting:**
${matchedDest.whyWorthVisiting}

**Practical Visitor Guidance:**
- **Opening Hours**: ${matchedDest.openingHoursInfo}
- **Entry Fee**: ${matchedDest.entryFeeInfo}
- **Best Time**: ${matchedDest.bestTimeToVisit}
- **Accessibility**: ${matchedDest.accessibilityInfo}
- **Nearby Combination**: Combine with ${matchedDest.nearbyCombinations.join(', ')}`,
        sources: [matchedDest.sourceNote, `Verified date: ${matchedDest.verifiedDate}`],
      };
    }

    // 3. Local Food queries
    if (q.includes('food') || q.includes('dish') || q.includes('eat') || q.includes('breakfast') || q.includes('try')) {
      const dishList = city.dishes
        .map(
          (d) =>
            `- **${d.name}** (${d.localName}): ${d.description}\n  *Where to find*: ${d.whereToFind}\n  *Dietary*: ${d.isVeg ? 'Vegetarian' : 'Non-Vegetarian'} (${d.dietaryAdvice})`
        )
        .join('\n\n');

      return {
        text: `Here are the essential gastronomic traditions of **${city.name}**:\n\n${dishList}\n\n**Food District Highlights**: Explore **${city.foodDistricts[0]?.name}** (${city.foodDistricts[0]?.character}).`,
        sources: [`${city.name} Culinary Archives`, 'CIVITRACE Gastronomy Field Surveys'],
      };
    }

    // 4. Neighbourhood comparison
    if (q.includes('compare') || q.includes('neighbourhood') || q.includes('district') || q.includes('area')) {
      const hoodText = city.neighbourhoods
        .map(
          (n) =>
            `### ${n.name}\n- **Character**: ${n.character}\n- **Budget**: ${n.budgetTier}\n- **Transit**: ${n.transitScore}\n- **Walkability**: ${n.walkabilityRating}\n- **Highlights**: ${n.heritageHighlights.join(', ')}`
        )
        .join('\n\n');

      return {
        text: `Here is the comparative breakdown of key districts in **${city.name}**:\n\n${hoodText}\n\n*All ratings are evaluated using municipal transport and street accessibility records without arbitrary numerical scores.*`,
        sources: [`${city.name} Urban Planning Survey`, 'CIVITRACE Neighbourhood Comparative Index'],
      };
    }

    // Default intelligent overview
    return {
      text: `### Exploring ${city.name} ("${city.tagline}")

${city.heroDescription}

**Key Cultural Anchors:**
${city.destinations.slice(0, 4).map((d) => `- **${d.name}** (${d.category}): ${d.shortSummary}`).join('\n')}

**Iconic Regional Taste:**
Try **${city.dishes[0]?.name}** at ${city.dishes[0]?.whereToFind}.

**Safety & Transit Tip:**
${city.safetyGuide.generalPrecautions[0]} Use ${city.insights.transportInfrastructure[0]?.mode}.`,
      sources: [`${city.name} Comprehensive City Dossier`, 'Archaeological Survey of India'],
    };
  };

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isLoading) return;

    const userMessageId = `user-${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMessageId,
      role: 'user',
      content: trimmed,
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Call server-side Gemini API route
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          city: {
            name: city.name,
            state: city.state,
            tagline: city.tagline,
            heroDescription: city.heroDescription,
            heritageThemes: city.heritageThemes,
          },
          history: messages.slice(-4),
        }),
      });

      if (!response.ok) {
        throw new Error('Server returned non-200 status');
      }

      const data = await response.json();

      if (data.isLive && data.text) {
        const assistantMsg: ChatMessage = {
          id: `ai-${Date.now()}`,
          role: 'assistant',
          content: data.text,
          timestamp: 'Just now',
          isLive: true,
          modelUsed: 'Gemini 3.8 Flash (Server-Side)',
          sources: [`${city.name} Official Heritage Archives`, 'Google AI Studio'],
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } else {
        throw new Error('Fallback required');
      }
    } catch {
      // Graceful, fact-grounded local intelligence fallback
      const fallbackResult = generateLocalFallbackAnswer(trimmed);
      const assistantMsg: ChatMessage = {
        id: `ai-fallback-${Date.now()}`,
        role: 'assistant',
        content: fallbackResult.text,
        timestamp: 'Just now',
        isLive: false,
        modelUsed: 'CIVITRACE Grounded Local Intelligence Engine',
        sources: fallbackResult.sources,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-xl h-full bg-[#0a0e17] border-l border-slate-800 shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-600 to-amber-600 flex items-center justify-center border border-teal-500/30 shadow-md">
              <Sparkles className="w-5 h-5 text-amber-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-editorial text-lg font-bold text-white">Pulse AI</h3>
                <span className="px-2 py-0.5 rounded-full bg-teal-500/15 border border-teal-500/30 text-teal-300 text-[10px] font-bold">
                  City Intelligence Guide
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Active Context: <strong className="text-amber-300">{city.name}</strong>, {city.state}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            aria-label="Close Pulse AI"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages Feed */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 text-xs sm:text-sm ${
                msg.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.role === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-amber-600/20 border border-amber-500/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4 text-amber-400" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 space-y-2 relative group ${
                  msg.role === 'user'
                    ? 'bg-amber-600 text-white rounded-br-xs'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-xs shadow-md'
                }`}
              >
                {/* Message Body */}
                <div className="leading-relaxed whitespace-pre-wrap space-y-2">
                  {msg.content}
                </div>

                {/* Engine Attribution & Sources for Assistant */}
                {msg.role === 'assistant' && (
                  <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500">
                    <div className="flex items-center gap-1.5 text-amber-400/90 font-mono">
                      <Sparkles className="w-3 h-3" />
                      <span>{msg.modelUsed || 'Grounded Local Intelligence'}</span>
                    </div>

                    <button
                      onClick={() => handleCopyMessage(msg.id, msg.content)}
                      className="text-slate-400 hover:text-slate-200 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4 text-slate-300" />
                </div>
              )}
            </div>
          ))}

          {/* Typing Indicator */}
          {isLoading && (
            <div className="flex gap-3 text-xs justify-start animate-in fade-in">
              <div className="w-7 h-7 rounded-lg bg-amber-600/20 border border-amber-500/30 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-amber-400" />
              </div>
              <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl rounded-bl-xs flex items-center gap-2 text-slate-400">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                <span>Consulting verified {city.name} city intelligence...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Starter Prompts Carousel */}
        <div className="p-3 bg-slate-900/60 border-t border-slate-800/80">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">
            Suggested Prompts for {city.name}:
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {starterPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(prompt)}
                disabled={isLoading}
                className="px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white whitespace-nowrap transition-colors text-[11px]"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-slate-900 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputValue);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={`Ask Pulse AI about ${city.name} heritage, food, or safety...`}
              disabled={isLoading}
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-400 text-xs sm:text-sm focus:outline-none focus:border-amber-500 transition-all disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isLoading}
              className="p-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 disabled:opacity-40 text-white shadow-md transition-all shrink-0"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <p className="text-[10px] text-slate-500 mt-2 text-center">
            Pulse AI answers strictly from verified municipal and historical sources. Never fabricates prices or live conditions.
          </p>
        </div>
      </div>
    </div>
  );
};
