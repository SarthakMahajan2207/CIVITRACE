import React, { useState } from 'react';
import { Bookmark, Clock, MapPin, ArrowRight, Eye, ShieldAlert } from 'lucide-react';
import { Destination } from '../types';

interface DestinationCardProps {
  destination: Destination;
  onOpenDetails: (destination: Destination) => void;
  isSaved: boolean;
  onToggleSave: (destinationId: string) => void;
}

export const DestinationCard: React.FC<DestinationCardProps> = ({
  destination,
  onOpenDetails,
  isSaved,
  onToggleSave,
}) => {
  const [imageError, setImageError] = useState(false);

  // Fallback image placeholder if link fails
  const fallbackImage = 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80';

  return (
    <div className="group rounded-2xl bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 hover:bg-slate-850 shadow-md transition-all duration-300 flex flex-col justify-between overflow-hidden">
      {/* Photographic Header */}
      <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-slate-950">
        <img
          src={imageError ? fallbackImage : destination.image}
          alt={destination.imageAlt || destination.name}
          onError={() => setImageError(true)}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

        {/* Category Badge */}
        <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-slate-900/85 backdrop-blur-md border border-slate-700/80 text-amber-200 text-xs font-semibold shadow-md">
          {destination.category}
        </div>

        {/* Bookmark Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleSave(destination.id);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md border transition-all shadow-md ${
            isSaved
              ? 'bg-amber-500 border-amber-400 text-slate-950 scale-105'
              : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
          title={isSaved ? 'Remove from saved' : 'Save to itinerary'}
          aria-label={isSaved ? 'Remove bookmark' : 'Add bookmark'}
        >
          <Bookmark className="w-3.5 h-3.5 fill-current" />
        </button>

        {/* Duration Chip */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-sm text-[11px] text-slate-300">
          <Clock className="w-3 h-3 text-amber-400" />
          <span>{destination.suggestedDuration}</span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 sm:p-5 flex flex-col justify-between flex-1">
        <div>
          <h3 className="text-lg font-editorial font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-1">
            {destination.name}
          </h3>

          <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-1">
            <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
            <span className="line-clamp-1">{destination.location}</span>
          </div>

          <p className="text-xs text-slate-300 mt-2.5 line-clamp-3 leading-relaxed">
            {destination.shortSummary}
          </p>
        </div>

        {/* Card Footer Actions */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
          <div className="text-[11px] text-slate-400">
            <span className="text-amber-400 font-semibold">{destination.entryFeeInfo.includes('Free') ? 'Free Entry' : 'Ticketed'}</span>
          </div>

          <button
            onClick={() => onOpenDetails(destination)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-semibold group-hover:border-amber-500/50 transition-all"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>View Dossier</span>
          </button>
        </div>
      </div>
    </div>
  );
};
