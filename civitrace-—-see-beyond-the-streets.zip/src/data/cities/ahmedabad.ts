import { City } from '../../types';

export const ahmedabadData: City = {
  id: 'ahmedabad',
  name: 'Ahmedabad',
  state: 'Gujarat',
  region: 'Sabarmati Basin & Western Plains',
  tagline: 'India’s First UNESCO World Heritage City & Cradle of Ahimsa',
  heroDescription: 'Founded in 1411 by Sultan Ahmed Shah on the banks of the Sabarmati river, Ahmedabad is India’s first designated UNESCO World Heritage City. Celebrated for its unique pols—tight-knit, community-oriented residential clusters featuring hand-carved wooden havelis and wooden bird-feeders (chabutras)—the city is also the spiritual cradle of Mahatma Gandhi’s non-violent freedom movement, the home of 15th-century subterranean stepwells, and a global textile design capital.',
  introSentence: 'India’s first UNESCO World Heritage City, where intricately carved wooden pol communities, serene Gandhian ashrams, and subterranean stone stepwells celebrate civic harmony.',
  coordinates: [23.0225, 72.5714],
  accentColor: 'amber',
  hexAccent: '#d97706',
  heroImage: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1600&q=80',
  imageAlt: 'Intricately carved stone pillars and arches of Adalaj Stepwell near Ahmedabad',
  imageCredit: 'Unsplash / Gujarat Tourism Development Corporation',
  heritageThemes: ['UNESCO World Heritage City Walled Fabric', 'Pol Architecture & Community Chabutras', 'Gandhian Ahimsa & Sabarmati Ashram', 'Solanki & Sultanate Stepwells (Vavs)', 'Textile Capital & Calico Weaving Heritage'],

  destinations: [
    {
      id: 'amd-adalaj-stepwell',
      name: 'Adalaj Stepwell (Adalaj Ni Vav)',
      cityId: 'ahmedabad',
      category: 'Architecture',
      shortSummary: '1498 five-storey subterranean stepwell fusing Solanki Hindu carvings with Islamic geometric filigree.',
      fullDescription: 'Constructed in 1498 in the village of Adalaj by Queen Rudabai, wife of Vaghela chieftain Rana Veer Singh, this five-storey subterranean stepwell is an architectural masterpiece of water conservation and tragic royal devotion. Descending five tiers into the cool earth to tap the deep water table, the structure served not only as a crucial caravan drinking reservoir on dry trade routes, but as a cool social sanctuary for village women. The stepwell features an octagonal opening that channels natural light and air down to the water, keeping the interior temperature nearly six degrees cooler than the scorching surface above. The sandstone pillars and walls are densely carved with an extraordinary fusion of Jain and Hindu deities, celestial dancers, flowering creepers, and Islamic floral arabesques.',
      historicalBackground: 'Commissioned by Rana Veer Singh; completed under Sultan Mahmud Begada who conquered the region and promised the grieving queen to complete her husband’s stepwell in his memory.',
      culturalSignificance: 'One of the most celebrated stepwells (vavs) in Gujarat, demonstrating the synthesis of Solanki stonecraft and Indo-Islamic design.',
      architecturalFeatures: 'Five-tiered subterranean stepped galleries, octagonal light shaft, 16 carved stone pillars per level, stepped pyramidal corridors, and mythological relief panels.',
      whyWorthVisiting: 'Experience the astonishing engineering and spiritual grace of traditional subterranean desert architecture, illuminated by shifting shafts of sunlight.',
      whatToExperience: 'Walk down the stepped platforms into the cool subterranean depths, study the carved friezes of the tree of life and churning of the ocean (Samudra Manthan), and touch the chilled stone pillars.',
      location: 'Adalaj, Gandhinagar Highway, 18 km north of Ahmedabad 382421',
      coordinates: [23.1667, 72.5833],
      suggestedDuration: '1.5 hours',
      bestTimeToVisit: 'Morning (8:30 AM – 11:00 AM) when morning sunlight creates dramatic shadow angles through the octagonal galleries.',
      entryFeeInfo: '₹25 for Indian citizens, ₹300 for foreign visitors (ASI monument ticketing).',
      openingHoursInfo: 'Open daily: 8:00 AM – 6:00 PM.',
      accessibilityInfo: 'Viewing from the ground level perimeter is flat and accessible; descending to the lower reservoir platforms requires navigating multiple flights of stone stairs.',
      familySuitability: 'Fascinating for architecture lovers, students, and families; ensure children do not climb over low stone parapets.',
      photographyNotes: 'Spectacular geometric perspective shots looking down through the successive octagonal levels.',
      nearbyCombinations: ['Akshardham Gandhinagar', 'Sabarmati Riverfront', 'Trimandir'],
      transitAdvice: 'Take a taxi or auto-rickshaw via SG Highway (approx. 30 minutes from central Ahmedabad). Dedicated parking at the gate.',
      visitorTips: ['Notice how the air temperature drops noticeably as you descend each successive level.', 'Combine with a visit to the Sabarmati Ashram on the return drive to the city.'],
      officialLinks: [{ title: 'ASI Vadodara Circle — Adalaj Stepwell', url: 'https://asivadodara.in' }],
      sourceNote: 'Archaeological Survey of India & Gujarat State Archaeology Department.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Carved sandstone subterranean galleries of Adalaj Stepwell',
      imageCredit: 'Unsplash'
    },
    {
      id: 'amd-sabarmati-ashram',
      name: 'Sabarmati Ashram & Hriday Kunj',
      cityId: 'ahmedabad',
      category: 'History & Heritage',
      shortSummary: 'Mahatma Gandhi’s tranquil headquarters from 1917 to 1930, from which the historic 1930 Salt March commenced.',
      fullDescription: 'Nestled beneath tranquil neem and tamarind trees on the tranquil western bank of the Sabarmati river, this modest ashram was the spiritual and political laboratory of Mahatma Gandhi for twelve decisive years (1917–1930). It was from his simple whitewashed cottage here—Hriday Kunj ("Abode of the Heart")—that Gandhi directed India’s non-violent independence struggle, established the dignity of manual labour, promoted village khadi spinning, and launched the historic 241-mile Dandi Salt March on 12 March 1930, vowing never to return until India had won complete freedom. Today, the ashram is preserved with serene dignity, featuring Charles Correa’s celebrated 1963 Gandhi Smarak Sangrahalaya museum housing original letters, spinning wheels (charkhas), and manuscripts.',
      historicalBackground: 'Founded by Gandhi in 1917 after moving from Kochrab; served as the headquarters of the national Satyagraha movement.',
      culturalSignificance: 'The global pilgrimage center of non-violent resistance (Ahimsa) and truth-seeking (Satyagraha).',
      architecturalFeatures: 'Vernacular whitewashed brick cottages, terracotta tiled roofs, open-air prayer grounds overlooking the river, and Charles Correa’s open-brick pavilion museum.',
      whyWorthVisiting: 'Experience the sublime power of absolute simplicity and stand where modern world history was redirected without a single weapon.',
      whatToExperience: 'Step inside Hriday Kunj to view Gandhi’s spinning wheel and writing desk, sit in quiet meditation on the open prayer ground at sunrise, and study the letters to Tolstoy and Einstein in the museum.',
      location: 'Gandhi Smarak Sangrahalaya, Ashram Road, Ahmedabad 380027',
      coordinates: [23.0605, 72.5804],
      suggestedDuration: '2 hours',
      bestTimeToVisit: 'Early morning (8:00 AM – 10:30 AM) when bird song fills the trees and gentle river breezes cool the grounds.',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Open daily: 8:30 AM – 6:30 PM.',
      accessibilityInfo: 'Paved, level gravel and brick pathways throughout the ashram grounds; wheelchair accessible.',
      familySuitability: 'Deeply moving and educational for visitors of all generations.',
      photographyNotes: 'Non-flash photography allowed; the play of natural light through the brick open pavilions of the museum is world-class.',
      nearbyCombinations: ['Sabarmati Riverfront Promenade', 'Calico Museum of Textiles', 'Usmanpura Heritage Precinct'],
      transitAdvice: 'Located directly on Ashram Road. Accessible via Ahmedabad BRTS or Metro Line 1 (Old High Court / Gandhi Ashram).',
      visitorTips: ['Visit the ashram khadi bookshop to purchase authenticated spinning wheels, khadi garments, and Gandhi’s autobiography.', 'Take a peaceful seat on the stone bench overlooking the river.'],
      officialLinks: [{ title: 'Sabarmati Ashram Preservation and Memorial Trust', url: 'https://gandhiashramsabarmati.org' }],
      sourceNote: 'Sabarmati Ashram Memorial Trust & Gandhi Heritage Portal.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Whitewashed terracotta-roofed cottage of Hriday Kunj at Sabarmati Ashram',
      imageCredit: 'Unsplash'
    },
    {
      id: 'amd-sidi-saiyyed',
      name: 'Sidi Saiyyed Mosque & Tree of Life Jaali',
      cityId: 'ahmedabad',
      category: 'Architecture',
      shortSummary: '1573 stone filigree masterpiece featuring the internationally famous "Tree of Life" carved marble screens.',
      fullDescription: 'Constructed in 1573 in the final years of the Gujarat Sultanate by Sidi Saiyyed, an Abyssinian general of the royal court, this modest sandstone mosque near the city center is globally renowned for its extraordinary ten stone latticework windows (jaalis). The semi-circular jali on the western wall—the celebrated "Tree of Life"—is hailed as one of the supreme achievements of stone carving in human history. Carved out of a single block of yellow sandstone, the window depicts an intricately stylized banyan tree with delicate intertwining branches, curling tendrils, and palm fronds. The carving is so fine and lace-like that from a short distance, it appears not as solid stone, but as diaphanous textile lace. The motif was adopted as the official design insignia of the Indian Institute of Management Ahmedabad (IIM-A).',
      historicalBackground: 'Completed just before Mughal Emperor Akbar conquered Gujarat in 1573; the intricate carving work was reportedly left slightly unfinished at the side arches due to the sudden arrival of imperial forces.',
      culturalSignificance: 'The global artistic ambassador of Ahmedabad, recognized worldwide as the zenith of Indo-Islamic decorative sculpture.',
      architecturalFeatures: 'Intricately pierced sandstone jali screens, ten arched window bays, fluted minarets, and yellow sandstone masonry.',
      whyWorthVisiting: 'Stand face-to-face with the pinnacle of world stone filigree carving, freely accessible right in the center of the city.',
      whatToExperience: 'Study the delicate stone vines and leaves backlit by natural sunlight, admire the symmetrical geometry of the side screens, and observe afternoon prayers in the quiet stone hall.',
      location: 'Bhadra, Opposite Electricity House, Gheekanta, Ahmedabad 380001',
      coordinates: [23.0286, 72.5806],
      suggestedDuration: '45 minutes',
      bestTimeToVisit: 'Morning or late afternoon (3:30 PM – 5:30 PM) when low sun illuminates the lace-like stone screens from behind.',
      entryFeeInfo: 'Free entry.',
      openingHoursInfo: 'Open daily: 6:00 AM – 8:00 PM.',
      accessibilityInfo: 'Level stone courtyard; easily accessible from the street with low threshold.',
      familySuitability: 'Peaceful, inspiring, and accessible for all travelers.',
      photographyNotes: 'Capture the intricate silhouette of the Tree of Life against the sunlit outer sky.',
      nearbyCombinations: ['Bhadra Fort', 'Teen Darwaza', 'Manek Chowk'],
      transitAdvice: 'Gheekanta Metro Station is 500m away; easily accessible via auto-rickshaw or city buses.',
      visitorTips: ['Remove footwear before stepping onto the carpeted prayer hall floor.', 'Walk 10 minutes east through the historic Teen Darwaza arch into the historic pols.'],
      officialLinks: [{ title: 'Gujarat Tourism — Sidi Saiyyed Mosque', url: 'https://gujarattourism.com' }],
      sourceNote: 'Archaeological Survey of India Vadodara Circle & Gujarat State Archaeology Department.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Delicate stone latticework screen of the Tree of Life at Sidi Saiyyed Mosque',
      imageCredit: 'Unsplash'
    },
    {
      id: 'amd-historic-pols',
      name: 'The Historic Walled City Pols & Chabutras',
      cityId: 'ahmedabad',
      category: 'Architecture',
      shortSummary: '600-year-old self-contained neighborhood clusters with hand-carved teakwood havelis and ornate bird feeders.',
      fullDescription: 'The defining urban feature that earned Ahmedabad its UNESCO World Heritage inscription is its network of over 600 historic pols (from the Sanskrit pratoli, meaning "gate"). Developed as defensive, self-contained residential micro-neighborhoods during centuries of political unrest, each pol features a single fortified gate leading into a maze of shaded, narrow pedestrian lanes. The architecture is characterized by multi-storey timber-framed havelis adorned with intricately hand-carved teak facades, bracket figures of peacocks and elephants, secret underground escape passages, and rainwater harvesting cisterns (tankas). At the center of every pol stands an ornate, multi-tiered wooden bird feeder (chabutra), demonstrating the Jain and Hindu ethos of reverence for non-human life by providing grain and water for thousands of urban birds.',
      historicalBackground: 'Evolved between the 15th and 18th centuries; preserved through strong community caste and trade guild (Mahajan) governance systems.',
      culturalSignificance: 'The living heart of Ahmedabad’s UNESCO World Heritage status, embodying human-scale community living, thermal insulation, and shared compassion.',
      architecturalFeatures: 'Carved teakwood brackets, otlas (raised street verandas), underground rainwater tankas, cantilevered upper storeys providing shade, and ornate wooden chabutras.',
      whyWorthVisiting: 'Experience an intact, living medieval residential ecosystem that demonstrates timeless principles of sustainable, climate-responsive urban design.',
      whatToExperience: 'Join the morning Ahmedabad Heritage Walk starting at Kalupur Swaminarayan Temple, admire the carved haveli facades in Mandvi ni Pol, watch pigeons feed at the stone chabutras, and visit Manek Chowk.',
      location: 'Old City, Khadia to Kalupur, Ahmedabad 380001',
      coordinates: [23.0238, 72.5894],
      suggestedDuration: '2.5 to 3 hours',
      bestTimeToVisit: 'Early morning (7:30 AM – 10:30 AM) during the official Ahmedabad Municipal Corporation Heritage Walk.',
      entryFeeInfo: 'Self-guided walking is free; AMC Guided Heritage Walk: ₹100 for Indian citizens, ₹200 for foreign tourists.',
      openingHoursInfo: 'Open public residential neighbourhoods; respect private residents.',
      accessibilityInfo: 'Pols are narrow and closed to four-wheeled cars; walking is on paved stone with gentle slopes.',
      familySuitability: 'Delightful and safe for all ages; lively street culture.',
      photographyNotes: 'Intricate carved wooden pillars, ornate bird towers, and warm street life; ask residents before photographing interior courtyards.',
      nearbyCombinations: ['Jama Masjid', 'Manek Chowk', 'Swaminarayan Mandir Kalupur'],
      transitAdvice: 'Kalupur Railway Station Metro and Gheekanta Metro Stations provide easy access to the edge of the walled city.',
      visitorTips: ['Book the official Ahmedabad Heritage Walk online or at the Kalupur Swaminarayan Temple desk by 7:45 AM.', 'Sample hot fafda and jalebi at Chandravilas Restaurant (operating since 1900) on Gandhi Road.'],
      officialLinks: [{ title: 'Ahmedabad World Heritage City Trust (AMC)', url: 'https://heritage.ahmedabadcity.gov.in' }],
      sourceNote: 'UNESCO World Heritage Inscription Dossier & AMC Heritage Cell.',
      verifiedDate: 'October 2024',
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1000&q=80',
      imageAlt: 'Ornate carved wooden facade and bird feeder tower in Ahmedabad historic pol',
      imageCredit: 'Unsplash'
    }
  ],

  heritagePeriods: [
    {
      epoch: '1411 – 1572 CE',
      title: 'The Gujarat Sultanate & Foundation of Ahmedabad',
      description: 'Sultan Ahmed Shah founds the capital in 1411; master builders construct monumental stepwells, the colossal Jama Masjid, and fortified gates along the Sabarmati.',
      keySites: ['Bhadra Fort', 'Jama Masjid (1424)', 'Adalaj Stepwell (1498)', 'Sidi Saiyyed Mosque']
    },
    {
      epoch: '1572 – 1818 CE',
      title: 'Mughal & Maratha Mercantile Rule',
      description: 'Ahmedabad becomes a wealthy global textile and indigo hub under Mughal governors. Defensive pol neighborhoods flourish, governed by powerful mercantile guilds (Mahajans).',
      keySites: ['Historic Walled City Pols', 'Sarkhej Roza', 'Hutheesing Jain Temple']
    },
    {
      epoch: '1915 – Present',
      title: 'Gandhian Ahimsa & UNESCO Recognition',
      description: 'Mahatma Gandhi establishes the Sabarmati Ashram, leading the freedom struggle. In 2017, Ahmedabad is declared India’s first UNESCO World Heritage City.',
      keySites: ['Sabarmati Ashram', 'Calico Museum of Textiles', 'Sabarmati Riverfront']
    }
  ],

  architecturalHeritageOverview: 'Ahmedabad is defined by its timber-framed pol havelis with hand-carved teakwood brackets, earthquake-resistant wooden bond timbers, and deep underground rainwater cisterns—coexisting with colossal 15th-century sandstone stepwells with subterranean Solanki pillars.',

  traditionsAndFestivals: [
    {
      title: 'International Kite Festival (Uttarayan)',
      seasonOrFrequency: 'January 14–15 (Makar Sankranti)',
      description: 'The sky over Ahmedabad becomes a roaring canvas of millions of colorful kites. Families crowd rooftops from dawn to midnight, shouting "Kai Po Che!" as dueling kites soar, followed by floating paper lanterns (tukkals) and sesame sweets.',
      visitorEtiquette: 'Watch out for glass-coated kite strings (manja) along public roads; rooftop invitations from local families are warm and hospitable.'
    },
    {
      title: 'Navratri Garba (Nine Nights of Dance)',
      seasonOrFrequency: 'Ashwin month (September – October, 9 nights)',
      description: 'The world’s longest dance festival. Millions of citizens dressed in mirror-work chaniya cholis dance in synchronized concentric circles to devotional rhythms, celebrating the divine feminine under open skies until 2:00 AM.',
      visitorEtiquette: 'Join open community garba grounds respectfully; traditional festive attire is welcomed.'
    }
  ],

  dishes: [
    {
      id: 'amd-gujarati-thali',
      name: 'Grand Gujarati Thali',
      localName: 'ગુજરાતી થાળી',
      culturalOrigin: 'The crowning glory of vegetarian gastronomy, refined across merchant and Jain household traditions.',
      description: 'An expansive vegetarian feast celebrating the harmony of six Ayurvedic tastes: sweet, sour, salty, bitter, pungent, and astringent. Features hot phulkas brushed with ghee, sweet-tart Gujarati kadhi thickened with chickpea flour and tempered with cinnamon, ringna no olo (smoked eggplant), dal, farsan (khaman, kachori), accompanied by gol-keri pickle, papad, and seasonal aamras (mango pulp) or shrikhand.',
      typicalIngredients: ['Gujarati kadhi', 'Spiced vegetables (shaak)', 'Ghee phulkas', 'Khaman dhokla', 'Aamras / Shrikhand', 'Chaas (buttermilk)'],
      isVeg: true,
      whereToFind: 'Agashiye (The House of MG), Vishalla (heritage village setting), Gordhan Thal, Sasumaa.',
      priceCategory: 'Moderate to Specialty',
      dietaryAdvice: 'Strictly vegetarian. Jain options (without onion, garlic, or root vegetables) widely available.',
      etiquetteTips: 'Do not hesitate to request multiple refills of hot phulkas and sweet kadhi; hospitality is limitless.',
      image: 'https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'amd-khaman-fafda',
      name: 'Surati Khaman Dhokla & Fafda Jalebi',
      localName: 'ખમણ ઢોકળા અને ફાફડા જલેબી',
      culturalOrigin: 'The beloved morning breakfast and festive snack of Gujarat, perfected across centuries.',
      description: 'Pillowy, spongy, steamed chickpea flour cakes (khaman) tempered with mustard seeds, green chillies, and fresh grated coconut, doused in light sugar-lemon water. Paired with crispy, savory chickpea ribbon crisps (fafda) seasoned with ajwain and black pepper, hot saffron jalebis, and raw papaya sambharo salad.',
      typicalIngredients: ['Gram flour (besan)', 'Mustard seeds & green chillies', 'Ajwain (carom seeds)', 'Fermented jalebi batter', 'Papaya sambharo'],
      isVeg: true,
      whereToFind: 'Das Khaman (multiple branches), Chandravilas Restaurant (Gandhi Road), Oswal (Ashram Road).',
      priceCategory: 'Budget',
      dietaryAdvice: 'Vegetarian and vegan. Light, easily digestible, and comforting.',
      etiquetteTips: 'Pair the crisp savory fafda with sweet jalebi in the same bite for the signature Gujarati sweet-salty harmony.',
      image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
    }
  ],

  foodDistricts: [
    {
      name: 'Manek Chowk Night Market',
      character: 'Jewelry market by day that transforms by 9:00 PM into an electrifying open-air street food square.',
      bestTime: 'Night 9:30 PM until 1:30 AM.',
      highlights: ['Gwalior dosa with butter', 'Chocolate cheese sandwiches', 'Pav bhaji and kulfi'],
      visitorAdvice: 'Completely pedestrianized at night; park near Teen Darwaza and walk in.'
    },
    {
      name: 'Law Garden & CG Road',
      character: 'Bustling evening market featuring traditional mirror-work crafts followed by a bustling street food khau galli.',
      bestTime: 'Evening 6:00 PM – 10:30 PM.',
      highlights: ['Kulfi falooda', 'Dabeli', 'Frankies and chaat stalls'],
      visitorAdvice: 'Great combination of evening handicraft souvenir shopping and light dining.'
    }
  ],

  safetyGuide: {
    generalPrecautions: [
      'Ahmedabad is officially recognized as one of the safest metropolitan cities in India, with very low crime rates and active night street life.',
      'Summer temperatures in April and May often exceed 43°C; schedule monument visits in early morning hours and carry cold buttermilk (chaas).',
      'Gujarat is a dry state (alcohol prohibition is in effect); foreign and domestic travelers can obtain temporary liquor permits online or at approved five-star hotel desks with valid travel documentation.'
    ],
    transportPedestrian: [
      'Ahmedabad Metro Line 1 and Line 2 provide clean, air-conditioned step-free transit connecting the Old City to modern western business sectors.',
      'Janmarg BRTS is one of India’s most successful bus rapid transit networks with dedicated lanes and level platform boarding.',
      'Auto-rickshaw drivers generally use meters; ride-hailing apps (Ola, Uber, Rapido) provide guaranteed upfront pricing.'
    ],
    nightTravel: [
      'Manek Chowk, Law Garden, and the Sabarmati Riverfront promenade remain lively with families and women past midnight.',
      'The city is exceptionally safe for late evening walks.'
    ],
    accessibilityNotes: [
      'Ahmedabad Metro and Janmarg BRTS stations feature level, step-free boarding and ramps.',
      'Sabarmati Riverfront features a continuous 11 km level paved lower promenade suitable for wheelchairs and strollers.'
    ],
    emergencyContacts: [
      { title: 'Ahmedabad Police Emergency', number: '112 / 100', note: 'Unified 24/7 emergency dispatch' },
      { title: 'Women Safety Helpline', number: '1091', note: 'SHE Teams & Women Police Division' },
      { title: 'Civil Hospital Emergency (Asarwa)', number: '079 2268 0074', note: 'One of Asia’s largest government hospitals' },
      { title: 'Disaster Emergency Helpdesk', number: '079 2755 1551', note: 'Municipal emergency helpline' }
    ],
    limitationsDisclaimer: 'Information is cross-referenced with Ahmedabad Police Commissionerate notifications and Gujarat Tourism Development Corporation.'
  },

  neighbourhoods: [
    {
      id: 'amd-historic-pols-quarter',
      name: 'Walled City: Historic Pols & Haveli Grid',
      cityId: 'ahmedabad',
      character: 'The UNESCO World Heritage core, characterized by narrow shaded lanes, wooden havelis, community bird towers (chabutras), and quiet temple courtyards.',
      budgetTier: 'Budget-friendly',
      transitScore: 'Very High (Served by Kalupur and Gheekanta metro stations, extensive auto routes)',
      transitDetails: 'Direct Metro connection; walking is the only way to navigate the interior lanes.',
      walkabilityRating: 'Very High for pedestrians; vehicles are restricted, creating a calm historic pace.',
      accessibilityNotes: 'Pols have stone paving; historic wooden havelis have raised stone entry plinths (otlas).',
      heritageHighlights: ['Historic Pols & Chabutras', 'Sidi Saiyyed Mosque', 'Jama Masjid', 'Teen Darwaza'],
      foodHighlights: ['Chandravilas Restaurant', 'Das Khaman', 'Manek Chowk night market'],
      greenSpaceNotes: 'Courtyard trees and nearby Sabarmati Riverfront gardens.',
      safetyContext: 'One of the safest, most socially cohesive urban communities in India.',
      methodologyNote: 'Evaluated using UNESCO World Heritage management documentation and architectural conservation surveys.',
      dataFreshness: 'Updated October 2024'
    },
    {
      id: 'amd-ashram-road-riverfront',
      name: 'Ashram Road & Sabarmati Riverfront',
      cityId: 'ahmedabad',
      character: 'Civilized modern cultural corridor running along the Sabarmati river, connecting Gandhi’s ashram, contemporary art museums, and landscaped waterfront parks.',
      budgetTier: 'Moderate to Upscale',
      transitScore: 'Very High (Ahmedabad Metro, BRTS, wide avenues, plentiful app cabs)',
      transitDetails: 'Excellent vehicular and public transit connectivity; ample parking at riverfront parks.',
      walkabilityRating: 'Very High (The 11 km continuous paved Sabarmati Riverfront promenade offers car-free walking).',
      accessibilityNotes: 'Riverfront promenade features ramps, elevators, and wide flat paved pathways.',
      heritageHighlights: ['Sabarmati Ashram (Hriday Kunj)', 'Kite Museum (Sanskar Kendra, Le Corbusier)', 'Usmanpura Tomb'],
      foodHighlights: ['Agashiye at The House of MG', 'Toran Dining Hall', 'Riverfront cafes'],
      greenSpaceNotes: 'Riverfront Flower Park, Biodiversity Park, and Sabarmati Ashram woodland.',
      safetyContext: 'Exceptionally safe day and night, popular with joggers, cyclists, and families.',
      methodologyNote: 'Based on riverfront urban renewal metrics and public open-space accessibility audits.',
      dataFreshness: 'Updated October 2024'
    }
  ],

  stories: [
    {
      id: 'story-amd-chabutra-compassion',
      cityId: 'ahmedabad',
      title: 'Towers of Compassion: Why Every Pol Built a Palace for Birds',
      preview: 'In the heart of India’s first World Heritage City, discover how human communities built multi-tiered wooden towers to feed pigeons, parrots, and peacocks.',
      fullArticle: 'To walk through the historic pols of Ahmedabad is to encounter an architectural element found nowhere else: the chabutra. Rising like an ornate, multi-tiered miniature pagoda on an octagonal wooden pillar in the center of community squares, the chabutra is a dedicated palace for birds. Inscribed with vibrant folk carvings of peacocks, elephants, and floral brackets, these towers feature an elevated platform protected by an overhanging tiled umbrella roof to shelter birds from rain and predatory cats. Rooted in the ancient Jain and Hindu philosophy of Jivdaya (compassion toward all living beings), pol residents take turns every morning replenishing fresh water in earthen bowls and scattering grains. In a dense medieval city where human space was tightly constrained, citizens deliberately dedicated their most precious central plazas to non-human neighbors, creating a living monument to ecological harmony.',
      locationName: 'Dhal ni Pol & Mandvi ni Pol',
      factualExplanation: 'Documented in UNESCO World Heritage Inscription Dossier for Historic City of Ahmadabad and Ahmedabad Heritage Cell archives.',
      sources: ['UNESCO World Heritage Nomination Dossier: Historic City of Ahmadabad', 'The Pols of Ahmedabad by CEPT University Press'],
      relatedDestinationIds: ['amd-historic-pols'],
      readTimeMinutes: 3,
      image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80',
      imageAlt: 'Ornate wooden bird feeder tower in historic Ahmedabad courtyard'
    }
  ],

  insights: {
    seasonalClimate: [
      { season: 'Winter (Nov – Feb)', temperatureRange: '12°C – 28°C', advice: 'Peak travel season; crisp sunny days, pleasant evenings, the International Kite Festival (Jan 14–15), and heritage walks.' },
      { season: 'Monsoon (Jul – Sep)', temperatureRange: '25°C – 33°C', advice: 'Moderate showers; stepwells fill up and riverfront gardens are lush.' },
      { season: 'Summer (Mar – Jun)', temperatureRange: '27°C – 44°C', advice: 'Severe dry heat; plan outdoor explorations before 9:30 AM or after 6:00 PM; drink cold buttermilk (chaas).' }
    ],
    transportInfrastructure: [
      { mode: 'Ahmedabad Metro', coverage: 'East-West and North-South corridors connecting Thaltej, Kalupur, and APMC', tip: 'Fast, step-free, air-conditioned; great way to travel between modern west and historic east.' },
      { mode: 'Janmarg BRTS', coverage: 'Dedicated closed-lane bus rapid transit across 160+ km', tip: 'Frequent, avoids road traffic completely.' },
      { mode: 'Sabarmati Riverfront Promenade', coverage: '11 km continuous paved pedestrian river walk', tip: 'Great for morning jogging and evening strolls.' }
    ],
    environmentalNotes: 'The Sabarmati Riverfront Project transformed a seasonal dry riverbed into a perennial water reservoir and green public parkway. Heritage restoration laws strictly prohibit vehicular alteration of the historic pols.',
    dataAttribution: 'Ahmedabad World Heritage City Trust & Gujarat Tourism Development Corporation'
  }
};
